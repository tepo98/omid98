import requests
import ipaddress
import time
from concurrent.futures import ThreadPoolExecutor
from rich import print
from rich.console import Console

console = Console()

# ================= STATE =================
alive = []
dead = []
tested = 0

# ================= DEFAULT CONFIG =================
CONFIG = {
    "timeout": 3,
    "threads": 25,
    "mode": "auto"   # auto / fast / safe
}

lock = None


# ================= CHECK =================
def check_ip(ip):
    global tested

    try:
        start = time.time()
        r = requests.get(f"http://{ip}", timeout=CONFIG["timeout"])
        latency = int((time.time() - start) * 1000)

        alive.append((str(ip), latency))
        tested += 1

        print(f"[green]✔ LIVE[/green] {ip} {latency}ms")

    except:
        dead.append(str(ip))
        tested += 1
        print(f"[red]✘ DEAD[/red] {ip}")


# ================= INPUT PARSER =================
def expand(data):
    ips = set()

    for line in data.splitlines():
        line = line.strip()
        if not line:
            continue

        # CIDR
        if "/" in line:
            try:
                net = ipaddress.ip_network(line, strict=False)
                for ip in net.hosts():
                    ips.add(str(ip))
            except:
                pass

        # RANGE
        elif "-" in line:
            try:
                s, e = line.split("-")
                s = ipaddress.IPv4Address(s.strip())
                e = ipaddress.IPv4Address(e.strip())
                for i in range(int(s), int(e) + 1):
                    ips.add(str(ipaddress.IPv4Address(i)))
            except:
                pass

        # SINGLE
        else:
            try:
                ipaddress.IPv4Address(line)
                ips.add(line)
            except:
                pass

    return list(ips)


# ================= MENU =================
def menu():
    print("\n[bold cyan]==== TEPO98 SCANNER ====[/bold cyan]")

    print("1) 🚀 Start Scan (AUTO MODE)")
    print("2) ⚙ Quick Settings")
    print("3) ⚡ Fast Mode")
    print("4) 🛡 Safe Mode")
    print("5) 📊 Show Config")
    print("6) ❌ Exit")

    return input("Select: ")


# ================= SETTINGS (IN MENU ONLY) =================
def quick_settings():
    print("\n⚙ QUICK SETTINGS")

    t = input(f"Threads [{CONFIG['threads']}]: ")
    to = input(f"Timeout sec [{CONFIG['timeout']}]: ")

    if t.strip():
        CONFIG["threads"] = int(t)

    if to.strip():
        CONFIG["timeout"] = int(to)

    print("[green]✔ Saved[/green]")


def set_mode(mode):
    CONFIG["mode"] = mode

    if mode == "fast":
        CONFIG["threads"] = 60
        CONFIG["timeout"] = 1

    elif mode == "safe":
        CONFIG["threads"] = 15
        CONFIG["timeout"] = 5

    else:  # auto
        CONFIG["threads"] = 25
        CONFIG["timeout"] = 3

    print(f"[cyan]Mode set: {mode}[/cyan]")


def show_config():
    print("\n[bold yellow]CONFIG[/bold yellow]")
    for k, v in CONFIG.items():
        print(f"{k}: {v}")


# ================= SCAN =================
def scan(ips):
    global alive, dead, tested

    alive = []
    dead = []
    tested = 0

    print(f"\n[cyan]🚀 Scanning {len(ips)} IPs | MODE: {CONFIG['mode']}[/cyan]\n")

    with ThreadPoolExecutor(max_workers=CONFIG["threads"]) as exe:
        exe.map(check_ip, ips)

    print("\n[bold green]===== RESULT =====[/bold green]")
    print(f"Alive: {len(alive)}")
    print(f"Dead: {len(dead)}")

    if alive:
        alive.sort(key=lambda x: x[1])
        print("\n[cyan]TOP IPs:[/cyan]")
        for ip, lat in alive[:10]:
            print(f"[green]{ip}[/green] → {lat}ms")


# ================= MAIN =================
while True:
    choice = menu()

    # AUTO SCAN (DEFAULT)
    if choice == "1":
        print("\nPaste IP / CIDR / Range (empty line = start):")

        data = ""
        while True:
            line = input()
            if line == "":
                break
            data += line + "\n"

        ips = expand(data)

        if not ips:
            print("[red]No valid IP[/red]")
            continue

        scan(ips)

    elif choice == "2":
        quick_settings()

    elif choice == "3":
        set_mode("fast")

    elif choice == "4":
        set_mode("safe")

    elif choice == "5":
        show_config()

    elif choice == "6":
        print("Bye 👋")
        break
