#!/usr/bin/env python3
import os

# رنگ‌ها
GREEN = "\033[1;32m"
CYAN = "\033[1;36m"
YELLOW = "\033[1;33m"
RED = "\033[1;31m"
RESET = "\033[0m"

# منو با منابع جدید
options = [
    ("Config Lite", "https://raw.githubusercontent.com/Kolandone/v2raycollector/main/config_lite.txt"),
    ("V2RAY Latest Base64", "https://github.com/LonUp/NodeList/raw/main/V2RAY/Latest_base64.txt"),
    ("V2ray Nodes Peter", "https://github.com/theGreatPeter/v2rayNodes/raw/main/nodes.txt"),
    ("NodeFree 20240228", "https://nodefree.org/dy/2024/02/20240228.txt"),
    ("Everyday Node", "https://raw.githubusercontent.com/245237866/v2rayn/main/everydaynode"),
    ("52bp FreeSite", "https://raw.githubusercontent.com/52bp/52bp.github.io/master/freesite.html"),
    ("AzadNet iOS", "https://raw.githubusercontent.com/AzadNetCH/Clash/main/AzadNet_iOS.txt"),
    ("Barabama Merged", "https://raw.githubusercontent.com/Barabama/FreeNodes/master/nodes/merged.txt"),
    ("Creativveb Updated", "https://raw.githubusercontent.com/Creativveb/v2configs/main/updated"),
    ("Flik6 V2ray", "https://raw.githubusercontent.com/Flik6/getNode/main/v2ray.txt"),
    # ... ادامهٔ همه لینک‌ها طبق لیست شما ...
]

# 🔁 حلقه تکراری
while True:
    # نمایش منو
    print(f"{GREEN}Select a VPN subscription link:{RESET}")
    for idx, (name, _) in enumerate(options, 1):
        print(f"{CYAN}{idx}. {YELLOW}{name}{RESET}")
    print(f"{CYAN}0. {YELLOW}Exit{RESET}")

    choice = input(f"{GREEN}Enter your choice: {RESET}").strip()

    # خروج
    if choice == "0":
        print(f"{YELLOW}Exiting...{RESET}")
        exit(0)

    # بررسی انتخاب و باز کردن لینک
    try:
        idx = int(choice) - 1
        if 0 <= idx < len(options):
            subscription = options[idx][1]
            print(f"{GREEN}Opening subscription link in browser...{RESET}")
            os.system(f'am start -a android.intent.action.VIEW -d "{subscription}" >/dev/null 2>&1')
        else:
            print(f"{RED}Invalid input.{RESET}")
    except ValueError:
        print(f"{RED}Invalid input.{RESET}")
