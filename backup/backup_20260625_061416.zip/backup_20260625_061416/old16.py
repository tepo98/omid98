#!/data/data/com.termux/files/usr/bin/python3
# -*- coding: utf-8 -*-
"""
Optimized hybrid proxy parser & tester
- Supports: vless, vmess, trojan, shadowsocks
- Median ping measurement
- Categorizes proxies: GREEN (fast), YELLOW (stable), RED (discard)
- Groups: Fast, Stable, PreciseFallback
- Minimal terminal output
- Smart fallback update with lightweight ping history
"""

import os, re, json, yaml, base64, socket, time, threading, subprocess
from urllib.parse import urlparse, parse_qs
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import deque

# -------------------- paths & editor --------------------
BASE_DIR = "/storage/emulated/0/Download/Akbar98"
os.makedirs(BASE_DIR, exist_ok=True)
INPUT_PATH = os.path.join(BASE_DIR, "input.txt")

# Clear input and open editor
with open(INPUT_PATH, "w", encoding="utf-8"): pass
try: subprocess.call(["nano", INPUT_PATH])
except: pass

# Output folder and file
out_folder = input("Enter output folder name in Download: ").strip()
if not out_folder: raise SystemExit("Folder name required.")
OUT_DIR = os.path.join("/storage/emulated/0/Download", out_folder)
os.makedirs(OUT_DIR, exist_ok=True)

out_name = input("Enter output file name (without extension): ").strip()
if not out_name: raise SystemExit("File name required.")
OUT_PATH = os.path.join(OUT_DIR, f"{out_name}.yaml")

# -------------------- user-configurable settings --------------------
def read_int(prompt, default):
    try: v = input(f"{prompt} [{default}]: ").strip(); return int(v) if v else default
    except: return default
def read_float(prompt, default):
    try: v = input(f"{prompt} [{default}]: ").strip(); return float(v) if v else default
    except: return default

PING_ATTEMPTS = read_int("Ping attempts", 5)
PING_TIMEOUT = read_float("Ping timeout (s)", 1.0)
RECHECK_INTERVAL_MIN = read_int("Recheck interval (min, 0=off)", 5)
GREEN_MAX_MS = read_int("Max ping for GREEN", 100)
YELLOW_MAX_MS = read_int("Max ping for YELLOW", 300)
RED_MIN_MS = 1
RED_MAX_MS = 300

MAX_WORKERS = 40
FAST_GROUP_LIMIT = 10
STABLE_GROUP_LIMIT = 10

# -------------------- helpers --------------------
_used_names = set()
def uniq_name(base): 
    base = re.sub(r"[^A-Za-z0-9_\- .]", "", str(base)) or "Proxy"
    name = base; i = 2
    while name in _used_names: name = f"{base} {i}"; i += 1
    _used_names.add(name); return name
def tail(s, n=6): return re.sub(r"[-]","", s)[-n:] if s else ""
def b64fix(s): s=s.strip().replace("\n","").replace(" ",""); return s + "="*(4-len(s)%4) if len(s)%4 else s
def tcp_ping_once(host,port,timeout=PING_TIMEOUT):
    try:
        start=time.monotonic()
        sock=socket.create_connection((host,int(port)),timeout=timeout); sock.close()
        return int((time.monotonic()-start)*1000)
    except: return None
def tcp_ping_median(host,port,attempts=PING_ATTEMPTS,timeout=PING_TIMEOUT,gap=0.08):
    vals=[v for _ in range(max(1,attempts)) if (v:=tcp_ping_once(host,port,timeout)) is not None or time.sleep(gap) is None]
    if not vals: return None
    vals.sort(); mid=len(vals)//2
    return vals[mid] if len(vals)%2 else int((vals[mid-1]+vals[mid])/2)
def extract_json_objects(text):
    objs,stack,start=[],[],None
    for i,c in enumerate(text):
        if c=='{': start=i if not stack else start; stack.append(c)
        elif c=='}' and stack: stack.pop(); 
        if not stack and start is not None: objs.append(text[start:i+1]); start=None
    return objs
def categorize_ping(ping):
    if ping<RED_MIN_MS or ping>RED_MAX_MS: return None
    if ping<=GREEN_MAX_MS: return "green"
    if ping<=YELLOW_MAX_MS: return "yellow"
    return None

# -------------------- read input --------------------
try: content=open(INPUT_PATH,"r",encoding="utf-8").read()
except: content=""

proxies=[]

# -------------------- parse JSON --------------------
for frag in extract_json_objects(content):
    try: obj=json.loads(frag)
    except: continue
    for ob in obj.get("outbounds",[]):
        proto=(ob.get("protocol") or "").lower()
        if proto not in ("vless","vmess","trojan","shadowsocks"): continue
        stream=ob.get("streamSettings") or {}; net=(stream.get("network") or "tcp").lower()
        security=(stream.get("security") or "").lower(); tls_flag=security in ("tls","reality")
        if proto in ("vless","vmess"):
            try: vnext=(ob.get("settings") or {}).get("vnext",[{}])[0]; user=(vnext.get("users") or [{}])[0]
            except: continue
            server=vnext.get("address",""); port=int(vnext.get("port",0)); uid=user.get("id","")
            if not(server and port and uid): continue
            name=uniq_name(f"{proto}-{server}-{tail(uid)}")
            p={"name":name,"type":proto,"server":server,"port":port,"udp":True,"network":net}
            if proto=="vless": p.update({"uuid":uid,"encryption":"none"})
            else: p.update({"uuid":uid,"alterId":int(user.get("alterId",user.get("aid",0))),"cipher":user.get("cipher","auto")})
            if tls_flag: sni=(stream.get("tlsSettings") or {}).get("serverName") or server; p.update({"tls":True,"servername":sni})
            if net=="ws": ws=stream.get("wsSettings") or {}; p["ws-opts"]={"path":ws.get("path","/")}; headers=ws.get("headers"); 
            if net=="ws" and headers: p["ws-opts"]["headers"]=headers
            proxies.append(p)
        elif proto=="trojan":
            try: s=(ob.get("settings") or {}).get("servers",[{}])[0]
            except: continue
            server=s.get("address",""); port=int(s.get("port",0)); pwd=s.get("password","")
            if not(server and port and pwd): continue
            name=uniq_name(f"trojan-{server}-{tail(pwd)}"); p={"name":name,"type":"trojan","server":server,"port":port,"password":pwd,"udp":True,"network":"tcp"}
            if tls_flag: p.update({"tls":True,"sni":server})
            proxies.append(p)
        elif proto=="shadowsocks":
            try: s=(ob.get("settings") or {}).get("servers",[{}])[0]
            except: continue
            server=s.get("address",""); port=int(s.get("port",0)); cipher=s.get("method") or s.get("cipher",""); password=s.get("password","")
            if not(server and port and cipher and password): continue
            name=uniq_name(f"ss-{server}-{port}"); proxies.append({"name":name,"type":"ss","server":server,"port":port,"cipher":cipher,"password":password,"udp":True})

# -------------------- parse inline links --------------------
for line in [ln.strip() for ln in content.splitlines() if ln.strip() and not ln.startswith("{")]:
    try:
        if line.startswith("vless://"):
            parsed=urlparse(line); uid=parsed.username or ""; host=parsed.hostname or ""; port=parsed.port or 443
            q=parse_qs(parsed.query); net=(q.get("type",["tcp"])[0]).lower()
            if not(uid and host and port): continue
            name=uniq_name(f"vless-{host}-{tail(uid)}"); p={"name":name,"type":"vless","server":host,"port":port,"uuid":uid,"encryption":"none","udp":True,"network":net}
            if net=="ws": p["ws-opts"]={"path":q.get("path",["/"])[0]}; hosth=q.get("host",[]) or q.get("Host",[]); 
            if net=="ws" and hosth: p["ws-opts"]["headers"]={"Host":hosth[0]}
            if (q.get("security",[""])[0]).lower() in ("tls","reality"): p.update({"tls":True,"servername":(q.get("sni",[]) or [host])[0]})
            proxies.append(p)
        elif line.startswith("vmess://"):
            decoded=json.loads(base64.b64decode(b64fix(line[8:])).decode(errors="ignore"))
            host=decoded.get("add",""); port=int(decoded.get("port",0)); uid=decoded.get("id","")
            if not(host and port and uid): continue
            net=(decoded.get("net") or "tcp").lower(); tls_flag=str(decoded.get("tls","")).lower()=="tls"
            name=uniq_name(f"vmess-{host}-{tail(uid)}")
            p={"name":name,"type":"vmess","server":host,"port":port,"uuid":uid,"alterId":int(decoded.get("aid",0)),"cipher":decoded.get("scy","auto"),"udp":True,"network":net}
            if net=="ws": p["ws-opts"]={"path":decoded.get("path","/")}; hosth=decoded.get("host",""); 
            if net=="ws" and hosth: p["ws-opts"]["headers"]={"Host":hosth}
            if tls_flag: p.update({"tls":True,"servername":decoded.get("sni") or host})
            proxies.append(p)
        elif line.startswith("trojan://"):
            parsed=urlparse(line); pwd=parsed.username or ""; host=parsed.hostname or ""; port=parsed.port or 443
            q=parse_qs(parsed.query); sni=q.get("sni",[host])[0]
            if not(pwd and host and port): continue
            name=uniq_name(f"trojan-{host}-{tail(pwd)}"); proxies.append({"name":name,"type":"trojan","server":host,"port":port,"password":pwd,"udp":True,"network":"tcp","tls":True,"sni":sni})
        elif line.startswith("ss://"):
            try:
                after=line[5:]
                if "@" in after and ":" in after.split("@",1)[0]:
                    method,password=after.split("@",1)[0].split(":",1)
                    host,port=after.split("@",1)[1].split("#",1)[0].rsplit(":",1)
                else:
                    b64cred,rest=after.split("@",1)
                    method,password=base64.urlsafe_b64decode(b64fix(b64cred)).decode().split(":",1)
                    host,port=rest.split("#",1)[0].rsplit(":",1)
                proxies.append({"name":uniq_name(f"ss-{host}-{port}"),"type":"ss","server":host.strip(),"port":int(port.strip()),"cipher":method.strip(),"password":password.strip(),"udp":True})
            except: continue
    except: continue

# -------------------- remove duplicates --------------------
seen=set(); unique=[]
for p in proxies:
    key=(p.get("type"),p.get("server"),p.get("port"))
    if key not in seen: seen.add(key); unique.append(p)
proxies=unique

# -------------------- ping measurement --------------------
results=[]
if proxies:
    with ThreadPoolExecutor(max_workers=min(MAX_WORKERS,len(proxies))) as ex:
        futs={ex.submit(tcp_ping_median,p["server"],p["port"],PING_ATTEMPTS,PING_TIMEOUT,0.08):p for p in proxies}
        for fut in as_completed(futs):
            p = futs[fut]
            try:
                ping=fut.result()
            except:
                ping=None
            p["ping"]=ping; p["status"]="ok" if ping is not None else "dead"
            cat=categorize_ping(ping) if ping is not None else None
            if cat: p["category"]=cat; results.append(p)
final_proxies=results

# -------------------- group proxies --------------------
fast=[p for p in final_proxies if p.get("category")=="green"][:FAST_GROUP_LIMIT]
stable=[p for p in final_proxies if p.get("category")=="yellow"][:STABLE_GROUP_LIMIT]
all_names=[p["name"] for p in final_proxies]
fast_names=[p["name"] for p in fast] or all_names[:1]
stable_names=[p["name"] for p in stable] or all_names[:1]
def ensure_nonempty(lst): return lst if lst else ["No proxies"]

# -------------------- config --------------------
config={
    "proxies": final_proxies,
    "proxy-groups":[
        {"name":"Manual","type":"select","proxies":["Auto","Stable","Fast","PreciseFallback","DIRECT"]+all_names},
        {"name":"Auto","type":"url-test","url":"https://www.gstatic.com/generate_204","interval":max(60,RECHECK_INTERVAL_MIN*60),"tolerance":50,"proxies":all_names},
        {"name":"Stable","type":"select","proxies":ensure_nonempty(stable_names)},
        {"name":"Fast","type":"select","proxies":ensure_nonempty(fast_names)},
        {"name":"PreciseFallback","type":"fallback","url":"https://www.gstatic.com/generate_204","interval":max(60,RECHECK_INTERVAL_MIN*60),"timeout":3,"tolerance":50,"proxies":ensure_nonempty(all_names)}
    ],
    "rules":["MATCH,Manual"]
}

# -------------------- save YAML --------------------
with open(OUT_PATH,"w",encoding="utf-8") as f: yaml.safe_dump(config,f,allow_unicode=True,sort_keys=False)

# -------------------- ping history & recheck loop --------------------
ping_history={p["name"]:deque([p["ping"]]*3,maxlen=8) for p in fast+stable}

def recheck_loop():
    if RECHECK_INTERVAL_MIN<=0: return
    interval=RECHECK_INTERVAL_MIN*60
    while True:
        try:
            candidates=fast+stable
            if not candidates: time.sleep(interval); continue
            with ThreadPoolExecutor(max_workers=min(MAX_WORKERS,len(candidates))) as ex:
                futs={ex.submit(tcp_ping_median,p["server"],p["port"],max(1,min(PING_ATTEMPTS,7)),PING_TIMEOUT,0.03):p for p in candidates}
                for fut in as_completed(futs):
                    p = futs[fut]; name=p["name"]
                    try:
                        ping=fut.result()
                    except: ping=None
                    ping_history.setdefault(name,deque(maxlen=8)).append(ping if ping is not None else 999999)
            # update fallback order
            ordered=sorted(candidates,key=lambda x: sum(ping_history.get(x["name"],[999999]))/len(ping_history.get(x["name"],[999999])))
            fb=[p["name"] for p in ordered]
            for g in config["proxy-groups"]:
                if g["name"]=="PreciseFallback": g["proxies"]=fb; break
            with open(OUT_PATH,"w",encoding="utf-8") as f: yaml.safe_dump(config,f,allow_unicode=True,sort_keys=False)
        except: time.sleep(interval)
        time.sleep(interval)

if RECHECK_INTERVAL_MIN and (fast or stable):
    threading.Thread(target=recheck_loop,daemon=True).start()

# Clear input
with open(INPUT_PATH,"w",encoding="utf-8"): pass

print(f"[✅] Saved {len(final_proxies)} proxies to {OUT_PATH}")

