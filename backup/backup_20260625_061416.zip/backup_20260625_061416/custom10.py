#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import copy
import tempfile
from urllib.parse import urlparse, parse_qs, unquote

# ================= COLOR =================
G = "\033[92m"
Y = "\033[93m"
R = "\033[91m"
C = "\033[96m"
W = "\033[0m"

# ================= BASE CONFIG =================
BASE = {
    "remarks": "CUSTOM-CONFIG",
    "outbounds": [
        {
            "protocol": "trojan",
            "settings": {
                "servers": [
                    {
                        "address": "",
                        "port": 0,
                        "password": ""
                    }
                ]
            },
            "streamSettings": {
                "network": "ws",
                "security": "tls",
                "wsSettings": {
                    "path": "/",
                    "headers": {
                        "Host": ""
                    }
                },
                "tlsSettings": {
                    "serverName": ""
                }
            }
        }
    ]
}

# ================= PARSER =================
def parse(link):
    u = urlparse(link)
    q = parse_qs(u.query)

    return {
        "scheme": u.scheme,
        "address": u.hostname,
        "port": u.port,
        "user": u.username,
        "password": u.username or "",
        "host": q.get("host", [""])[0] or q.get("sni", [""])[0] or "",
        "sni": q.get("sni", [""])[0] or q.get("host", [""])[0] or "",
        "path": unquote(q.get("path", ["/"])[0])
    }

# ================= BUILDER =================
def build(link):
    d = parse(link)
    cfg = copy.deepcopy(BASE)

    s = cfg["outbounds"][0]["settings"]["servers"][0]
    st = cfg["outbounds"][0]["streamSettings"]

    # PURE REPLACE ONLY
    s["address"] = d["address"]
    s["port"] = d["port"]
    s["password"] = d["password"]

    st["wsSettings"]["path"] = d["path"]
    st["wsSettings"]["headers"]["Host"] = d["host"]
    st["tlsSettings"]["serverName"] = d["sni"]

    # protocol hint (optional only)
    cfg["outbounds"][0]["protocol"] = d["scheme"] if d["scheme"] else "trojan"

    return cfg

# ================= NANO MODE =================
def nano_input():
    print(f"{Y}[NANO MODE]{W} Paste configs, empty line to finish:\n")

    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, "w") as f:
        while True:
            line = input()
            if line.strip() == "":
                break
            f.write(line + "\n")

    with open(path, "r") as f:
        data = f.read()

    os.remove(path)
    return [x.strip() for x in data.splitlines() if x.strip()]

# ================= MENU =================
def menu():
    print(f"""
{C}==============================
   CUSTOM CONVERTER TOOL
=============================={W}

{G}1){W} Single Paste
{G}2){W} Nano Mode
{R}0){W} Exit
""")

    return input(f"{Y}Select > {W}").strip()

# ================= MAIN =================
while True:
    c = menu()

    if c == "0":
        break

    elif c == "1":
        link = input("Paste link:\n> ").strip()
        out = build(link)
        print("\n===== OUTPUT =====\n")
        print(json.dumps(out, ensure_ascii=False, indent=2))

    elif c == "2":
        links = nano_input()
        print("\n===== OUTPUTS =====\n")
        for l in links:
            try:
                out = build(l)
                print(json.dumps(out, ensure_ascii=False, indent=2))
                print()
            except:
                pass

    input(f"{C}\nPress ENTER to continue...{W}")
