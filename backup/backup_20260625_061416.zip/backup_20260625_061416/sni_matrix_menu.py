import socket
import ssl
import os
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

TIMEOUT = 3

G = "\033[92m"
R = "\033[91m"
Y = "\033[93m"
C = "\033[96m"
W = "\033[0m"


TARGET_FILE = "targets.txt"


def clear():
    os.system("clear")


def load_targets():
    with open(TARGET_FILE, "r") as f:
        lines = [l.strip() for l in f if l.strip()]

    if "###" not in lines:
        print(f"{R}[ERROR] Missing ### in targets.txt{W}")
        exit()

    idx = lines.index("###")
    ips = lines[:idx]
    snis = lines[idx+1:]

    return ips, snis


def test(ip, sni):
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        with socket.create_connection((ip, 443), timeout=TIMEOUT) as sock:
            with ctx.wrap_socket(sock, server_hostname=sni) as ssock:
                ssock.send(b"GET / HTTP/1.1\r\nHost: test\r\n\r\n")
                ssock.recv(64)

        return ip, sni, True
    except:
        return ip, sni, False


def run_scan():
    ips, snis = load_targets()

    print(f"{C}[INFO]{W} IPs : {len(ips)}")
    print(f"{C}[INFO]{W} SNIs: {len(snis)}")
    print(f"{Y}[START SCAN]{W}\n")

    ok = []

    with ThreadPoolExecutor(max_workers=150) as ex:
        futures = [ex.submit(test, ip, sni) for ip in ips for sni in snis]

        for f in as_completed(futures):
            ip, sni, res = f.result()

            if res:
                ok.append((ip, sni))
                print(f"{G}[OK]{W} {ip} -> {sni}")
            else:
                print(f"{R}[FAIL]{W} {ip} -> {sni}")

    save_output(ok)


def edit_targets():
    os.system(f"nano {TARGET_FILE}")


def save_output(ok):
    base_dir = "/storage/emulated/0/Download/SNI_RESULTS"
    os.makedirs(base_dir, exist_ok=True)

    time = datetime.now().strftime("%Y%m%d-%H%M%S")
    file_path = f"{base_dir}/result_{time}.txt"

    with open(file_path, "w") as f:
        for ip, sni in ok:
            f.write(f"{ip}\n{sni}\n\n")

    print(f"\n{Y}[SAVED]{W} {file_path}\n")


def menu():
    while True:
        clear()
        print(f"{C}===== SNI MATRIX MENU ====={W}\n")
        print(f"{G}1{W} - Run Scanner")
        print(f"{G}2{W} - Edit Targets")
        print(f"{R}3{W} - Exit\n")

        choice = input(f"{Y}Select: {W}")

        if choice == "1":
            run_scan()
            input("\nPress Enter...")
        elif choice == "2":
            edit_targets()
        elif choice == "3":
            break
        else:
            print("Invalid!")


if __name__ == "__main__":
    menu()
