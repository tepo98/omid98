import socket
import time
import threading
from concurrent.futures import ThreadPoolExecutor
from flask import Flask, jsonify, render_template_string

# ================= CONFIG =================
INPUT_FILE = "ips.txt"
PORTS = [443, 8443, 2053, 2083, 2087, 2096]
THREADS = 100
TEST_COUNT = 3
MAX_LATENCY = 300

app = Flask(__name__)

results = []
lock = threading.Lock()

# ================= CORE TEST =================
def tcp_test(ip, port):
    try:
        start = time.time()
        s = socket.socket()
        s.settimeout(1)
        s.connect((ip, port))
        s.close()
        return (time.time() - start) * 1000
    except:
        return None


def multi_test(ip):
    latencies = []
    success = 0

    for _ in range(TEST_COUNT):
        for port in PORTS:
            r = tcp_test(ip, port)
            if r:
                latencies.append(r)
                success += 1

    if not latencies:
        return None

    avg = sum(latencies) / len(latencies)
    jitter = max(latencies) - min(latencies)
    loss = 1 - (success / (TEST_COUNT * len(PORTS)))

    score = 1000 - avg - (jitter * 2) - (loss * 200)

    return {
        "ip": ip,
        "avg": round(avg, 2),
        "jitter": round(jitter, 2),
        "loss": round(loss, 2),
        "score": round(score, 2)
    }


# ================= SCAN =================
def worker(ip):
    global results
    r = multi_test(ip)

    if r:
        with lock:
            results.append(r)
        print(f"[OK] {r['ip']} {r['avg']}ms Score:{r['score']}")
    else:
        print(f"[FAIL] {ip}")


def start_scan():
    with open(INPUT_FILE) as f:
        ips = [i.strip().split(":")[0] for i in f if i.strip()]

    with ThreadPoolExecutor(max_workers=THREADS) as ex:
        ex.map(worker, ips)


# ================= WEB UI =================
HTML = """
<html>
<head>
<title>scanner20 PRO</title>
<style>
body{background:#000;color:#0f0;font-family:monospace}
table{width:100%}
th,td{padding:5px;border:1px solid #0f0}
</style>
</head>
<body>
<h2>⚡ SCANNER20 PRO</h2>
<table>
<tr><th>IP</th><th>MS</th><th>Jitter</th><th>Loss</th><th>Score</th></tr>
{% for r in data %}
<tr>
<td>{{r.ip}}</td>
<td>{{r.avg}}</td>
<td>{{r.jitter}}</td>
<td>{{r.loss}}</td>
<td>{{r.score}}</td>
</tr>
{% endfor %}
</table>
</body>
</html>
"""


@app.route("/")
def home():
    sorted_data = sorted(results, key=lambda x: x["score"], reverse=True)[:100]
    return render_template_string(HTML, data=sorted_data)


@app.route("/api")
def api():
    return jsonify(sorted(results, key=lambda x: x["score"], reverse=True)[:100])


# ================= RUN =================
if __name__ == "__main__":
    print("SCANNER20 PRO STARTED")
    threading.Thread(target=start_scan).start()
    app.run(host="127.0.0.1", port=5000)
