import socket
import time
import threading
from concurrent.futures import ThreadPoolExecutor
import subprocess

# ===== SETTINGS =====
INPUT_FILE = "ips.txt"
PORTS = [443, 8443, 2053, 2083, 2087, 2096]
THREADS = 80
TIMEOUT = 1
TOP = 100
MAX_LATENCY = 250

# ===== COLORS =====
G = "\033[1;32m"
R = "\033[1;31m"
Y = "\033[1;33m"
C = "\033[1;36m"
W = "\033[0m"

lock = threading.Lock()
results = []

# ===== LOAD IPS =====
def load_ips():
    ips = []
    with open(INPUT_FILE, "r") as f:
        for line in f:
            ip = line.strip()
            if ":" in ip:
                ip = ip.split(":")[0]
            if ip:
                ips.append(ip)
    return list(set(ips))

# ===== TCP TEST =====
def test_port(ip, port):
    try:
        s = socket.socket()
        s.settimeout(TIMEOUT)

        t1 = time.time()
        s.connect((ip, port))
        s.close()
        t2 = time.time()

        ms = int((t2 - t1) * 1000)
        return ms
    except:
        return None

# ===== SCAN IP =====
def scan_ip(ip):
    latencies = []

    for port in PORTS:
        ms = test_port(ip, port)
        if ms:
            latencies.append(ms)

    if not latencies:
        print(f"{R}[FAIL]{W} {ip}")
        return

    avg = sum(latencies) // len(latencies)
    jitter = max(latencies) - min(latencies)
    score = 1000 - avg - (jitter * 2)

    if avg <= MAX_LATENCY:
        with lock:
            results.append((score, avg, ip))
        print(f"{G}[OK]{W} {ip} {avg}ms score:{score}")
    else:
        print(f"{Y}[SLOW]{W} {ip} {avg}ms")

# ===== EXPORT =====
def export():
    results.sort(reverse=True)

    clean = [x[2] for x in results[:TOP]]
    port = [f"{x[2]}:443" for x in results[:TOP]]

    open("clean.txt", "w").write("\n".join(clean))
    open("port.txt", "w").write("\n".join(port))

    print(f"\n{C}[+] Saved clean.txt & port.txt{W}")

    # clipboard
    subprocess.run("termux-clipboard-set < clean.txt", shell=True)
    print(f"{G}[+] Clean copied to clipboard{W}")

# ===== MAIN =====
def main():
    ips = load_ips()

    print(f"{C}Starting scanner... {len(ips)} IPs{W}\n")

    with ThreadPoolExecutor(max_workers=THREADS) as ex:
        ex.map(scan_ip, ips)

    export()

    print(f"\n{G}[DONE] TOP RESULTS:{W}")
    for s, ms, ip in results[:TOP]:
        print(f"{ip} | {ms}ms | score:{s}")

if __name__ == "__main__":
    main()
