#!/data/data/com.termux/files/usr/bin/bash

DIR="/storage/emulated/0/Download/html"
PORT=8000

cd "$DIR" || {
  echo -e "\e[31mFolder not found: $DIR\e[0m"
  exit 1
}

clear
echo -e "\e[36m====================================\e[0m"
echo -e "\e[33m      HTML LAUNCHER PRO (SEARCH)    \e[0m"
echo -e "\e[36m====================================\e[0m"
echo ""

# گرفتن فایل‌ها
files=(*.html)

if [ ! -e "${files[0]}" ]; then
  echo -e "\e[31mNo HTML files found!\e[0m"
  exit 1
fi

# لیست اولیه
function show_list() {
  clear
  echo -e "\e[36m========== HTML FILES ==========\e[0m"
  echo ""

  i=1
  for f in "${filtered[@]}"; do
    echo -e "\e[32m[$i]\e[0m \e[37m$f\e[0m"
    ((i++))
  done

  echo ""
}

# پیش‌فرض همه فایل‌ها
filtered=("${files[@]}")

# سرچ
echo -ne "\e[34mSearch (press Enter for all): \e[0m"
read query

if [ -n "$query" ]; then
  filtered=()
  for f in "${files[@]}"; do
    if [[ "$f" == *"$query"* ]]; then
      filtered+=("$f")
    fi
  done
fi

if [ ${#filtered[@]} -eq 0 ]; then
  echo -e "\e[31mNo match found!\e[0m"
  exit 1
fi

show_list

# انتخاب
echo -ne "\e[34mSelect number: \e[0m"
read choice

index=$((choice-1))
selected="${filtered[$index]}"

if [ -z "$selected" ]; then
  echo -e "\e[31mInvalid selection!\e[0m"
  exit 1
fi

echo ""
echo -e "\e[32m[+] Selected: $selected\e[0m"

# اجرای سرور
echo -e "\e[33m[+] Starting local server...\e[0m"
python -m http.server $PORT > /dev/null 2>&1 &

sleep 2

URL="http://127.0.0.1:$PORT/$selected"

echo -e "\e[36m[+] Opening browser...\e[0m"
echo -e "\e[37m$URL\e[0m"

termux-open-url "$URL"
