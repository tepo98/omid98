import requests
import ipaddress
import time
import threading
from concurrent.futures import ThreadPoolExecutor
from rich import print
from rich.console import Console

console = Console()

# ================== STATE ==================
alive = []
dead = []
tested = 0
lock = threading.Lock()

# ================== CONFIG ==================
timeout = 3
threads = 25


# ================== CORE CHECK ==================
def check_ip(ip):
    global tested

    try:
        start = time.time()
        r = requests.get(f"http://{ip}", timeout=timeout)
        latency = int((time.time() - start) * 1000)

        with lock:
            alive.append((str(ip), latency))
            tested += 1
            console.print(f"[green]✔ LIVE[/green] {ip} {latency}ms")

    except:
        with lock:
            dead.append(str(ip))
            tested += 1
            console.print(f"[red]✘ DEAD[/red] {ip}")


# ================== PARSE INPUT ==================
def expand_input(data):
    ips = set()

    for line in data.splitlines():
        line = line.strip()
        if not line:
            continue

        # CIDR
        if "/" in line:
            try:
                net = ipaddress.ip_network(line, strict=False)
                for ip in net.hosts():
                    ips.add(str(ip))
            except:
                pass

        # RANGE
        elif "-" in line:
            try:
                start, end = line.split("-")
                start_ip = ipaddress.IPv4Address(start.strip())
                end_ip = ipaddress.IPv4Address(end.strip())

                for ip_int in range(int(start_ip), int(end_ip) + 1):
                    ips.add(str(ipaddress.IPv4Address(ip_int)))
            except:
                pass

        # SINGLE IP
        else:
            try:
                ipaddress.IPv4Address(line)
                ips.add(line)
            except:
                pass

    return list(ips)


# ================== SCAN ==================
def scan(ips):
    global tested, alive, dead

    alive = []
    dead = []
    tested = 0

    print(f"\n[cyan]🚀 Starting scan on {len(ips)} IPs (tepo98 Scanner)[/cyan]\n")

    with ThreadPoolExecutor(max_workers=threads) as exe:
        exe.map(check_ip, ips)

    print("\n[bold green]====== RESULT ======[/bold green]")
    print(f"[green]Alive:[/green] {len(alive)}")
    print(f"[red]Dead:[/red] {len(dead)}")

    if alive:
        alive.sort(key=lambda x: x[1])
        print("\n[cyan]TOP FAST IPs:[/cyan]")
        for ip, lat in alive[:10]:
            print(f"[green]{ip}[/green] -> {lat}ms")


# ================== MENU ==================
def menu():
    print("\n[bold blue]==== TEPO98 SCANNER ====[/bold blue]")
    print("1) Start Scan")
    print("2) Settings")
    print("3) Exit")
    return input("Select: ")


# ================== SETTINGS ==================
def settings():
    global timeout, threads

    timeout = int(input("Timeout (sec): "))
    threads = int(input("Threads (recommended 10-50): "))

    print("[green]✔ Settings saved[/green]")


# ================== MAIN ==================
while True:
    choice = menu()

    if choice == "1":
        print("\nPaste IP / CIDR / Range (empty line to start):")

        data = ""
        while True:
            line = input()
            if line == "":
                break
            data += line + "\n"

        ips = expand_input(data)

        if not ips:
            print("[red]No valid IP found[/red]")
            continue

        scan(ips)

    elif choice == "2":
        settings()

    elif choice == "3":
        print("Bye 👋")
        break
