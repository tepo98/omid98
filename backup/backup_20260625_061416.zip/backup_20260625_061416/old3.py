#!/data/data/com.termux/files/usr/bin/python3
# -*- coding: utf-8 -*-

import os, re, json, base64, socket, time, subprocess
from urllib.parse import urlparse, parse_qs
from concurrent.futures import ThreadPoolExecutor, as_completed
import yaml

# ================== مسیرها ==================
BASE_DIR = "/storage/emulated/0/Download/Akbar98"
os.makedirs(BASE_DIR, exist_ok=True)
INPUT_PATH = os.path.join(BASE_DIR, "input.txt")

# ایجاد فایل ورودی برای ویرایش
with open(INPUT_PATH, "w", encoding="utf-8") as f:
    f.write("")
subprocess.call(["nano", INPUT_PATH])

out_folder = input("Enter output folder name in Download: ").strip()
if not out_folder:
    print("Folder name required."); raise SystemExit(1)
OUT_DIR = os.path.join("/storage/emulated/0/Download", out_folder)
os.makedirs(OUT_DIR, exist_ok=True)

out_name = input("Enter output file name (without extension): ").strip()
if not out_name:
    print("File name required."); raise SystemExit(1)
OUT_PATH = os.path.join(OUT_DIR, f"{out_name}.yaml")

# ================== توابع کمکی ==================
def b64fix(s: str) -> str:
    s = (s or "").strip().replace("\n","").replace(" ","")
    pad = len(s) % 4
    if pad: s += "=" * (4 - pad)
    return s

def safe_int(x, default=0):
    try:
        return int(x)
    except:
        return default

def sanitize(s: str) -> str:
    if not s: return ""
    return re.sub(r"[^A-Za-z0-9_\- .]", "", str(s)).strip()

_used_names = set()
def uniq_name(base: str) -> str:
    base = sanitize(base) or "Proxy"
    name = base
    i = 2
    while name in _used_names:
        name = f"{base} {i}"
        i += 1
    _used_names.add(name)
    return name

def tail(s: str, n=6):
    if not s: return ""
    s2 = re.sub(r"[-]","",s)
    return s2[-n:] if len(s2) >= n else s2

# ======= TCP پینگ پایدار =======
def tcp_ping_once(host, port, timeout=0.8):
    try:
        t0 = time.monotonic()
        sock = socket.create_connection((host, int(port)), timeout=timeout)
        sock.close()
        return int((time.monotonic() - t0) * 1000)
    except:
        return None

def tcp_ping_median(host, port, attempts=5, timeout=0.8):
    vals = []
    for _ in range(attempts):
        v = tcp_ping_once(host, port, timeout=timeout)
        if v is not None:
            vals.append(v)
    if not vals:
        return None
    vals.sort()
    mid = len(vals)//2
    return vals[mid] if len(vals)%2==1 else int((vals[mid-1]+vals[mid])/2)

def attach_ping(proxy):
    host = proxy.get("server") or ""
    port = proxy.get("port") or 0
    if not host or not port:
        proxy["ping"] = None
        proxy["status"] = "dead"
        return proxy
    lat = tcp_ping_median(host, port)
    if lat is None:
        proxy["ping"] = None
        proxy["status"] = "dead"
    else:
        proxy["ping"] = int(lat)
        proxy["status"] = "ok"
    return proxy

# ======= استخراج JSON =======
def extract_json_objects(text):
    objs, stack, start = [], [], None
    for i, c in enumerate(text):
        if c == '{':
            if not stack: start = i
            stack.append(c)
        elif c == '}':
            if stack:
                stack.pop()
                if not stack and start is not None:
                    objs.append(text[start:i+1])
                    start = None
    return objs

# ================== خواندن ورودی ==================
try:
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        content = f.read()
except:
    content = ""

proxies = []

# ================== پردازش JSON ==================
for frag in extract_json_objects(content):
    try:
        obj = json.loads(frag)
    except:
        continue
    outbounds = obj.get("outbounds") or []
    for ob in outbounds:
        proto = (ob.get("protocol") or "").lower()
        if proto not in ("vless","vmess","trojan","shadowsocks"):
            continue
        stream = ob.get("streamSettings") or {}
        net = (stream.get("network") or "tcp").lower()
        security = (stream.get("security") or "").lower()
        tls_flag = security in ("tls","reality")

        if proto in ("vless","vmess"):
            try:
                vnext = (ob.get("settings") or {}).get("vnext", [])[0]
                user = (vnext.get("users") or [])[0]
            except:
                continue
            server = vnext.get("address") or ""
            port = safe_int(vnext.get("port"), 0)
            uid = user.get("id") or ""
            if not (server and port and uid):
                continue
            base = f"{proto}-{server}-{tail(uid)}"
            name = uniq_name(base)
            p = {"name": name, "type": proto, "server": server, "port": port, "udp": True, "network": net}
            if proto == "vless":
                p["uuid"] = uid
                p["encryption"] = "none"
            else:
                p["uuid"] = uid
                p["alterId"] = safe_int(user.get("alterId", user.get("aid", 0)))
                p["cipher"] = user.get("cipher", "auto")
            if tls_flag:
                sni = (stream.get("tlsSettings") or {}).get("serverName") \
                      or (stream.get("realitySettings") or {}).get("serverName") \
                      or server
                p["tls"] = True
                p["sni"] = sni
                p["servername"] = sni
            if net == "ws":
                ws = stream.get("wsSettings") or {}
                path = ws.get("path") or "/"
                headers = ws.get("headers") or {}
                p["ws-opts"] = {"path": path}
                if headers:
                    p["ws-opts"]["headers"] = headers
            elif net == "grpc":
                grpc = stream.get("grpcSettings") or {}
                svc = grpc.get("serviceName") or ""
                if svc:
                    p["grpc-opts"] = {"grpc-service-name": svc}
            proxies.append(p)

        elif proto == "trojan":
            try:
                s = (ob.get("settings") or {}).get("servers", [])[0]
            except:
                continue
            server = s.get("address") or ""
            port = safe_int(s.get("port"), 0)
            pwd = s.get("password") or ""
            if not (server and port and pwd):
                continue
            name = uniq_name(f"trojan-{server}-{tail(pwd)}")
            p = {
                "name": name,
                "type": "trojan",
                "server": server,
                "port": port,
                "password": pwd,
                "udp": True,
                "network": "tcp",
                "tls": tls_flag,
                "sni": server,
                "servername": server
            }
            proxies.append(p)

        elif proto == "shadowsocks":
            try:
                s = (ob.get("settings") or {}).get("servers", [])[0]
            except:
                continue
            server = s.get("address") or ""
            port = safe_int(s.get("port"), 0)
            cipher = s.get("method") or s.get("cipher") or ""
            password = s.get("password") or ""
            if not (server and port and cipher and password):
                continue
            name = uniq_name(f"ss-{server}-{port}")
            p = {"name": name, "type": "ss", "server": server, "port": port, "cipher": cipher, "password": password, "udp": True}
            proxies.append(p)

# ================== پردازش لینک‌ها ==================
for line in [ln.strip() for ln in content.splitlines() if ln.strip() and not ln.strip().startswith("{")]:
    try:
        # vless://
        if line.startswith("vless://"):
            parsed = urlparse(line)
            uid = parsed.username or ""
            host = parsed.hostname or ""
            port = parsed.port or 443
            q = parse_qs(parsed.query)
            if not (uid and host and port):
                continue
            net = (q.get("type", ["tcp"])[0] or "tcp").lower()
            tls_flag = (q.get("security", [""])[0] or "").lower() in ("tls","reality")
            name = uniq_name(f"vless-{host}-{tail(uid)}")
            p = {"name": name, "type": "vless", "server": host, "port": port, "uuid": uid, "encryption": "none", "udp": True, "network": net}
            if net == "ws":
                p["ws-opts"] = {"path": q.get("path", ["/"])[0]}
                hosth = q.get("host", []) or q.get("Host", [])
                if hosth:
                    p["ws-opts"]["headers"] = {"Host": hosth[0]}
            elif net == "grpc":
                svc = q.get("serviceName", [""])[0]
                if svc:
                    p["grpc-opts"] = {"grpc-service-name": svc}
            if tls_flag:
                sni = (q.get("sni", []) or q.get("servername", []) or [host])[0]
                p["tls"] = True
                p["sni"] = sni
                p["servername"] = sni
            proxies.append(p)

        # vmess://
        elif line.startswith("vmess://"):
            payload = line[8:]
            try:
                decoded = base64.b64decode(b64fix(payload)).decode(errors="ignore")
                info = json.loads(decoded)
            except:
                continue
            host = info.get("add") or info.get("server") or ""
            port = safe_int(info.get("port"), 0)
            uid = info.get("id") or ""
            if not (host and port and uid):
                continue
            net = (info.get("net") or "tcp").lower()
            tls_flag = str(info.get("tls", "")).lower() == "tls"
            name = uniq_name(f"vmess-{host}-{tail(uid)}")
            p = {
                "name": name, "type": "vmess", "server": host, "port": port,
                "uuid": uid, "alterId": safe_int(info.get("aid", info.get("alterId", 0))),
                "cipher": info.get("scy", "auto"), "udp": True, "network": net
            }
            if net == "ws":
                path = info.get("path") or "/"
                p["ws-opts"] = {"path": path}
                hosth = info.get("host") or ""
                if hosth:
                    p["ws-opts"]["headers"] = {"Host": hosth}
            if tls_flag:
                sni = info.get("sni") or info.get("host") or host
                p["tls"] = True
                p["sni"] = sni
                p["servername"] = sni
            proxies.append(p)

        # trojan://
        elif line.startswith("trojan://"):
            parsed = url
