#!/bin/bash
clear

green='\e[1;32m'
cyan='\e[1;36m'
yellow='\e[1;33m'
reset='\e[0m'

echo -e "${cyan}========== CLEAN IP SCANNER ==========${reset}"
echo -e "${green}1) IPv4 Scan${reset}"
echo -e "${green}2) IPv6 Scan${reset}"
echo -e "${green}3) Export Clean IPs (deduplicate)${reset}"
echo -e "${cyan}=====================================${reset}"

read -p "Select option: " user_input


ipv4_scan() {
    echo "Scanning IPv4..."
    bash <(curl -fsSL https://raw.githubusercontent.com/Ptechgithub/warp/main/endip/install.sh) \
    | grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}'
}


ipv6_scan() {
    echo "Scanning IPv6..."
    bash <(curl -fsSL https://raw.githubusercontent.com/Ptechgithub/warp/main/endip/install.sh) \
    | grep -oE '([0-9a-fA-F:]+)'
}


clean_export() {
    echo "Paste IP list (CTRL+D to finish):"
    cat \
    | grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}|[0-9a-fA-F:]+' \
    | sort -u
}


case "$user_input" in
    1) ipv4_scan ;;
    2) ipv6_scan ;;
    3) clean_export ;;
    *) echo "Invalid option" ;;
esac
