#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import base64
import uuid
from urllib.parse import urlparse, parse_qs, unquote

# ================= TEMPLATE (FIXED - DO NOT CHANGE STRUCTURE) =================
TEMPLATE = {
    "remarks": "CUSTOM-CONFIG",
    "log": {
        "access": "",
        "error": "",
        "loglevel": "info",
        "dnsLog": False
    },
    "inbounds": [
        {
            "tag": "in_proxy",
            "port": 1080,
            "protocol": "socks",
            "listen": "0.0.0.0",
            "settings": {
                "auth": "noauth",
                "udp": True,
                "userLevel": 8
            },
            "sniffing": {
                "enabled": False
            }
        }
    ],
    "outbounds": [
        {
            "tag": "proxy",
            "protocol": "trojan",
            "settings": {
                "servers": [
                    {
                        "address": "",
                        "port": 0,
                        "password": ""
                    }
                ]
            },
            "streamSettings": {
                "network": "ws",
                "security": "tls",
                "wsSettings": {
                    "path": "/",
                    "headers": {
                        "Host": ""
                    }
                },
                "tlsSettings": {
                    "serverName": "",
                    "allowInsecure": True,
                    "alpn": ["http/1.1"],
                    "fingerprint": "ios"
                }
            }
        }
    ]
}

# ================= COLORS =================
G = "\033[92m"
B = "\033[94m"
Y = "\033[93m"
C = "\033[96m"
W = "\033[0m"

# ================= PARSER =================
def parse(link):
    u = urlparse(link)
    q = parse_qs(u.query)

    return {
        "address": u.hostname,
        "port": u.port,
        "password": u.username or "",
        "host": q.get("host", [""])[0] or q.get("sni", [""])[0] or "",
        "sni": q.get("sni", [""])[0] or q.get("host", [""])[0] or "",
        "path": unquote(q.get("path", ["/"])[0])
    }

# ================= BUILDER =================
def build(data):
    cfg = json.loads(json.dumps(TEMPLATE))

    srv = cfg["outbounds"][0]["settings"]["servers"][0]
    st = cfg["outbounds"][0]["streamSettings"]

    # فقط جایگزینی ساده
    srv["address"] = data["address"]
    srv["port"] = data["port"]
    srv["password"] = data["password"]

    host = data["host"] or data["sni"]
    sni = data["sni"] or data["host"]

    st["wsSettings"]["headers"]["Host"] = host
    st["tlsSettings"]["serverName"] = sni
    st["wsSettings"]["path"] = data["path"]

    return cfg

# ================= UI =================
print(C + "============================" + W)
print(G + "   CUSTOM CONFIG BUILDER   " + W)
print(C + "============================\n" + W)

print(Y + "1) Paste Mode" + W)
print(Y + "2) Nano Mode" + W)
print(Y + "0) Exit\n" + W)

mode = input(B + "Select > " + W).strip()

links = []

# ================= PASTE MODE =================
if mode == "1":
    print("\nPaste links (END to finish):")
    while True:
        x = input().strip()
        if x == "END":
            break
        links.append(x)

# ================= NANO MODE =================
elif mode == "2":
    tmp = f"/data/data/com.termux/files/home/tmp_{uuid.uuid4().hex}.txt"

    print("\nOpening nano editor...")

    with open(tmp, "w") as f:
        f.write("")

    os.system(f"nano {tmp}")

    if os.path.exists(tmp):
        with open(tmp, "r") as f:
            links = [i.strip() for i in f.readlines() if i.strip()]

    try:
        os.remove(tmp)
    except:
        pass

elif mode == "0":
    exit()

else:
    print("Invalid option")
    exit()

# ================= CHECK =================
if not links:
    print("NO INPUT FOUND")
    exit()

# ================= PROCESS =================
results = []

for l in links:
    data = parse(l)
    results.append(build(data))

# ================= OUTPUT (CLEAN ONLY) =================
print("\n")

for cfg in results:
    print(json.dumps(cfg, ensure_ascii=False))
    print()
