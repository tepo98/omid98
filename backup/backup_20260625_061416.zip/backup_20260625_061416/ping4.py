#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ==================== Imports ====================
import os
import re
import subprocess
from rich import print
from rich.table import Table
from rich.panel import Panel
from rich.console import Console

console = Console()

# ==================== Settings ====================
OUTPUT_FOLDER = "/storage/emulated/0/Download/almasi98"
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# ==================== Personal Ping Settings ====================
VALID_PING_MIN = 1
VALID_PING_MAX = 800
GOOD_THRESHOLD = 50
WARN_THRESHOLD = 200
TIMEOUT = 20.0
PING_COUNT = 10

console.print(Panel.fit(
    f"[bold magenta]Almasi98 Personal Ping Analyzer[/bold magenta]\n"
    f"[green]Custom precise preset activated[/green]\n"
    f"[cyan]Ping Range:[/cyan] {VALID_PING_MIN}-{VALID_PING_MAX} ms | "
    f"[cyan]GOOD:[/cyan] <{GOOD_THRESHOLD} | "
    f"[cyan]WARN:[/cyan] <{WARN_THRESHOLD} | "
    f"[cyan]Timeout:[/cyan] {TIMEOUT}s | [cyan]Count:[/cyan] {PING_COUNT}",
    title="[bold yellow]★ Ideal Personal Mode ★[/bold yellow]",
    border_style="bright_magenta"
))

# ==================== Helpers ====================
def extract_host(config: str):
    """Extract host from a config line"""
    m = re.search(r"@([^:/?#\s]+)", config)
    if m:
        return m.group(1)
    m = re.search(r"://([^:/?#\s]+)", config)
    return m.group(1) if m else None

def ping_host(host: str):
    """Ping host and return average ms or None"""
    try:
        output = subprocess.check_output(
            ["ping", "-c", str(PING_COUNT), "-W", str(int(TIMEOUT)), host],
            stderr=subprocess.DEVNULL
        ).decode()
        match = re.search(r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)", output)
        return float(match.group(1)) if match else None
    except Exception:
        return None

def classify_ping(avg_ms: float | None):
    """Return status string and colored label"""
    if avg_ms is None:
        return "bad", "[bold red][BAD][/bold red]"
    if avg_ms < GOOD_THRESHOLD:
        return "good", "[bold green][GOOD][/bold green]"
    if avg_ms < WARN_THRESHOLD:
        return "warn", "[bold yellow][WARN][/bold yellow]"
    return "bad", "[bold red][BAD][/bold red]"

# ==================== Main ====================
def main():
    # ---------- Input ----------
    print("[bold cyan]Enter your configs line by line (VLESS/Trojan/SS only). Ctrl+D when done:[/bold cyan]")
    configs = []
    while True:
        try:
            line = input()
            if line.strip():
                configs.append(line.strip())
        except EOFError:
            break

    if not configs:
        print("[bold red]No configs entered![/bold red]")
        return

    # ---------- Ping + Stats ----------
    good, warn, bad = [], [], []
    ping_results = {}
    protocol_count = {"vless":0, "trojan":0, "ss":0, "ignored":0}

    console.print("\n[bold magenta]Starting personal ping tests...[/bold magenta]\n")

    for cfg in configs:
        host = extract_host(cfg)
        if not host:
            protocol_count["ignored"] += 1
            print(f"[bold yellow]⚠ Ignored (invalid):[/bold yellow] {cfg}")
            continue
        ping = ping_host(host)
        status, label = classify_ping(ping)
        ping_results[cfg] = {"status": status, "ping": ping}
        color = {
            "good": "green",
            "warn": "yellow",
            "bad": "red"
        }.get(status, "white")
        if ping:
            console.print(f"[{color}]• {host:<35} → {label} {ping:.1f} ms[/]")
        else:
            console.print(f"[red]• {host:<35} → [BAD] No response[/red]")

        if status == "good":
            good.append(cfg)
        elif status == "warn":
            warn.append(cfg)
        else:
            bad.append(cfg)

        if cfg.startswith("vless://"):
            protocol_count["vless"] += 1
        elif cfg.startswith("trojan://"):
            protocol_count["trojan"] += 1
        elif cfg.startswith("ss://") or cfg.startswith("ssss://"):
            protocol_count["ss"] += 1

    # ---------- Summary Table ----------
    table = Table(title="[bold magenta]Configs Summary[/bold magenta]", border_style="bright_blue")
    table.add_column("[cyan]Category[/cyan]")
    table.add_column("[white]Count[/white]")
    table.add_row("[magenta]Total configs[/magenta]", str(len(configs)))
    table.add_row("[green]Green (GOOD)[/green]", str(len(good)))
    table.add_row("[yellow]Yellow (WARN)[/yellow]", str(len(warn)))
    table.add_row("[red]Red (BAD)[/red]", str(len(bad)))
    table.add_row("[blue]vless[/blue]", str(protocol_count["vless"]))
    table.add_row("[bright_yellow]trojan[/bright_yellow]", str(protocol_count["trojan"]))
    table.add_row("[bright_cyan]ss[/bright_cyan]", str(protocol_count["ss"]))
    table.add_row("[dim]Ignored/Invalid[/dim]", str(protocol_count["ignored"]))
    print(table)

    # ==================== Save & Menu Helpers ====================
    MENU_MAP = {
        "1": "vless",
        "2": "trojan",
        "3": "ss",
        "4": "green",
        "5": "green+yellow",
        "6": "all"
    }

    def filter_by_choice(choice_key: str, configs_list: list):
        if choice_key == "1":
            return [c for c in configs_list if c.startswith("vless://")]
        if choice_key == "2":
            return [c for c in configs_list if c.startswith("trojan://")]
        if choice_key == "3":
            return [c for c in configs_list if c.startswith("ss://") or c.startswith("ssss://")]
        if choice_key == "4":
            return [c for c in configs_list if ping_results.get(c, {}).get("status") == "good"]
        if choice_key == "5":
            return [c for c in configs_list if ping_results.get(c, {}).get("status") in ("good", "warn")]
        if choice_key == "6":
            return configs_list
        return []

    def default_filename_for_choice(choice_key: str):
        mapping = {
            "1": "vless",
            "2": "trojan",
            "3": "ss",
            "4": "green",
            "5": "green_yellow",
            "6": "all_configs"
        }
        return mapping.get(choice_key, "output")

    def save_list_to_txt(lines: list, default_name: str):
        if not lines:
            print("[yellow]No items to save for this selection.[/yellow]")
            return None
        fname = input(f"Enter filename (default: {default_name}.txt): ").strip() or default_name
        if not fname.endswith(".txt"):
            fname += ".txt"
        outpath = os.path.join(OUTPUT_FOLDER, fname)
        try:
            with open(outpath, "w", encoding="utf-8") as f:
                for ln in lines:
                    f.write(ln.rstrip() + "\n")
            print(f"[green]Saved {len(lines)} items -> {outpath}[/green]")
            return outpath
        except Exception as e:
            print(f"[red]Error saving file: {e}[/red]")
            return None

    # ==================== Main Output Menu ====================
    while True:
        console.print("\n[bold cyan]Choose output to generate (enter number):[/bold cyan]")
        console.print("[white]1)[/white] [green]vless[/green]")
        console.print("[white]2)[/white] [yellow]trojan[/yellow]")
        console.print("[white]3)[/white] [cyan]ss/ssss[/cyan]")
        console.print("[white]4)[/white] [green]green (GOOD)[/green]")
        console.print("[white]5)[/white] [yellow]green + yellow (GOOD + WARN)[/yellow]")
        console.print("[white]6)[/white] [magenta]all configs[/magenta]")
        console.print("[white]0)[/white] [red]Exit[/red]")
        choice = input("Choice: ").strip()
        if choice == "0":
            console.print("[cyan]Exiting. Goodbye.[/cyan]")
            break
        if choice not in MENU_MAP:
            console.print("[red]Invalid choice[/red]")
            continue
        selected = filter_by_choice(choice, configs)
        default_name = default_filename_for_choice(choice)
        save_list_to_txt(selected, default_name)
        cont = input("Do you want to generate another output? (y/N): ").strip().lower()
        if cont != "y":
            console.print("[cyan]Done — exiting.[/cyan]")
            break

# ==================== Entry Point ====================
if __name__ == "__main__":
    main()
