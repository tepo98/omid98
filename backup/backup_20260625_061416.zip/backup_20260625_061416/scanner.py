#!/usr/bin/env python3
"""
MasterDnsVPN MTU Approximation Scanner v5.0.0
Built by @ProgrammingWithAITech

Interactive menu-driven scanner.
Phase 1: Find best servers using test.txt
Phase 2: Scan large IP list using top servers

CRITICAL: Run with VPN OFF
"""

import asyncio
import argparse
import sys
import os
import json
import random
import string
import time
import urllib.request
import ipaddress
from pathlib import Path
from typing import List, Tuple, Optional, Dict
from dataclasses import dataclass, asdict, field

try:
    import dns.asyncresolver
    import dns.message
    import dns.asyncquery
    import dns.edns
    import dns.flags
except ImportError:
    print("ERROR: dnspython not installed.")
    print("Run: pip install dnspython")
    sys.exit(1)

try:
    from tqdm import tqdm
    HAS_TQDM = True
except ImportError:
    HAS_TQDM = False

# ============================================================================
# ANSI COLORS
# ============================================================================

class C:
    RST     = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    ULINE   = "\033[4m"
    RED     = "\033[91m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    BLUE    = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN    = "\033[96m"
    WHITE   = "\033[97m"
    GREY    = "\033[90m"
    BG_RED  = "\033[41m"
    BG_GRN  = "\033[42m"
    BG_BLU  = "\033[44m"
    BG_MAG  = "\033[45m"
    BG_CYN  = "\033[46m"

# ============================================================================
# VERSION & DEFAULTS
# ============================================================================

VERSION = "5.0.0"

DEFAULT_CONCURRENCY    = 100
DEFAULT_TIMEOUT        = 3.0
DEFAULT_MIN_UPLOAD     = 75
DEFAULT_MIN_DOWNLOAD   = 500
DEFAULT_CHECKPOINT_INT = 5000
DEFAULT_PORT           = 53
DEFAULT_TOP_N_SERVERS  = 4
CONCURRENCY_WARN       = 200
MAX_DOMAIN_DISPLAY     = 24
MAX_PATH_DISPLAY       = 40

# ── All files in one folder inside Downloads ─────────────────────────────────
BASE_DIR = Path("/storage/emulated/0/Download/scanner")
BASE_DIR.mkdir(parents=True, exist_ok=True)

SAMPLE_FILE       = BASE_DIR / "test.txt"
MAIN_FILE_LIST    = BASE_DIR / "list.txt"
MAIN_FILE_IRAN    = BASE_DIR / "iran-ips.txt"
OUTPUT_FILE       = BASE_DIR / "passed.txt"
CHECKPOINT_FILE   = BASE_DIR / "scan.json"
IRAN_DOWNLOAD_DST = BASE_DIR / "iran-ips.txt"

# ============================================================================
# BUILT-IN SERVER LIST (6 servers)
# ============================================================================

BUILTIN_SERVERS = [
    ("z.bamak.xyz",            "bc8d889ba87a24ca7b6a36b3167ca8ad"),
    ("v.eshkaftak.vip",        "8705eb75abeedcd99001ef8d01cf9fad"),
    ("w3.prs612.us",           "3cec408034c22d3632f40e6a2e28d26c"),
    ("v.xbtai.shop",           "b1dabaedd1d2ecffdc76f23992454c6c"),
    ("f.tenzm.lol",            "013295fd3fb2cd32294b38e485828137"),
    ("v.guardiansangel.cv",    "1b356f9f7f47e5239d8f90b3e5b29270"),
]

# ============================================================================
# IRANIAN IP SOURCES
# ============================================================================

IRAN_IP_SOURCES = [
    {
        "name": "PYDNS-Scanner (xullexer) ~10M IPs",
        "url": "https://raw.githubusercontent.com/xullexer/PYDNS-Scanner/main/iran-ipv4.cidrs"
    },
    {
        "name": "Country IP Blocks (herrbischoff)",
        "url": "https://raw.githubusercontent.com/herrbischoff/country-ip-blocks/master/ipv4/ir.cidr"
    },
    {
        "name": "KAJOOSH Iran IP Database",
        "url": "https://raw.githubusercontent.com/KAJOOSH/iran-ip-database/main/iran-ip.txt"
    },
]

# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class MTUResult:
    ip: str
    port: int
    server_domain: str = ""
    upload_ok: bool = False
    download_ok: bool = False
    upload_latency_ms: float = 0.0
    download_latency_ms: float = 0.0
    passed: bool = False
    error: Optional[str] = None

@dataclass
class ServerScore:
    domain: str
    passed: int = 0
    tested: int = 0
    avg_latency_ms: float = 0.0
    latencies: List[float] = field(default_factory=list)

    @property
    def pass_rate(self) -> float:
        return self.passed / max(self.tested, 1)

    @property
    def score(self) -> float:
        latency_penalty = min(self.avg_latency_ms / 3000.0, 1.0)
        return self.pass_rate * (1.0 - latency_penalty * 0.3)

# ============================================================================
# HELPERS
# ============================================================================

def trunc(text: str, maxlen: int) -> str:
    if len(text) <= maxlen:
        return text
    return text[:maxlen - 2] + ".."

def trunc_path(p: Path, maxlen: int = MAX_PATH_DISPLAY) -> str:
    s = str(p)
    if len(s) <= maxlen:
        return s
    return "..." + s[-(maxlen - 3):]

def clear():
    os.system('clear' if os.name != 'nt' else 'cls')

def hr(char="─", length=56):
    return f"  {C.GREY}{char * length}{C.RST}"

def banner():
    print()
    print(f"  {C.CYAN}{C.BOLD}╔══════════════════════════════════════════════════════╗{C.RST}")
    print(f"  {C.CYAN}{C.BOLD}║{C.RST}  {C.GREEN}{C.BOLD}🔍  MasterDnsVPN MTU Scanner{C.RST}  {C.DIM}v{VERSION}{C.RST}            {C.CYAN}{C.BOLD}║{C.RST}")
    print(f"  {C.CYAN}{C.BOLD}║{C.RST}  {C.YELLOW}Built by @ProgrammingWithAITech{C.RST}               {C.CYAN}{C.BOLD}║{C.RST}")
    print(f"  {C.CYAN}{C.BOLD}╠══════════════════════════════════════════════════════╣{C.RST}")
    print(f"  {C.CYAN}{C.BOLD}║{C.RST}  {C.RED}{C.BOLD}⚠️  Keep VPN DISCONNECTED while scanning!{C.RST}        {C.CYAN}{C.BOLD}║{C.RST}")
    print(f"  {C.CYAN}{C.BOLD}╚══════════════════════════════════════════════════════╝{C.RST}")

def donation_box():
    print()
    print(f"  {C.MAGENTA}{C.BOLD}╔══════════════════════════════════════════════════════╗{C.RST}")
    print(f"  {C.MAGENTA}{C.BOLD}║{C.RST}  {C.YELLOW}💰 Donations (حمایت مالی):{C.RST}                        {C.MAGENTA}{C.BOLD}║{C.RST}")
    print(f"  {C.MAGENTA}{C.BOLD}║{C.RST}  {C.GREEN}BSC:{C.RST} {C.WHITE}0xd4bc0ea63f6dae921694c9a77{C.RST}              {C.MAGENTA}{C.BOLD}║{C.RST}")
    print(f"  {C.MAGENTA}{C.BOLD}║{C.RST}       {C.WHITE}ee49ae5d8385df8{C.RST}                          {C.MAGENTA}{C.BOLD}║{C.RST}")
    print(f"  {C.MAGENTA}{C.BOLD}║{C.RST}  {C.DIM}(Binance Smart Chain){C.RST}                            {C.MAGENTA}{C.BOLD}║{C.RST}")
    print(f"  {C.MAGENTA}{C.BOLD}╚══════════════════════════════════════════════════════╝{C.RST}")

def section_header(title: str):
    print(f"\n  {C.CYAN}{C.BOLD}{'═'*56}{C.RST}")
    print(f"  {C.CYAN}{C.BOLD}  {title}{C.RST}")
    print(f"  {C.CYAN}{C.BOLD}{'═'*56}{C.RST}")

def info(msg: str):
    print(f"  {C.BLUE}ℹ{C.RST}  {msg}")

def success(msg: str):
    print(f"  {C.GREEN}✓{C.RST}  {msg}")

def warn(msg: str):
    print(f"  {C.YELLOW}⚠{C.RST}  {msg}")

def error(msg: str):
    print(f"  {C.RED}✗{C.RST}  {msg}")

def prompt(text: str, default: str = "") -> str:
    if default:
        result = input(f"  {C.CYAN}▸{C.RST} {text} {C.DIM}[{default}]{C.RST}: ").strip()
        return result if result else default
    return input(f"  {C.CYAN}▸{C.RST} {text}: ").strip()

def prompt_int(text: str, default: int) -> int:
    while True:
        raw = prompt(text, str(default))
        try:
            return int(raw)
        except ValueError:
            error("Please enter a number")

def prompt_float(text: str, default: float) -> float:
    while True:
        raw = prompt(text, str(default))
        try:
            return float(raw)
        except ValueError:
            error("Please enter a number")

def file_line_count(path: Path) -> int:
    try:
        count = 0
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    count += 1
        return count
    except Exception:
        return 0

def check_file(path: Path, label: str) -> bool:
    if path.exists():
        count = file_line_count(path)
        success(f"{label}: {C.WHITE}{trunc_path(path)}{C.RST} {C.DIM}({count:,} lines){C.RST}")
        return True
    else:
        error(f"{label}: {C.WHITE}{trunc_path(path)}{C.RST} {C.RED}(NOT FOUND){C.RST}")
        return False

def show_scan_config(
    sample_file: Path,
    main_file: Path,
    output_file: Path,
    checkpoint_file: Optional[Path],
    min_upload: int,
    min_download: int,
    concurrency: int,
    timeout: float,
    top_n: int,
    limit: Optional[int],
):
    print(f"\n{hr()}")
    print(f"  {C.WHITE}Sample file {C.RST} : {C.CYAN}{trunc_path(sample_file)}{C.RST}")
    print(f"  {C.WHITE}Main file   {C.RST} : {C.CYAN}{trunc_path(main_file)}{C.RST}")
    print(f"  {C.WHITE}Output      {C.RST} : {C.CYAN}{trunc_path(output_file)}{C.RST}")
    print(f"  {C.WHITE}Upload MTU  {C.RST} : {C.GREEN}≥{min_upload} bytes{C.RST}")
    print(f"  {C.WHITE}Download MTU{C.RST} : {C.GREEN}≥{min_download} bytes{C.RST}")
    print(f"  {C.WHITE}Concurrency {C.RST} : {C.YELLOW}{concurrency}{C.RST}")
    print(f"  {C.WHITE}Timeout     {C.RST} : {C.YELLOW}{timeout}s{C.RST}")
    print(f"  {C.WHITE}Top servers {C.RST} : {C.YELLOW}{top_n}{C.RST}")
    ck_str = trunc_path(checkpoint_file) if checkpoint_file else "disabled"
    print(f"  {C.WHITE}Checkpoint  {C.RST} : {C.DIM}{ck_str}{C.RST}")
    lm_str = str(limit) if limit else f"{C.DIM}none (all IPs){C.RST}"
    print(f"  {C.WHITE}IP limit    {C.RST} : {lm_str}")
    print(f"{hr()}")
    if concurrency > CONCURRENCY_WARN:
        warn(f"Concurrency {concurrency} > {CONCURRENCY_WARN} — may trigger ISP rate-limiting!")

# ============================================================================
# PROGRESS BAR
# ============================================================================

def make_progress_bar(total: int, desc: str, unit: str = "IP") -> Optional[tqdm]:
    if HAS_TQDM and sys.stdout.isatty():
        return tqdm(
            total=total,
            desc=f"{C.GREEN}{C.BOLD}{desc}{C.RST}",
            unit=unit,
            ncols=80,
            bar_format=(
                "{l_bar}"
                f"{C.CYAN}" + "{bar}" + f"{C.RST}"
                " {n_fmt}/{total_fmt} "
                f"{C.DIM}" + "[{elapsed}<{remaining}, {rate_fmt}]" + f"{C.RST}"
                " {postfix}"
            ),
            ascii="░▒▓█",
        )
    return None

# ============================================================================
# IRANIAN IP DOWNLOADER
# ============================================================================

def download_iran_ips(output_file: Path) -> Optional[Path]:
    output_file.parent.mkdir(parents=True, exist_ok=True)

    section_header("Downloading Iranian IP Ranges")

    for idx, source in enumerate(IRAN_IP_SOURCES):
        info(f"[{idx+1}/{len(IRAN_IP_SOURCES)}] {source['name']}")

        try:
            req = urllib.request.Request(
                source['url'],
                headers={'User-Agent': 'Mozilla/5.0'}
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = resp.read().decode('utf-8', errors='ignore')

            valid = [
                l.strip() for l in raw.splitlines()
                if l.strip() and not l.strip().startswith('#')
            ]

            if not valid:
                error("Empty response")
                continue

            with open(output_file, 'w') as f:
                f.write(f"# Iranian IP Ranges\n")
                f.write(f"# Source: {source['name']}\n")
                f.write(f"# Downloaded: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                f.write('\n'.join(valid) + '\n')

            success(f"Downloaded {C.WHITE}{len(valid):,}{C.RST} ranges")
            success(f"Saved to: {C.CYAN}{output_file}{C.RST}")

            total = 0
            for line in valid[:500]:
                try:
                    if '/' in line:
                        total += ipaddress.ip_network(line, strict=False).num_addresses
                    else:
                        total += 1
                except Exception:
                    pass
            est = total * (len(valid) / min(500, len(valid)))
            info(f"Estimated IPs: ~{C.WHITE}{est:,.0f}{C.RST}")
            h = est / DEFAULT_CONCURRENCY / DEFAULT_TIMEOUT / 3600
            info(f"Est. scan time: ~{C.YELLOW}{h:.1f}h{C.RST} at concurrency {DEFAULT_CONCURRENCY}")

            return output_file

        except Exception as e:
            error(f"Failed: {e}")
            continue

    error("All sources failed!")
    print(f"  {C.DIM}Manual download:{C.RST}")
    print(f"  {C.DIM}curl -o {output_file} \\{C.RST}")
    print(f"  {C.DIM}  https://raw.githubusercontent.com/xullexer/PYDNS-Scanner/main/iran-ipv4.cidrs{C.RST}")
    return None

# ============================================================================
# IP EXPANSION
# ============================================================================

def expand_ip_list(input_file: Path, randomize: bool = True) -> List[Tuple[str, int]]:
    resolvers = []
    skipped = 0

    with open(input_file, 'r') as f:
        lines = f.readlines()

    for line in lines:
        line = line.strip()
        if not line or line.startswith('#'):
            continue

        port = DEFAULT_PORT
        addr_part = line

        if ':' in line and '/' not in line:
            try:
                addr_part, port_str = line.rsplit(':', 1)
                port = int(port_str)
            except ValueError:
                pass
        elif ':' in line and '/' in line:
            try:
                addr_part, port_str = line.rsplit(':', 1)
                port = int(port_str)
            except ValueError:
                pass

        if '/' in addr_part:
            try:
                network = ipaddress.ip_network(addr_part, strict=False)
                for ip in network.hosts():
                    resolvers.append((str(ip), port))
            except ValueError:
                skipped += 1
        else:
            try:
                ipaddress.ip_address(addr_part)
                resolvers.append((addr_part, port))
            except ValueError:
                skipped += 1

    if skipped:
        warn(f"Skipped {skipped:,} invalid entries")

    if randomize:
        random.shuffle(resolvers)

    return resolvers

# ============================================================================
# MTU TESTER
# ============================================================================

class MTUTester:
    def __init__(self, timeout: float = DEFAULT_TIMEOUT):
        self.timeout = timeout

    async def test_upload(self, resolver_ip: str, domain: str, mtu_bytes: int) -> Tuple[bool, float]:
        start = time.time()
        try:
            rand = ''.join(random.choices(string.ascii_lowercase + string.digits, k=mtu_bytes))
            labels = [rand[i:i+63] for i in range(0, len(rand), 63)]
            test_domain = '.'.join(labels) + '.' + domain

            resolver = dns.asyncresolver.Resolver(configure=False)
            resolver.nameservers = [resolver_ip]
            resolver.timeout = self.timeout
            resolver.lifetime = self.timeout

            try:
                await resolver.resolve(test_domain, 'A')
                return (True, (time.time() - start) * 1000)
            except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
                return (True, (time.time() - start) * 1000)
            except (dns.exception.Timeout, asyncio.TimeoutError):
                return (False, (time.time() - start) * 1000)
        except Exception:
            return (False, (time.time() - start) * 1000)

    async def test_download(self, resolver_ip: str, domain: str, mtu_bytes: int) -> Tuple[bool, float]:
        start = time.time()
        try:
            query = dns.message.make_query(domain, 'A')
            query.use_edns(edns=0, payload=mtu_bytes)
            try:
                response = await asyncio.wait_for(
                    dns.asyncquery.udp(query, resolver_ip, timeout=self.timeout),
                    timeout=self.timeout
                )
                latency = (time.time() - start) * 1000
                if response.edns >= 0 and not (response.flags & dns.flags.TC):
                    return (True, latency)
                return (False, latency)
            except (asyncio.TimeoutError, dns.exception.Timeout):
                return (False, (time.time() - start) * 1000)
        except Exception:
            return (False, (time.time() - start) * 1000)

    async def test_resolver(self, ip: str, port: int, domain: str,
                            min_upload: int, min_download: int) -> MTUResult:
        result = MTUResult(ip=ip, port=port, server_domain=domain)
        upload_ok, ul = await self.test_upload(ip, domain, min_upload)
        result.upload_ok = upload_ok
        result.upload_latency_ms = ul

        if upload_ok:
            dl_ok, dl = await self.test_download(ip, domain, min_download)
            result.download_ok = dl_ok
            result.download_latency_ms = dl

        result.passed = result.upload_ok and result.download_ok
        return result

# ============================================================================
# PHASE 1: SERVER SELECTION
# ============================================================================

async def phase1_select_servers(
    sample_ips: List[Tuple[str, int]],
    servers: List[Tuple[str, str]],
    tester: MTUTester,
    min_upload: int,
    min_download: int,
    concurrency: int,
    top_n: int
) -> List[Tuple[str, str]]:

    section_header("PHASE 1: Server Selection")
    info(f"Sample IPs  : {C.WHITE}{len(sample_ips):,}{C.RST}")
    info(f"Servers     : {C.WHITE}{len(servers)}{C.RST}")
    info(f"Total probes: {C.WHITE}{len(sample_ips) * len(servers):,}{C.RST}")
    info(f"Selecting   : top {C.YELLOW}{top_n}{C.RST} servers")
    print()

    scores: Dict[str, ServerScore] = {
        domain: ServerScore(domain=domain)
        for domain, _ in servers
    }

    semaphore = asyncio.Semaphore(concurrency)

    async def test_one(ip: str, port: int, domain: str):
        async with semaphore:
            result = await tester.test_resolver(ip, port, domain, min_upload, min_download)
            scores[domain].tested += 1
            if result.passed:
                scores[domain].passed += 1
                scores[domain].latencies.append(
                    result.upload_latency_ms + result.download_latency_ms
                )
            return result

    tasks = []
    for ip, port in sample_ips:
        for domain, _ in servers:
            tasks.append(test_one(ip, port, domain))
    random.shuffle(tasks)

    progress = make_progress_bar(len(tasks), "Phase 1", "probe")
    if progress:
        async def wrapped(coro):
            r = await coro
            progress.update(1)
            return r
        await asyncio.gather(*[wrapped(t) for t in tasks], return_exceptions=True)
        progress.close()
    else:
        await asyncio.gather(*tasks, return_exceptions=True)

    for s in scores.values():
        if s.latencies:
            s.avg_latency_ms = sum(s.latencies) / len(s.latencies)

    sorted_scores = sorted(scores.values(), key=lambda s: s.score, reverse=True)

    print()
    header = (
        f"  {C.BOLD}{C.WHITE}{'Domain':<26} {'Pass':>5} {'Rate':>7} "
        f"{'Avg Lat':>10} {'Score':>8}{C.RST}"
    )
    print(header)
    print(f"  {C.GREY}{'─'*56}{C.RST}")

    for i, s in enumerate(sorted_scores):
        if i < top_n:
            marker = f"{C.GREEN}{C.BOLD}✓{C.RST}"
            dom_color = C.GREEN
        else:
            marker = f" "
            dom_color = C.DIM
        d = trunc(s.domain, 24)
        print(
            f"  {marker} {dom_color}{d:<24}{C.RST} {s.passed:>5} "
            f"{s.pass_rate*100:>6.1f}% {s.avg_latency_ms:>8.0f}ms {s.score:>8.4f}"
        )

    top = sorted_scores[:top_n]
    domain_to_key = {d: k for d, k in servers}

    print(f"\n  {C.GREEN}{C.BOLD}✓ Top {top_n} servers selected:{C.RST}")
    for i, s in enumerate(top, 1):
        d = trunc(s.domain, MAX_DOMAIN_DISPLAY)
        print(
            f"    {C.CYAN}{i}.{C.RST} {C.WHITE}{d}{C.RST} "
            f"{C.DIM}(rate={s.pass_rate*100:.1f}%, lat={s.avg_latency_ms:.0f}ms){C.RST}"
        )

    return [(s.domain, domain_to_key[s.domain]) for s in top]

# ============================================================================
# PHASE 2: FULL SCAN
# ============================================================================

async def phase2_full_scan(
    all_ips: List[Tuple[str, int]],
    top_servers: List[Tuple[str, str]],
    tester: MTUTester,
    min_upload: int,
    min_download: int,
    concurrency: int,
    checkpoint: 'CheckpointManager',
) -> List[MTUResult]:

    section_header("PHASE 2: Full Scan")
    info("Servers (round-robin):")
    for i, (domain, _) in enumerate(top_servers, 1):
        d = trunc(domain, MAX_DOMAIN_DISPLAY)
        print(f"    {C.CYAN}{i}.{C.RST} {C.WHITE}{d}{C.RST}")

    to_scan = [
        (ip, port) for ip, port in all_ips
        if not checkpoint.is_scanned(ip, port)
    ]
    skipped = len(all_ips) - len(to_scan)
    if skipped:
        warn(f"Skipping {skipped:,} already-scanned IPs (checkpoint)")
    info(f"To scan: {C.WHITE}{len(to_scan):,}{C.RST} IPs")

    if not to_scan:
        warn("Nothing to scan!")
        return checkpoint.results

    est = len(to_scan) / concurrency * DEFAULT_TIMEOUT
    info(f"Est. time: ~{C.YELLOW}{est/3600:.1f} hours{C.RST}")
    print()

    semaphore = asyncio.Semaphore(concurrency)
    server_index = [0]

    progress = make_progress_bar(len(to_scan), "Phase 2", "IP")

    async def test_with_semaphore(ip: str, port: int):
        async with semaphore:
            idx = server_index[0] % len(top_servers)
            server_index[0] += 1
            domain, _ = top_servers[idx]

            result = await tester.test_resolver(
                ip, port, domain, min_upload, min_download
            )
            checkpoint.add_result(result)

            if progress:
                progress.update(1)
                passed = sum(1 for r in checkpoint.results if r.passed)
                progress.set_postfix(
                    passed=f"{C.GREEN}{passed}{C.RST}",
                    srv=trunc(domain, 16),
                    refresh=False
                )
            return result

    start = time.time()
    tasks = [test_with_semaphore(ip, port) for ip, port in to_scan]
    await asyncio.gather(*tasks, return_exceptions=True)

    if progress:
        progress.close()

    checkpoint.save()
    elapsed = time.time() - start
    total = len(checkpoint.results)
    passed = sum(1 for r in checkpoint.results if r.passed)
    ul = sum(1 for r in checkpoint.results if r.upload_ok)
    dl = sum(1 for r in checkpoint.results if r.download_ok)

    section_header("Phase 2 Complete!")
    print(f"  {C.WHITE}Total tested {C.RST} : {C.CYAN}{total:,}{C.RST}")
    print(f"  {C.WHITE}Upload passed{C.RST} : {C.GREEN}{ul:,}{C.RST} ({ul/max(total,1)*100:.1f}%)")
    print(f"  {C.WHITE}Download pass{C.RST} : {C.GREEN}{dl:,}{C.RST} ({dl/max(total,1)*100:.1f}%)")
    print(f"  {C.WHITE}Both passed  {C.RST} : {C.GREEN}{C.BOLD}{passed:,}{C.RST} ({passed/max(total,1)*100:.1f}%)")
    print(f"  {C.WHITE}Time elapsed {C.RST} : {C.YELLOW}{elapsed/60:.1f} minutes{C.RST}")
    print(f"  {C.WHITE}Speed        {C.RST} : {C.YELLOW}{total/max(elapsed,1):.1f} IPs/sec{C.RST}")

    return checkpoint.results

# ============================================================================
# CHECKPOINT
# ============================================================================

class CheckpointManager:
    def __init__(self, checkpoint_file: Optional[Path], interval: int):
        self.checkpoint_file = checkpoint_file
        self.interval = interval
        self.scanned_ips: set = set()
        self.results: List[MTUResult] = []
        self.counter = 0

        if checkpoint_file and checkpoint_file.exists():
            self.load()

    def load(self):
        try:
            with open(self.checkpoint_file, 'r') as f:
                data = json.load(f)
            self.scanned_ips = set(data.get('scanned_ips', []))
            self.results = [MTUResult(**r) for r in data.get('results', [])]
            passed = sum(1 for r in self.results if r.passed)
            success(f"Resumed: {len(self.scanned_ips):,} scanned, {passed:,} passed")
        except Exception as e:
            warn(f"Could not load checkpoint: {e}")

    def save(self):
        if not self.checkpoint_file:
            return
        try:
            data = {
                'scanned_ips': list(self.scanned_ips),
                'results': [asdict(r) for r in self.results]
            }
            with open(self.checkpoint_file, 'w') as f:
                json.dump(data, f)
        except Exception as e:
            warn(f"Checkpoint save failed: {e}")

    def add_result(self, result: MTUResult):
        self.scanned_ips.add(f"{result.ip}:{result.port}")
        self.results.append(result)
        self.counter += 1
        if self.counter % self.interval == 0:
            self.save()
            passed = sum(1 for r in self.results if r.passed)
            print(f"\n  {C.BLUE}[Checkpoint]{C.RST} Scanned: {C.WHITE}{self.counter:,}{C.RST} | Passed: {C.GREEN}{passed:,}{C.RST}")

    def is_scanned(self, ip: str, port: int) -> bool:
        return f"{ip}:{port}" in self.scanned_ips

# ============================================================================
# OUTPUT
# ============================================================================

def write_output(results: List[MTUResult], output_file: Path):
    passed = [r for r in results if r.passed]
    output_file.parent.mkdir(parents=True, exist_ok=True)

    with open(output_file, 'w') as f:
        for r in passed:
            f.write(f"{r.ip}\n")

    print()
    success(f"Output written to : {C.CYAN}{output_file}{C.RST}")
    success(f"Passed resolvers  : {C.GREEN}{C.BOLD}{len(passed):,}{C.RST} / {len(results):,}")

    if passed:
        print(f"\n  {C.WHITE}First 10 results:{C.RST}")
        for r in passed[:10]:
            srv = trunc(r.server_domain, MAX_DOMAIN_DISPLAY)
            print(f"    {C.GREEN}●{C.RST} {C.WHITE}{r.ip}{C.RST}  {C.DIM}(via {srv}){C.RST}")
        if len(passed) > 10:
            print(f"    {C.DIM}... and {len(passed)-10} more{C.RST}")

# ============================================================================
# SCAN RUNNERS
# ============================================================================

def run_two_phase_scan(
    sample_file: Path,
    main_file: Path,
    output_file: Path,
    checkpoint_file: Optional[Path],
    min_upload: int,
    min_download: int,
    concurrency: int,
    timeout: float,
    top_n: int,
    limit: Optional[int] = None,
):
    tester = MTUTester(timeout=timeout)
    checkpoint = CheckpointManager(checkpoint_file, DEFAULT_CHECKPOINT_INT)

    info(f"Loading sample : {C.CYAN}{trunc_path(sample_file)}{C.RST}")
    sample_ips = expand_ip_list(sample_file, randomize=True)
    info(f"Sample IPs: {C.WHITE}{len(sample_ips):,}{C.RST}")

    info(f"Loading main   : {C.CYAN}{trunc_path(main_file)}{C.RST}")
    main_ips = expand_ip_list(main_file, randomize=True)
    if limit:
        main_ips = main_ips[:limit]
        warn(f"Limited to: {limit:,} IPs")
    info(f"Main IPs: {C.WHITE}{len(main_ips):,}{C.RST}")

    try:
        top_servers = asyncio.run(phase1_select_servers(
            sample_ips=sample_ips,
            servers=BUILTIN_SERVERS,
            tester=tester,
            min_upload=min_upload,
            min_download=min_download,
            concurrency=concurrency,
            top_n=top_n,
        ))

        results = asyncio.run(phase2_full_scan(
            all_ips=main_ips,
            top_servers=top_servers,
            tester=tester,
            min_upload=min_upload,
            min_download=min_download,
            concurrency=concurrency,
            checkpoint=checkpoint,
        ))

        write_output(results, output_file)

    except KeyboardInterrupt:
        print(f"\n\n  {C.YELLOW}Scan interrupted!{C.RST}")
        if checkpoint_file:
            info(f"Progress saved to: {C.CYAN}{checkpoint_file}{C.RST}")
        sys.exit(0)


def run_phase1_only(
    sample_file: Path,
    min_upload: int,
    min_download: int,
    concurrency: int,
    timeout: float,
    top_n: int,
):
    tester = MTUTester(timeout=timeout)

    info(f"Loading sample : {C.CYAN}{trunc_path(sample_file)}{C.RST}")
    sample_ips = expand_ip_list(sample_file, randomize=True)
    info(f"Sample IPs: {C.WHITE}{len(sample_ips):,}{C.RST}")

    try:
        top_servers = asyncio.run(phase1_select_servers(
            sample_ips=sample_ips,
            servers=BUILTIN_SERVERS,
            tester=tester,
            min_upload=min_upload,
            min_download=min_download,
            concurrency=concurrency,
            top_n=top_n,
        ))

        section_header("Phase 1 Complete — Best Servers")
        print()
        for i, (domain, key) in enumerate(top_servers, 1):
            d = trunc(domain, MAX_DOMAIN_DISPLAY)
            print(f"    {C.GREEN}{C.BOLD}{i}.{C.RST} {C.WHITE}{d}{C.RST}  {C.DIM}key={key[:12]}..{C.RST}")

        print(f"\n  {C.DIM}Use these servers in Phase 2 or Single Server mode.{C.RST}")

    except KeyboardInterrupt:
        print(f"\n\n  {C.YELLOW}Interrupted!{C.RST}")
        sys.exit(0)


def run_single_server_scan(
    main_file: Path,
    domain: str,
    output_file: Path,
    checkpoint_file: Optional[Path],
    min_upload: int,
    min_download: int,
    concurrency: int,
    timeout: float,
    limit: Optional[int] = None,
):
    tester = MTUTester(timeout=timeout)
    checkpoint = CheckpointManager(checkpoint_file, DEFAULT_CHECKPOINT_INT)

    info(f"Loading: {C.CYAN}{trunc_path(main_file)}{C.RST}")
    main_ips = expand_ip_list(main_file, randomize=True)
    if limit:
        main_ips = main_ips[:limit]
    info(f"IPs: {C.WHITE}{len(main_ips):,}{C.RST}")

    try:
        results = asyncio.run(phase2_full_scan(
            all_ips=main_ips,
            top_servers=[(domain, "")],
            tester=tester,
            min_upload=min_upload,
            min_download=min_download,
            concurrency=concurrency,
            checkpoint=checkpoint,
        ))
        write_output(results, output_file)

    except KeyboardInterrupt:
        print(f"\n\n  {C.YELLOW}Scan interrupted!{C.RST}")
        if checkpoint_file:
            info(f"Progress saved to: {C.CYAN}{checkpoint_file}{C.RST}")
        sys.exit(0)

# ============================================================================
# MENU ACTIONS
# ============================================================================

def menu_download_ips():
    section_header("Download Iranian IP Ranges")
    info(f"Save to: {C.CYAN}{IRAN_DOWNLOAD_DST}{C.RST}")
    print()

    if IRAN_DOWNLOAD_DST.exists():
        count = file_line_count(IRAN_DOWNLOAD_DST)
        warn(f"File already exists ({count:,} lines)")
        overwrite = prompt("Overwrite? (y/n)", "n").lower()
        if overwrite != 'y':
            info("Cancelled.")
            input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")
            return

    result = download_iran_ips(IRAN_DOWNLOAD_DST)
    if result:
        success("Done!")
    input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")


def menu_two_phase_list():
    section_header("Two-Phase Scan → list.txt")

    print(f"\n  {C.WHITE}Checking files:{C.RST}")
    ok = True
    ok &= check_file(SAMPLE_FILE, "Sample file")
    ok &= check_file(MAIN_FILE_LIST, "Main file (list)")

    if not ok:
        error("One or more required files not found!")
        input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")
        return

    print()
    min_upload   = prompt_int("Min upload MTU (bytes)", DEFAULT_MIN_UPLOAD)
    min_download = prompt_int("Min download MTU (bytes)", DEFAULT_MIN_DOWNLOAD)
    concurrency  = prompt_int("Concurrency", DEFAULT_CONCURRENCY)
    timeout      = prompt_float("Timeout (seconds)", DEFAULT_TIMEOUT)
    top_n        = prompt_int("Top N servers to select", DEFAULT_TOP_N_SERVERS)

    use_ckpt = prompt("Use checkpoint for resume? (y/n)", "y").lower() == 'y'
    ckpt = CHECKPOINT_FILE if use_ckpt else None

    limit_raw = prompt("Limit IPs? (0 = scan all)", "0")
    limit = int(limit_raw) if limit_raw.isdigit() and int(limit_raw) > 0 else None

    show_scan_config(
        SAMPLE_FILE, MAIN_FILE_LIST, OUTPUT_FILE, ckpt,
        min_upload, min_download, concurrency, timeout, top_n, limit
    )

    go = prompt("Start scan? (y/n)", "y").lower()
    if go != 'y':
        info("Cancelled.")
        input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")
        return

    run_two_phase_scan(
        sample_file=SAMPLE_FILE,
        main_file=MAIN_FILE_LIST,
        output_file=OUTPUT_FILE,
        checkpoint_file=ckpt,
        min_upload=min_upload,
        min_download=min_download,
        concurrency=concurrency,
        timeout=timeout,
        top_n=top_n,
        limit=limit,
    )
    input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")


def menu_two_phase_iran():
    section_header("Two-Phase Scan → iran-ips.txt")

    print(f"\n  {C.WHITE}Checking files:{C.RST}")
    ok = True
    ok &= check_file(SAMPLE_FILE, "Sample file")
    ok &= check_file(MAIN_FILE_IRAN, "Main file (iran-ips)")

    if not ok:
        error("One or more required files not found!")
        if not MAIN_FILE_IRAN.exists():
            dl = prompt("Download iran-ips.txt now? (y/n)", "y").lower()
            if dl == 'y':
                result = download_iran_ips(MAIN_FILE_IRAN)
                if not result:
                    input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")
                    return
            else:
                input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")
                return

    print()
    min_upload   = prompt_int("Min upload MTU (bytes)", DEFAULT_MIN_UPLOAD)
    min_download = prompt_int("Min download MTU (bytes)", DEFAULT_MIN_DOWNLOAD)
    concurrency  = prompt_int("Concurrency", DEFAULT_CONCURRENCY)
    timeout      = prompt_float("Timeout (seconds)", DEFAULT_TIMEOUT)
    top_n        = prompt_int("Top N servers to select", DEFAULT_TOP_N_SERVERS)

    use_ckpt = prompt("Use checkpoint for resume? (y/n)", "y").lower() == 'y'
    ckpt = CHECKPOINT_FILE if use_ckpt else None

    limit_raw = prompt("Limit IPs? (0 = scan all)", "0")
    limit = int(limit_raw) if limit_raw.isdigit() and int(limit_raw) > 0 else None

    show_scan_config(
        SAMPLE_FILE, MAIN_FILE_IRAN, OUTPUT_FILE, ckpt,
        min_upload, min_download, concurrency, timeout, top_n, limit
    )

    go = prompt("Start scan? (y/n)", "y").lower()
    if go != 'y':
        info("Cancelled.")
        input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")
        return

    run_two_phase_scan(
        sample_file=SAMPLE_FILE,
        main_file=MAIN_FILE_IRAN,
        output_file=OUTPUT_FILE,
        checkpoint_file=ckpt,
        min_upload=min_upload,
        min_download=min_download,
        concurrency=concurrency,
        timeout=timeout,
        top_n=top_n,
        limit=limit,
    )
    input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")


def menu_single_server():
    section_header("Single Server Scan")
    info("Scans a file against one domain (skips Phase 1)")
    print()

    print(f"  {C.WHITE}Which file to scan?{C.RST}")
    print(f"    {C.CYAN}1.{C.RST} list.txt")
    print(f"    {C.CYAN}2.{C.RST} iran-ips.txt")
    print(f"    {C.CYAN}3.{C.RST} Other (enter path)")
    file_choice = prompt("Choice", "1")

    if file_choice == '1':
        main_file = MAIN_FILE_LIST
    elif file_choice == '2':
        main_file = MAIN_FILE_IRAN
    else:
        path_str = input(f"  {C.CYAN}▸{C.RST} File path: ").strip()
        main_file = Path(path_str)

    if not main_file.exists():
        error(f"File not found: {main_file}")
        input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")
        return

    domain      = prompt("Tunnel domain (e.g. w3.prs612.us)")
    min_upload  = prompt_int("Min upload MTU (bytes)", DEFAULT_MIN_UPLOAD)
    min_download= prompt_int("Min download MTU (bytes)", DEFAULT_MIN_DOWNLOAD)
    concurrency = prompt_int("Concurrency", DEFAULT_CONCURRENCY)
    timeout     = prompt_float("Timeout (seconds)", DEFAULT_TIMEOUT)

    use_ckpt = prompt("Use checkpoint? (y/n)", "y").lower() == 'y'
    ckpt = CHECKPOINT_FILE if use_ckpt else None

    limit_raw = prompt("Limit IPs? (0 = all)", "0")
    limit = int(limit_raw) if limit_raw.isdigit() and int(limit_raw) > 0 else None

    print(f"\n{hr()}")
    print(f"  {C.WHITE}File   {C.RST}: {C.CYAN}{trunc_path(main_file)}{C.RST}")
    print(f"  {C.WHITE}Domain {C.RST}: {C.CYAN}{trunc(domain, 30)}{C.RST}")
    print(f"  {C.WHITE}Output {C.RST}: {C.CYAN}{trunc_path(OUTPUT_FILE)}{C.RST}")
    print(f"  {C.WHITE}Limit  {C.RST}: {limit or f'{C.DIM}none{C.RST}'}")

    go = prompt("Start? (y/n)", "y").lower()
    if go != 'y':
        info("Cancelled.")
        input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")
        return

    run_single_server_scan(
        main_file=main_file,
        domain=domain,
        output_file=OUTPUT_FILE,
        checkpoint_file=ckpt,
        min_upload=min_upload,
        min_download=min_download,
        concurrency=concurrency,
        timeout=timeout,
        limit=limit,
    )
    input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")


def menu_phase1_only():
    section_header("Phase 1 Only — Find Best Servers")
    info("Tests all built-in servers against sample IPs.")
    info("No scanning is performed — only server ranking.")
    print()

    print(f"  {C.WHITE}Checking files:{C.RST}")
    if not check_file(SAMPLE_FILE, "Sample file"):
        error("Sample file not found!")
        input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")
        return

    print()
    min_upload   = prompt_int("Min upload MTU (bytes)", DEFAULT_MIN_UPLOAD)
    min_download = prompt_int("Min download MTU (bytes)", DEFAULT_MIN_DOWNLOAD)
    concurrency  = prompt_int("Concurrency", DEFAULT_CONCURRENCY)
    timeout      = prompt_float("Timeout (seconds)", DEFAULT_TIMEOUT)
    top_n        = prompt_int("Top N servers to show", DEFAULT_TOP_N_SERVERS)

    go = prompt("Start Phase 1? (y/n)", "y").lower()
    if go != 'y':
        info("Cancelled.")
        input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")
        return

    run_phase1_only(
        sample_file=SAMPLE_FILE,
        min_upload=min_upload,
        min_download=min_download,
        concurrency=concurrency,
        timeout=timeout,
        top_n=top_n,
    )
    input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")


def menu_resume():
    section_header("Resume Interrupted Scan")

    if not CHECKPOINT_FILE.exists():
        error(f"No checkpoint found at: {CHECKPOINT_FILE}")
        input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")
        return

    try:
        with open(CHECKPOINT_FILE) as f:
            data = json.load(f)
        results_so_far = [MTUResult(**r) for r in data.get('results', [])]
        servers_used = list(set(
            r.server_domain for r in results_so_far if r.server_domain
        ))
        scanned = len(data.get('scanned_ips', []))
        passed  = sum(1 for r in results_so_far if r.passed)

        info(f"Checkpoint: {C.CYAN}{CHECKPOINT_FILE}{C.RST}")
        print(f"  {C.WHITE}Scanned so far{C.RST} : {C.CYAN}{scanned:,}{C.RST}")
        print(f"  {C.WHITE}Passed so far {C.RST} : {C.GREEN}{passed:,}{C.RST}")
        svr_list = ', '.join(trunc(s, 20) for s in servers_used)
        print(f"  {C.WHITE}Servers used  {C.RST} : {C.DIM}{svr_list}{C.RST}")

    except Exception as e:
        error(f"Could not read checkpoint: {e}")
        input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")
        return

    print(f"\n  {C.WHITE}Which file was being scanned?{C.RST}")
    print(f"    {C.CYAN}1.{C.RST} list.txt")
    print(f"    {C.CYAN}2.{C.RST} iran-ips.txt")
    file_choice = prompt("Choice", "1")
    main_file = MAIN_FILE_LIST if file_choice == '1' else MAIN_FILE_IRAN

    if not main_file.exists():
        error(f"File not found: {main_file}")
        input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")
        return

    concurrency = prompt_int("Concurrency", DEFAULT_CONCURRENCY)
    timeout     = prompt_float("Timeout (seconds)", DEFAULT_TIMEOUT)

    go = prompt("Resume? (y/n)", "y").lower()
    if go != 'y':
        info("Cancelled.")
        input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")
        return

    top_servers = [(s, "") for s in servers_used]
    tester      = MTUTester(timeout=timeout)
    checkpoint  = CheckpointManager(CHECKPOINT_FILE, DEFAULT_CHECKPOINT_INT)
    main_ips    = expand_ip_list(main_file, randomize=True)

    try:
        results = asyncio.run(phase2_full_scan(
            all_ips=main_ips,
            top_servers=top_servers,
            tester=tester,
            min_upload=DEFAULT_MIN_UPLOAD,
            min_download=DEFAULT_MIN_DOWNLOAD,
            concurrency=concurrency,
            checkpoint=checkpoint,
        ))
        write_output(results, OUTPUT_FILE)
    except KeyboardInterrupt:
        print(f"\n\n  {C.YELLOW}Scan interrupted!{C.RST}")
        info(f"Progress saved to: {C.CYAN}{CHECKPOINT_FILE}{C.RST}")

    input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")


def menu_list_servers():
    section_header(f"Built-in Servers ({len(BUILTIN_SERVERS)} total)")
    print(f"  {C.BOLD}{C.WHITE}{'#':<4} {'Domain':<28} {'Key (first 12)'}{C.RST}")
    print(f"  {C.GREY}{'─'*50}{C.RST}")
    for i, (domain, key) in enumerate(BUILTIN_SERVERS, 1):
        d = trunc(domain, 26)
        print(f"  {C.CYAN}{i:<4}{C.RST} {C.WHITE}{d:<28}{C.RST} {C.DIM}{key[:12]}..{C.RST}")
    input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")


def menu_view_results():
    section_header("View Results: passed.txt")

    if not OUTPUT_FILE.exists():
        error(f"File not found: {OUTPUT_FILE}")
        input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")
        return

    try:
        lines = [
            l.strip() for l in open(OUTPUT_FILE)
            if l.strip() and not l.startswith('#')
        ]
        info(f"Total IPs: {C.GREEN}{C.BOLD}{len(lines):,}{C.RST}")
        print()
        for i, line in enumerate(lines[:30], 1):
            print(f"    {C.CYAN}{i:>4}.{C.RST} {C.WHITE}{line}{C.RST}")
        if len(lines) > 30:
            print(f"\n    {C.DIM}... and {len(lines)-30} more IPs{C.RST}")
    except Exception as e:
        error(f"Error: {e}")

    input(f"\n  {C.DIM}Press Enter to continue...{C.RST}")

# ============================================================================
# MAIN MENU
# ============================================================================

def file_status_icon(path: Path, missing_text: str = "MISSING") -> str:
    if path.exists():
        return f"{C.GREEN}✓{C.RST}"
    return f"{C.RED}✗ {missing_text}{C.RST}"

def interactive_menu():
    while True:
        clear()
        banner()
        donation_box()
        print()

        print(f"  {C.WHITE}{C.BOLD}FILES{C.RST}  {C.DIM}{BASE_DIR}{C.RST}")
        print(f"  {C.GREY}{'─'*50}{C.RST}")

        s_ok  = file_status_icon(SAMPLE_FILE)
        f_ok  = file_status_icon(MAIN_FILE_LIST)
        i_ok  = file_status_icon(MAIN_FILE_IRAN)
        p_ok  = file_status_icon(OUTPUT_FILE, "not yet")
        ck_ok = file_status_icon(CHECKPOINT_FILE, "none")

        print(f"  {s_ok}  test.txt")
        print(f"  {f_ok}  list.txt")
        print(f"  {i_ok}  iran-ips.txt")
        print(f"  {p_ok}  passed.txt")
        print(f"  {ck_ok}  scan.json")

        print()
        print(f"  {C.WHITE}{C.BOLD}MENU{C.RST}")
        print(f"  {C.GREY}{'─'*50}{C.RST}")
        print(f"  {C.CYAN}{C.BOLD}1.{C.RST} {C.WHITE}Download Iranian IP ranges{C.RST}    {C.DIM}→ iran-ips.txt{C.RST}")
        print(f"  {C.CYAN}{C.BOLD}2.{C.RST} {C.WHITE}Two-phase scan{C.RST}                {C.DIM}→ list.txt{C.RST}")
        print(f"  {C.CYAN}{C.BOLD}3.{C.RST} {C.WHITE}Two-phase scan{C.RST}                {C.DIM}→ iran-ips.txt{C.RST}")
        print(f"  {C.CYAN}{C.BOLD}4.{C.RST} {C.WHITE}Single server scan{C.RST}            {C.DIM}(manual domain){C.RST}")
        print(f"  {C.CYAN}{C.BOLD}5.{C.RST} {C.WHITE}Phase 1 only{C.RST}                  {C.DIM}(find best servers){C.RST}")
        print(f"  {C.CYAN}{C.BOLD}6.{C.RST} {C.WHITE}Resume interrupted scan{C.RST}")
        print(f"  {C.CYAN}{C.BOLD}7.{C.RST} {C.WHITE}List all built-in servers{C.RST}")
        print(f"  {C.CYAN}{C.BOLD}8.{C.RST} {C.WHITE}View results{C.RST}                  {C.DIM}(passed.txt){C.RST}")
        print(f"  {C.RED}{C.BOLD}0.{C.RST} {C.WHITE}Exit{C.RST}")
        print()

        choice = input(f"  {C.CYAN}▸{C.RST} Select [{C.CYAN}0-8{C.RST}]: ").strip()

        if   choice == '1': menu_download_ips()
        elif choice == '2': menu_two_phase_list()
        elif choice == '3': menu_two_phase_iran()
        elif choice == '4': menu_single_server()
        elif choice == '5': menu_phase1_only()
        elif choice == '6': menu_resume()
        elif choice == '7': menu_list_servers()
        elif choice == '8': menu_view_results()
        elif choice == '0':
            print(f"\n  {C.GREEN}Goodbye! 👋{C.RST}\n")
            sys.exit(0)
        else:
            error("Invalid option")
            time.sleep(1)

# ============================================================================
# ENTRY POINT
# ============================================================================

def main():
    if len(sys.argv) == 1:
        interactive_menu()
        return

    parser = argparse.ArgumentParser(
        description=f"MasterDnsVPN MTU Scanner v{VERSION} — Built by @ProgrammingWithAITech"
    )
    parser.add_argument('--sample', type=Path, default=SAMPLE_FILE)
    parser.add_argument('--input', '-i', type=Path)
    parser.add_argument('--domain', '-d', type=str)
    parser.add_argument('--download-iran-ips', action='store_true')
    parser.add_argument('--output', '-o', type=Path, default=OUTPUT_FILE)
    parser.add_argument('--min-upload', type=int, default=DEFAULT_MIN_UPLOAD)
    parser.add_argument('--min-download', type=int, default=DEFAULT_MIN_DOWNLOAD)
    parser.add_argument('--concurrency', '-c', type=int, default=DEFAULT_CONCURRENCY)
    parser.add_argument('--timeout', '-t', type=float, default=DEFAULT_TIMEOUT)
    parser.add_argument('--top-servers', type=int, default=DEFAULT_TOP_N_SERVERS)
    parser.add_argument('--checkpoint', type=Path, default=CHECKPOINT_FILE)
    parser.add_argument('--limit', type=int)
    parser.add_argument('--list-servers', action='store_true')
    parser.add_argument('--phase1-only', action='store_true')
    parser.add_argument('--version', action='version', version=f'%(prog)s {VERSION}')
    args = parser.parse_args()

    if args.list_servers:
        for i, (d, k) in enumerate(BUILTIN_SERVERS, 1):
            print(f"  {i:>2}. {d:<30} {k[:8]}...")
        sys.exit(0)

    print(f"\n{C.CYAN}{C.BOLD}MasterDnsVPN MTU Scanner v{VERSION}{C.RST}")
    print(f"{C.YELLOW}Built by @ProgrammingWithAITech{C.RST}")
    print(f"{C.RED}⚠️  VPN must be DISCONNECTED!{C.RST}\n")

    if args.download_iran_ips:
        download_iran_ips(IRAN_DOWNLOAD_DST)
        sys.exit(0)

    if args.phase1_only:
        run_phase1_only(
            sample_file=args.sample,
            min_upload=args.min_upload,
            min_download=args.min_download,
            concurrency=args.concurrency,
            timeout=args.timeout,
            top_n=args.top_servers,
        )
        sys.exit(0)

    if args.sample and args.input:
        run_two_phase_scan(
            sample_file=args.sample,
            main_file=args.input,
            output_file=args.output,
            checkpoint_file=args.checkpoint,
            min_upload=args.min_upload,
            min_download=args.min_download,
            concurrency=args.concurrency,
            timeout=args.timeout,
            top_n=args.top_servers,
            limit=args.limit,
        )
        return

    if args.input and args.domain:
        run_single_server_scan(
            main_file=args.input,
            domain=args.domain,
            output_file=args.output,
            checkpoint_file=args.checkpoint,
            min_upload=args.min_upload,
            min_download=args.min_download,
            concurrency=args.concurrency,
            timeout=args.timeout,
            limit=args.limit,
        )
        return

    print("Run without arguments for interactive menu.")
    print("Or use --help for CLI options.")
    sys.exit(1)


if __name__ == '__main__':
    main()