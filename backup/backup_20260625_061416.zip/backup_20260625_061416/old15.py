#!/data/data/com.termux/files/usr/bin/python3
# better_dedupe_and_groups.py                           # هدف: یکتاسازی قوی، حذف ناقص‌ها، گروه‌بندی بهتر (GoodPing / Fastest / Backup / Selector)                         import os, re, json, yaml, subprocess, base64, socket, time, hashlib
from urllib.parse import urlparse, parse_qs             from concurrent.futures import ThreadPoolExecutor, as_completed                                                                                                         # ---------- paths & editor (همان رفتار نمونه) ----------  
BASE_DIR = "/storage/emulated/0/Download/Akbar98"       os.makedirs(BASE_DIR, exist_ok=True)                    INPUT_PATH = os.path.join(BASE_DIR, "input.txt")        with open(INPUT_PATH, "w", encoding="utf-8") as f: f.write("")                                                  subprocess.call(["nano", INPUT_PATH])                                                                           out_folder = input("Enter output folder name in Download: ").strip()
if not out_folder:                                          print("Folder name required."); exit(1)             OUT_DIR = os.path.join("/storage/emulated/0/Download", out_folder)                                              os.makedirs(OUT_DIR, exist_ok=True)
                                                        out_name = input("Enter output file name (without extension): ").strip()
if not out_name:
    print("File name required."); exit(1)
OUT_PATH = os.path.join(OUT_DIR, f"{out_name}.yaml")
                                                     
# ---------- helpers ----------
def b64fix(s: str) -> str:
    s = s.strip().replace("\n", "").replace(" ", "")
    pad = len(s) % 4
    if pad:
        s += "=" * (4 - pad)
    return s

def safe_int(x, default=0):
    try:
        return int(x)
    except:
        return default

def sanitize(s: str) -> str:
    if not s:
        return ""
    return re.sub(r"[^A-Za-z0-9_\- .]", "", str(s)).strip()

_used_keys = set()
_used_names = set()
def uniq_name(base: str) -> str:
    base = sanitize(base) or "Proxy"
    name = base
    i = 2
    while name in _used_names:
        name = f"{base} {i}"; i += 1
    _used_names.add(name)
    return name

def canonical_key(proxy: dict) -> str:
    """ساخت کلید کاننیکال برای یکتاسازی: protocol|server:port|id/password|network|tls"""
    proto = proxy.get("type","").lower()
    server = proxy.get("server","").lower()
    port = str(int(proxy.get("port",0)))
    if proto in ("vless","vmess"):
        ident = proxy.get("uuid","")
    elif proto == "trojan":
        ident = proxy.get("password","")
    elif proto in ("ss","shadowsocks"):
        ident = proxy.get("password","") + "|" + proxy.get("cipher","")
    else:
        ident = proxy.get("password","")
    net = proxy.get("network","tcp")
    tls = "tls" if proxy.get("tls") else "notls"
    key = "|".join([proto, f"{server}:{port}", ident, net, tls])
    # hash to keep keys short
    return hashlib.sha1(key.encode()).hexdigest()

def tail(s: str, n=6):
    if not s:
        return ""
    s2 = re.sub(r"[-]", "", s)
    return s2[-n:] if len(s2) >= n else s2

# ---------- health: TCP ping ----------
def tcp_ping_ms(host, port, timeout=2.0):
    try:
        start = time.monotonic()
        sock = socket.create_connection((host, int(port)), timeout=timeout)
        sock.close()
        return int((time.monotonic() - start) * 1000)
    except Exception:
        return None

# ---------- parse input ----------
try:
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f if ln.strip()]
except Exception:
    lines = []

raw_proxies = []

# support JSON fragments and line links
def extract_json_objects(text):
    objs, stack, start = [], [], None
    for i, c in enumerate(text):
        if c == '{':
            if not stack:
                start = i
            stack.append(c)
        elif c == '}':
            if stack:
                stack.pop()
                if not stack and start is not None:
                    objs.append(text[start:i+1])
                    start = None
    return objs

# read whole file for JSON fragments
whole = "\n".join(lines)
for frag in extract_json_objects(whole):
    try:
        obj = json.loads(frag)
    except:
        continue
    for ob in obj.get("outbounds", []) or []:
        proto = (ob.get("protocol") or "").lower()
        if proto not in ("vless", "vmess", "trojan", "shadowsocks"):
            continue
        stream = ob.get("streamSettings") or {}
        net = (stream.get("network") or "tcp").lower()
        security = (stream.get("security") or "").lower()
        tls_flag = security in ("tls", "reality")
        # vless/vmess
        if proto in ("vless", "vmess"):
            try:
                vnext = (ob.get("settings") or {}).get("vnext", [])[0]
                user = (vnext.get("users") or [])[0]
            except Exception:
                continue
            server = vnext.get("address") or ""
            port = safe_int(vnext.get("port"), 0)
            uid = user.get("id") or ""
            if not (server and port and uid):
                continue
            p = {"type": proto, "server": server, "port": port, "network": net}
            p["uuid"] = uid
            if proto == "vless":
                p["encryption"] = "none"
            else:
                p["alterId"] = safe_int(user.get("alterId", user.get("aid", 0)))
                p["cipher"] = user.get("cipher", "auto")
            if tls_flag:
                p["tls"] = True
                p["servername"] = (stream.get("tlsSettings") or {}).get("serverName") or server
            if net == "ws":
                ws = stream.get("wsSettings") or {}
                p["ws-opts"] = {"path": ws.get("path") or "/"}
            raw_proxies.append(p)
        elif proto == "trojan":
            try:
                s = (ob.get("settings") or {}).get("servers", [])[0]
            except Exception:
                continue
            server = s.get("address") or ""
            port = safe_int(s.get("port"), 0)
            pwd = s.get("password") or ""
            if not (server and port and pwd):
                continue
            p = {"type": "trojan", "server": server, "port": port, "password": pwd, "network": "tcp", "tls": True}
            raw_proxies.append(p)
        elif proto == "shadowsocks":
            try:
                s = (ob.get("settings") or {}).get("servers", [])[0]
            except Exception:
                continue
            server = s.get("address") or ""
            port = safe_int(s.get("port"), 0)
            cipher = s.get("method") or s.get("cipher") or ""
            password = s.get("password") or ""
            if not (server and port and cipher and password):
                continue
            p = {"type": "ss", "server": server, "port": port, "cipher": cipher, "password": password, "network": "tcp"}
            raw_proxies.append(p)

# parse line links (vless, vmess, trojan, ss)
for line in lines:
    try:
        if line.startswith("vless://"):
            parsed = urlparse(line)
            uid = parsed.username or ""
            host = parsed.hostname or ""
            port = parsed.port or 443
            q = parse_qs(parsed.query)
            if not (uid and host and port):
                continue
            net = (q.get("type", ["tcp"])[0] or "tcp").lower()
            tls_flag = (q.get("security", [""])[0] or "").lower() in ("tls","reality")
            p = {"type": "vless", "server": host, "port": int(port), "uuid": uid, "network": net}
            if tls_flag:
                p["tls"] = True
                p["servername"] = q.get("sni", [host])[0]
            if net == "ws":
                p["ws-opts"] = {"path": q.get("path", ["/"])[0]}
            raw_proxies.append(p)
        elif line.startswith("vmess://"):
            payload = line[8:]
            try:
                decoded = base64.b64decode(b64fix(payload)).decode(errors="ignore")
                info = json.loads(decoded)
            except:
                continue
            host = info.get("add") or info.get("server") or ""
            port = safe_int(info.get("port"), 0)
            uid = info.get("id") or ""
            if not (host and port and uid):
                continue
            net = (info.get("net") or "tcp").lower()
            p = {"type": "vmess", "server": host, "port": port, "uuid": uid, "network": net}
            p["alterId"] = safe_int(info.get("aid", info.get("alterId", 0)))
            p["cipher"] = info.get("scy", info.get("cipher","auto"))
            if str(info.get("tls","")).lower() == "tls":
                p["tls"] = True; p["servername"] = info.get("sni") or host
            if net == "ws":
                p["ws-opts"] = {"path": info.get("path") or "/"}
            raw_proxies.append(p)
        elif line.startswith("trojan://"):
            parsed = urlparse(line)
            pwd = parsed.username or ""
            host = parsed.hostname or ""
            port = parsed.port or 443
            if not (pwd and host and port):
                continue
            p = {"type":"trojan","server":host,"port":int(port),"password":pwd,"network":"tcp","tls":True}
            raw_proxies.append(p)
        elif line.startswith("ss://"):
            try:
                after = line[5:]
                if "@" in after and ":" in after.split("@",1)[0]:
                    cred, rest = after.split("@",1)
                    method, password = cred.split(":",1)
                    host_port = rest.split("#",1)[0]
                    if ":" not in host_port: continue
                    host, port = host_port.rsplit(":",1)
                else:
                    if "@" not in after: continue
                    b64cred, rest = after.split("@",1)
                    method_password = base64.urlsafe_b64decode(b64fix(b64cred)).decode()
                    method, password = method_password.split(":",1)
                    host_port = rest.split("#",1)[0]
                    host, port = host_port.rsplit(":",1)
                port = safe_int(port.strip(),0)
                p = {"type":"ss","server":host.strip(),"port":port,"cipher":method.strip(),"password":password.strip(),"network":"tcp"}
                raw_proxies.append(p)
            except:
                continue
    except:
        continue

# ---------- dedupe + assign names ----------
deduped = {}
final_list = []
for rp in raw_proxies:
    # discard obviously invalid
    if not rp.get("server") or not rp.get("port"):
        continue
    key = canonical_key(rp)
    if key in deduped:
        # merge some missing fields if needed (keep first but fill blanks)
        existing = deduped[key]
        for k,v in rp.items():
            if not existing.get(k) and v:
                existing[k]=v
        continue
    # assign name
    base = f"{rp.get('type','proxy')}-{rp.get('server')}-{tail(str(rp.get('port')))}"
    name = uniq_name(base)
    rp["name"] = name
    deduped[key] = rp
    final_list.append(rp)

proxies = final_list  # proxies ready (but without ping yet)

# ---------- parallel TCP ping (attach ping & status) ----------
def check_ping_attach(p):
    host = p.get("server")
    port = p.get("port")
    if not host or not port:
        p["ping"] = None; p["status"] = "dead"; return p
    lat = tcp_ping_ms(host, port, timeout=3.0)
    if lat is None:
        p["ping"] = None; p["status"] = "dead"
    else:
        p["ping"] = lat; p["status"] = "ok"
    return p

results = []
if proxies:
    max_workers = min(60, len(proxies))
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(check_ping_attach, p): p for p in proxies}
        for fut in as_completed(futures):
            try:
                results.append(fut.result())
            except:
                pass

# keep original order but updated
name_map = {p["name"]: p for p in results} if results else {p["name"]: p for p in proxies}
final_proxies = [name_map.get(p["name"], p) for p in proxies]


good = [p for p in final_proxies if p.get("status") == "ok"]
good_sorted = sorted(good, key=lambda x: x.get("ping", 99999))
proxy_names = [p["name"] for p in final_proxies]

# ensure non-empty lists for groups (fallback to DIRECT)
good_list_names = [p["name"] for p in good_sorted] if good_sorted else ["DIRECT"]
proxy_names_nonempty = proxy_names if proxy_names else ["DIRECT"]

# ---------- groups construction ----------

Good_Ping = "🥁بهترین پین🥁"
Fastest = "🥁سریع ترین♨️"
Backup = "🌟بکاپ گیری🌟"
Auto = "📌اتوماتیک تست📌"
Selector = "🌐انتخاب دستی🌐"
Direct = "🔗دایرکت🔗"
Block = "🎯بلوک🎯"

proxy_groups = [

{"name": Selector, "type": "select", "proxies": [Fastest, Good_Ping, Auto, "DIRECT"] + proxy_names},

    {"name": Good_Ping, "type": "select", "proxies": good_list_names},

    {"name": Fastest, "type": "fallback", "url": "https://www.gstatic.com/generate_204", "interval": 30, "tolerance": 80, "proxies": proxy_names_nonempty},

{"name": Auto, "type": "url-test", "url": "https://www.gstatic.com/generate_204", "interval": 20, "tolerance": 80, "proxies": proxy_names_nonempty},

    {"name": Backup, "type": "fallback", "url": "https://www.gstatic.com/generate_204", "interval": 10, "tolerance": 80, "proxies": ["DIRECT"] + proxy_names_nonempty},

    {"name": Direct, "type": "select", "proxies": ["DIRECT"]},

    {"name": Block, "type": "select", "proxies": ["REJECT", "DIRECT"]}
]

config = {
    "proxies": final_proxies,
    "proxy-groups": proxy_groups,
    "rules": [f"MATCH,{Selector}"]
}

with open(OUT_PATH, "w", encoding="utf-8") as f:
    yaml.safe_dump(config, f, allow_unicode=True, sort_keys=False)

# clear input
with open(INPUT_PATH, "w", encoding="utf-8") as f:
    f.write("")

print(f"[✅] Saved {len(final_proxies)} proxies to {OUT_PATH}")
