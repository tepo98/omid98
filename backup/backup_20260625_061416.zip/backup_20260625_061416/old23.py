#!/data/data/com.termux/files/usr/bin/python3
# -*- coding: utf-8 -*-
import os, re, json, socket, time, subprocess, base64, yaml, threading, sys
from urllib.parse import urlparse, parse_qs, unquote
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import deque

# ---------------- paths ----------------
BASE_DIR = "/storage/emulated/0/Download/ClashMetaParser"
os.makedirs(BASE_DIR, exist_ok=True)
INPUT_PATH = os.path.join(BASE_DIR, "input.txt")

# باز کردن ادیتور nano برای وارد کردن لیست لینک‌ها
with open(INPUT_PATH, "w", encoding="utf-8") as f:
    f.write("")
try:
    subprocess.call(["nano", INPUT_PATH])
except:
    pass

out_folder = input("Enter output folder name in Download: ").strip() or "ClashMetaExport"
OUT_DIR = os.path.join("/storage/emulated/0/Download", out_folder)
os.makedirs(OUT_DIR, exist_ok=True)

out_name = input("Enter output file name (without extension): ").strip() or "proxies"
OUT_PATH = os.path.join(OUT_DIR, f"{out_name}.yaml")
# =================== HELPERS ===================
def b64fix(s):
    s = s.replace("-", "+").replace("_", "/")
    return s + "=" * (-len(s) % 4)

def safe_int(x, default=0):
    try:
        return int(x)
    except:
        return default

def sanitize(s):
    return re.sub(r'[\n\r]+', '', str(s).strip())

_used_names = set()
def uniq_name(base):
    name = base
    i = 1
    while name in _used_names:
        name = f"{base}-{i}"
        i += 1
    _used_names.add(name)
    return name

def tail(s, n=6):
    return s[-n:] if len(s) > n else s

def split_host_port(hostport: str):
    if ':' in hostport:
        host, port = hostport.split(":", 1)
        return host.strip(), safe_int(port)
    return hostport.strip(), None

def tcp_ping_once(host, port, timeout=1.0):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        start = time.time()
        sock.connect((host, port))
        sock.close()
        return int((time.time() - start) * 1000)
    except:
        return None

def tcp_ping_median(host, port, attempts=3):
    pings = []
    for _ in range(attempts):
        p = tcp_ping_once(host, port)
        if p is not None: pings.append(p)
    if pings:
        pings.sort()
        mid = len(pings) // 2
        return pings[mid] if len(pings) % 2 else (pings[mid-1]+pings[mid])//2
    return None

def attach_ping(proxy):
    proxy['ping'] = tcp_ping_median(proxy['server'], proxy['port'])
    proxy['status'] = "ok" if proxy['ping'] is not None else "fail"
    return proxy
# =================== PARSERS ===================
def parse_vless(line):
    # خط vless://UUID@host:port?params#name
    try:
        if not line.startswith("vless://"): return None
        raw = line[7:]
        name = None
        if "#" in raw:
            raw, name = raw.split("#",1)
            name = unquote(name)
        userhost, _, params = raw.partition("?")
        uuid, _, hostport = userhost.partition("@")
        host, port = split_host_port(hostport)
        param_dict = dict([p.split("=",1) for p in params.split("&") if "=" in p])
        proxy = {
            "name": uniq_name(name or f"VLESS-{host}-{port}"),
            "type": "vless",
            "server": host,
            "port": safe_int(port,443),
            "uuid": uuid,
            "packet-encoding": "packetaddr",
            "ip-version": "dual",
            "tls": param_dict.get("tls","false").lower()=="true",
            "network": param_dict.get("type","tcp"),
            "tfo": True,
            "mptcp": True
        }
        if proxy['network']=="ws":
            ws_opts={"path": param_dict.get("path","/"), "headers":{"Host":param_dict.get("host",host)}}
            proxy["ws-opts"] = ws_opts
        proxy["skip-cert-verify"] = False
        return proxy
    except: return None

def parse_trojan(line):
    # trojan://password@host:port?params#name
    try:
        if not line.startswith("trojan://"): return None
        raw = line[9:]
        name = None
        if "#" in raw:
            raw, name = raw.split("#",1)
            name = unquote(name)
        userhost, _, params = raw.partition("?")
        password, _, hostport = userhost.partition("@")
        host, port = split_host_port(hostport)
        param_dict = dict([p.split("=",1) for p in params.split("&") if "=" in p])
        proxy = {
            "name": uniq_name(name or f"Trojan-{host}-{port}"),
            "type": "trojan",
            "server": host,
            "port": safe_int(port,443),
            "password": password,
            "ip-version": "dual",
            "tls": param_dict.get("tls","true").lower()=="true",
            "network": param_dict.get("type","tcp"),
            "tfo": True,
            "mptcp": True
        }
        if proxy['network']=="ws":
            ws_opts={"path": param_dict.get("path","/"), "headers":{"Host":param_dict.get("host",host)}}
            proxy["ws-opts"] = ws_opts
        proxy["skip-cert-verify"] = False
        return proxy
    except: return None

def parse_ss(line):
    # Shadowsocks ss://base64#name
    try:
        if not line.startswith("ss://"): return None
        raw = line[5:]
        name=None
        if "#" in raw:
            raw,name=raw.split("#",1)
            name=unquote(name)
        decoded=base64.urlsafe_b64decode(b64fix(raw)).decode()
        method_password, _, hostport = decoded.partition("@")
        method,password=method_password.split(":",1)
        host, port=split_host_port(hostport)
        proxy={
            "name": uniq_name(name or f"SS-{host}-{port}"),
            "type":"ss",
            "server":host,
            "port":safe_int(port,8388),
            "cipher":method,
            "password":password,
            "udp":True
        }
        return proxy
    except: return None
def parse_ssr(line):
    # SSR: ssr://base64
    try:
        if not line.startswith("ssr://"): return None
        raw=line[6:]
        decoded=base64.urlsafe_b64decode(b64fix(raw)).decode()
        parts=decoded.split(":")
        if len(parts)<6: return None
        host, port, protocol, method, obfs, password_encoded=parts[:6]
        password=base64.urlsafe_b64decode(b64fix(password_encoded)).decode()
        proxy={
            "name": uniq_name(f"SSR-{host}-{port}"),
            "type":"ssr",
            "server":host,
            "port":safe_int(port),
            "protocol":protocol,
            "cipher":method,
            "obfs":obfs,
            "password":password
        }
        return proxy
    except: return None

def parse_hysteria1(line):
    # hysteria://server:port?params#name
    try:
        if not line.startswith("hysteria://"): return None
        raw=line[10:]
        name=None
        if "#" in raw:
            raw,name=raw.split("#",1)
            name=unquote(name)
        hostport, _, params=raw.partition("?")
        host, port=split_host_port(hostport)
        param_dict=dict([p.split("=",1) for p in params.split("&") if "=" in p])
        proxy={
            "name":uniq_name(name or f"Hysteria-{host}-{port}"),
            "type":"hysteria",
            "server":host,
            "port":safe_int(port,443),
            "auth":param_dict.get("auth",""),
            "protocol":param_dict.get("protocol","udp"),
            "obfs":param_dict.get("obfs","udp"),
            "tls":param_dict.get("tls","true").lower()=="true",
            "udp":True
        }
        return proxy
    except: return None

def parse_hysteria2(line):
    return parse_hysteria1(line)

def parse_tuic(line):
    # tuic://...
    try:
        if not line.startswith("tuic://"): return None
        return {"name":uniq_name("TUIC"), "type":"tuic"}  # ساده شده
    except: return None

def parse_wireguard(line):
    # wg:// base64
    try:
        if not line.startswith("wg://"): return None
        return {"name":uniq_name("WireGuard"), "type":"wireguard"}  # ساده شده
    except: return None

def parse_http(line):
    if line.startswith("http://") or line.startswith("https://"):
        return {"name":uniq_name("HTTP"),"type":"http","server":line}
    return None

def parse_socks(line):
    if line.startswith("socks://") or line.startswith("socks5://"):
        return {"name":uniq_name("SOCKS"),"type":"socks","server":line}
    return None

def parse_line_any(line):
    for f in [parse_vless, parse_trojan, parse_ss, parse_ssr, parse_hysteria1, parse_hysteria2, parse_tuic, parse_wireguard, parse_http, parse_socks]:
        p=f(line)
        if p: return p
    return None

def parse_any(input_data):
    proxies=[]
    for line in input_data.splitlines():
        line=line.strip()
        if not line: continue
        p=parse_line_any(line)
        if p: proxies.append(p)
    return proxies

def dedupe_proxies(proxies):
    seen=set()
    result=[]
    for p in proxies:
        key=(p.get("type"), p.get("server"), p.get("port"), p.get("name"))
        if key not in seen:
            seen.add(key)
            result.append(p)
    return result

def to_clash_meta(proxy):
    # تبدیل dict proxy به فرمت Clash Meta
    mapping={"vless":"vless","trojan":"trojan","ss":"ss","ssr":"ssr","hysteria":"hysteria","tuic":"tuic","wireguard":"wireguard","http":"http","socks":"socks"}
    t=mapping.get(proxy.get("type"))
    if not t: return None
    meta={"name":proxy.get("name"),"type":t,"server":proxy.get("server"),"port":proxy.get("port")}
    if t=="vless":
        meta.update({k:proxy[k] for k in ["uuid","tls","network","ws-opts","tfo","mptcp","skip-cert-verify"] if k in proxy})
    elif t=="trojan":
        meta.update({k:proxy[k] for k in ["password","tls","network","ws-opts","tfo","mptcp","skip-cert-verify"] if k in proxy})
    elif t=="ss":
        meta.update({k:proxy[k] for k in ["cipher","password","udp"] if k in proxy})
    elif t=="ssr":
        meta.update({k:proxy[k] for k in ["cipher","protocol","obfs","password"] if k in proxy})
    elif t=="hysteria":
        meta.update({k:proxy[k] for k in ["auth","protocol","obfs","tls","udp"] if k in proxy})
    return meta
def generate_clash_meta_yaml(input_text, out_path):
    parsed=dedupe_proxies(parse_any(input_text))
    print(f"[INFO] Parsed {len(parsed)} unique proxies")
    # اضافه کردن ping و status
    with ThreadPoolExecutor(max_workers=min(50,len(parsed))) as ex:
        futures=[ex.submit(attach_ping,p) for p in parsed]
        results=[f.result() for f in as_completed(futures)]
    results.sort(key=lambda x: x.get("ping") if x.get("ping") else 999999)
    clash_proxies=[to_clash_meta(p) for p in results if to_clash_meta(p)]
    proxy_names=[p['name'] for p in clash_proxies]

    # گروه‌ها
    selector="✅ Selector"
    best_ping="💦 Best Ping 💥"
    config={
        "proxies": clash_proxies,
        "proxy-groups":[
            {"name":selector,"type":"select","proxies":[best_ping]+proxy_names},
            {"name":best_ping,"type":"url-test","url":"https://www.gstatic.com/generate_204","interval":30,"tolerance":50,"proxies":proxy_names}
        ],
        "rules":[f"MATCH,{selector}"]
    }
    # ذخیره YAML
    with open(out_path,"w",encoding="utf-8") as f:
        yaml.safe_dump(config,f,allow_unicode=True,sort_keys=False)
    print(f"[✅] Clash Meta YAML saved: {out_path}")
if __name__=="__main__":
    if len(sys.argv)>1:
        path=sys.argv[1]
        with open(path,"r",encoding="utf-8") as f: text=f.read()
    else:
        print("Paste your links (Ctrl-D to finish):")
        text=sys.stdin.read()
    if not text.strip():
        print("[ERROR] No input."); sys.exit(1)
    generate_clash_meta_yaml(text, OUT_PATH)


