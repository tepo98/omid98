#!/data/data/com.termux/files/usr/bin/python3
# -*- coding: utf-8 -*-

import os, re, json, socket, time, subprocess, base64, yaml, random
from urllib.parse import unquote, urlparse, parse_qs
from concurrent.futures import ThreadPoolExecutor, as_completed

# =================== PATHS ===================
BASE_DIR = "/storage/emulated/0/Download/Akbar98"
os.makedirs(BASE_DIR, exist_ok=True)
INPUT_PATH = os.path.join(BASE_DIR, "input_mobile.txt")

with open(INPUT_PATH, "w", encoding="utf-8") as f:
    f.write("")

try:
    subprocess.call(["nano", INPUT_PATH])
except:
    pass

out_folder = input("Enter output folder name in Download: ").strip()
if not out_folder:
    print("Folder name required.")
    exit(1)

OUT_DIR = os.path.join("/storage/emulated/0/Download", out_folder)
os.makedirs(OUT_DIR, exist_ok=True)

out_name = input("Enter output file name (without extension): ").strip()
if not out_name:
    print("File name required.")
    exit(1)

OUT_PATH = os.path.join(OUT_DIR, f"{out_name}.yaml")

# =================== HELPERS ===================
def b64fix(s):
    if not s:
        return ""
    s = s.strip().replace("\n", "").replace(" ", "")
    s = s.replace("-", "+").replace("_", "/")
    pad = len(s) % 4
    if pad:
        s += "=" * (4 - pad)
    return s

def safe_int(x, default=0):
    try:
        return int(x)
    except:
        return default

_used = set()
def uniq_name(x):
    base = re.sub(r"[^A-Za-z0-9_\- .\u0600-\u06FF]", "", x or "")
    if not base:
        base = "Proxy"
    name = base
    i = 2
    while name in _used:
        name = f"{base} {i}"
        i += 1
    _used.add(name)
    return name

def tail(x, n=6):
    s = re.sub(r"-", "", str(x or ""))
    return s[-n:]

# =================== SUPER ADVANCED PING ===================
def resolve_fast(host, retries=3):
    for _ in range(retries):
        try:
            return socket.gethostbyname(host)
        except:
            time.sleep(0.05)
    return None

def tcp_ping(ip, port, timeout):
    try:
        s = socket.socket()
        s.settimeout(timeout)
        t0 = time.monotonic()
        s.connect((ip, int(port)))
        s.close()
        return int((time.monotonic() - t0) * 1000)
    except:
        return None

def ping_proxy(host, port, attempts=5):
    ip = resolve_fast(host)
    if not ip:
        return None
    results = []
    timeout = 0.9
    for i in range(attempts):
        ms = tcp_ping(ip, port, timeout)
        if ms is None and i == 0:
            timeout = 1.8
            ms = tcp_ping(ip, port, timeout)
        if ms is None:
            continue
        results.append(ms)
        if ms < 180: timeout = 0.6
        if ms < 120: timeout = 0.45
        if ms < 80: timeout = 0.30
        time.sleep(0.05 + random.random() * 0.03)
    if not results:
        return None
    results = sorted(results)
    if len(results) > 2:
        results = results[1:-1]
    return min(results)

def attach_ping(p):
    ms = ping_proxy(p["server"], p["port"])
    p["ping"] = ms
    p["status"] = "ok" if ms is not None else "dead"
    return p

# =================== SUPER ADVANCED PARSER ===================
def b64decode_auto(s):
    s = s.replace("-", "+").replace("_", "/")
    pad = len(s) % 4
    if pad:
        s += "=" * (4 - pad)
    try:
        return base64.b64decode(s).decode()
    except:
        return None

def parse_vless(line):
    if not line.startswith("vless://"):
        return None
    try:
        raw = line[8:]
        frag = ""
        if "#" in raw:
            raw, frag = raw.split("#", 1)
            frag = unquote(frag)
        main, _, qs = raw.partition("?")
        uid, rest = main.split("@", 1)
        host, port = rest.split(":", 1)
        q = parse_qs(qs)
        q = {k: v[0] for k, v in q.items()}
        p = {
            "type": "vless",
            "name": uniq_name(frag or f"vless-{host}-{tail(uid)}"),
            "server": host,
            "port": safe_int(port),
            "uuid": uid,
            "udp": True,
            "tls": False,
            "network": q.get("type", "tcp")
        }
        sec = q.get("security", "").lower()
        if sec in ("tls", "reality"):
            p["tls"] = True
            p["security"] = sec
            p["sni"] = q.get("sni") or q.get("servername") or host
            p["servername"] = p["sni"]
        if sec == "reality":
            if q.get("pbk"): p["pbk"] = q["pbk"]
            if q.get("sid"): p["sid"] = q["sid"]
            if q.get("fp"): p["fingerprint"] = q["fp"]
            if q.get("spx"): p["spx"] = q["spx"]
        if p["network"] == "ws":
            p["ws-opts"] = {"path": q.get("path","/"), "headers":{"Host":q.get("host",host)}}
        if p["network"] == "grpc":
            p["grpc-opts"] = {"serviceName":q.get("serviceName",""), "mode":q.get("mode","gun")}
        if p["network"] in ("h2","http"):
            p["http-opts"] = {"path":q.get("path","/")}
        return p
    except:
        return None

def parse_vmess(line):
    if not line.startswith("vmess://"):
        return None
    try:
        raw = line[8:]
        js = None
        decoded = b64decode_auto(raw)
        if decoded:
            try: js = json.loads(decoded)
            except: pass
        if js is None:
            try: js = json.loads(unquote(raw))
            except: return None
        p = {
            "type": "vmess",
            "name": uniq_name(js.get("ps") or f"vmess-{js.get('add')}-{tail(js.get('id'))}"),
            "server": js.get("add"),
            "port": safe_int(js.get("port")),
            "uuid": js.get("id"),
            "alterId": safe_int(js.get("aid",0)),
            "cipher": js.get("scy","auto"),
            "udp": True,
            "tls": js.get("tls")=="tls",
            "network": js.get("net","tcp")
        }
        if p["tls"]:
            p["sni"] = js.get("sni") or js.get("host") or p["server"]
        if p["network"] == "ws":
            p["ws-opts"] = {"path":js.get("path","/"), "headers":{"Host":js.get("host",p["server"])}}
        if p["network"] == "grpc":
            p["grpc-opts"] = {"serviceName":js.get("serviceName",""), "mode":js.get("mode","gun")}
        return p
    except:
        return None

def parse_trojan(line):
    if not line.startswith("trojan://"):
        return None
    try:
        raw = line[9:]
        frag=""
        if "#" in raw:
            raw, frag = raw.split("#",1)
            frag=unquote(frag)
        main, _, qs = raw.partition("?")
        pwd, rest = main.split("@",1)
        host, port = rest.split(":",1)
        q = parse_qs(qs); q={k:v[0] for k,v in q.items()}
        p = {
            "type":"trojan",
            "name":uniq_name(frag or f"trojan-{host}-{tail(pwd)}"),
            "server":host,
            "port":safe_int(port),
            "password":pwd,
            "udp":True,
            "tls":True,
            "sni":q.get("sni",host)
        }
        net = q.get("type")
        if net=="grpc":
            p["network"]="grpc"; p["grpc-opts"]={"serviceName":q.get("serviceName","")}
        elif net=="ws":
            p["network"]="ws"; p["ws-opts"]={"path":q.get("path","/")}
        else:
            p["network"]="tcp"
        return p
    except:
        return None

def parse_ss(line):
    if not line.startswith("ss://"):
        return None
    try:
        raw=line[5:]; frag=""
        if "#" in raw: raw,frag=raw.split("#",1); frag=unquote(frag)
        if "@" in raw:
            creds, addr = raw.split("@",1)
            decoded=b64decode_auto(creds)
            if decoded: method,pwd=decoded.split(":",1)
            else: method,pwd=creds.split(":",1)
            host, port=addr.split(":",1)
        else:
            decoded=b64decode_auto(raw)
            if not decoded: return None
            pre, addr=decoded.split("@",1)
            method,pwd=pre.split(":",1)
            host,port=addr.split(":",1)
        p={
            "type":"ss",
            "name":uniq_name(frag or f"ss-{host}-{port}"),
            "server":host,
            "port":safe_int(port),
            "cipher":method,
            "password":pwd,
            "udp":True
        }
        return p
    except:
        return None

def parse_hysteria(line):
    if not (line.startswith("hysteria://") or line.startswith("hy2://")):
        return None
    try:
        is_hy2=line.startswith("hy2://")
        raw=line.split("://",1)[1]; frag=""
        if "#" in raw: raw,frag=raw.split("#",1); frag=unquote(frag)
        main, _, qs = raw.partition("?")
        host, port = main.split(":",1)
        q=parse_qs(qs); q={k:v[0] for k,v in q.items()}
        p={"type":"hysteria2" if is_hy2 else "hysteria","name":uniq_name(frag or f"hy-{host}-{port}"),"server":host,"port":safe_int(port),"udp":True}
        if q.get("auth"): p["auth"]=q["auth"]
        if q.get("sni"): p["sni"]=q["sni"]
        if q.get("alpn"): p["alpn"]=q["alpn"]
        if q.get("obfs"): p["obfs"]=q["obfs"]
        if q.get("pin"): p["pin"]=q["pin"]
        return p
    except:
        return None

def parse_link(line):
    line=line.strip()
    if not line: return None
    parsers=[parse_vless,parse_vmess,parse_trojan,parse_ss,parse_hysteria]
    for parser in parsers:
        p=parser(line)
        if p: return p
    try: return json.loads(line)
    except: return None

# =================== VALIDATE PROXY ===================
def validate_proxy(p):
    if not isinstance(p,dict): return False
    if not p.get("type") or not p.get("server") or not (1<=int(p.get("port",0))<=65535): return False
    t=p["type"]
    if t in ("vless","vmess") and not p.get("uuid"): return False
    if t=="trojan" and not p.get("password"): return False
    if t=="ss" and (not p.get("cipher") or not p.get("password")): return False
    return True

# =================== READ INPUT ===================
try:
    with open(INPUT_PATH,"r",encoding="utf-8") as f:
        content=f.read()
except:
    content=""

lines=[l.strip() for l in content.splitlines() if l.strip()]
proxies=[]
for line in lines:
    p=parse_link(line)
    if validate_proxy(p): proxies.append(p)

if not proxies:
    print("[ERROR] No valid proxies found."); exit(1)

print(f"[INFO] Valid proxies found: {len(proxies)}")

# =================== PING ALL ===================
with ThreadPoolExecutor(max_workers=38) as ex:
    futures = [ex.submit(attach_ping, p) for p in proxies]
    proxies = [f.result() for f in as_completed(futures)]

alive = [p for p in proxies if p["status"] == "ok"]

if not alive:
    print("[ERROR] All proxies are dead.")
    exit(1)

# مرتب‌سازی بر اساس پینگ
alive_sorted = sorted(
    alive,
    key=lambda x: x["ping"] if x["ping"] is not None else 99999
)

# فقط بهترین‌ها وارد رقابت شوند
top_proxies = alive_sorted[:14]

proxy_names = [p["name"] for p in top_proxies]

# =================== OUTPUT YAML ===================
yaml_data = {
    "proxies": alive_sorted,
    "proxy-groups": [
        {
            "name": "🪀 Select",
            "type": "select",
            "proxies": [
                "🚀 Super-Fast",
                "DIRECT"
            ] + [p["name"] for p in alive_sorted]
        },
        {
            "name": "🚀 Super-Fast",
            "type": "url-test",
            "url": "http://www.gstatic.com/generate_204",
            "interval": 600,
            "tolerance": 100,
            "proxies": [p["name"] for p in alive_sorted[:10]]
        }
    ],
    "rules": [
        "MATCH,🪀 Select"
    ]
}

with open(OUT_PATH, "w", encoding="utf-8") as f:
    yaml.dump(
        yaml_data,
        f,
        allow_unicode=True,
        sort_keys=False
    )

print(f"[INFO] Alive proxies: {len(alive_sorted)}")
print(f"[INFO] Super-Fast pool: {len(top_proxies)}")
print("[DONE] Saved:")
print(OUT_PATH)



