import socket
import time
from concurrent.futures import ThreadPoolExecutor
import subprocess

INPUT_FILE = "ips.txt"

PORT = 443
THREADS = 120
TOP = 30
MAX_LATENCY = 250

results = []
seen = set()

# ---------- load ----------
def load_ips():
    ips = []
    with open(INPUT_FILE, "r") as f:
        for line in f:
            ip = line.strip()
            if ":" in ip:
                ip = ip.split(":")[0]

            if ip and ip not in seen:
                seen.add(ip)
                ips.append(ip)
    return ips

# ---------- filter ----------
def is_valid(ip):
    # حذف private / invalid ranges
    bad = ("10.", "127.", "192.168.", "0.", "169.254.")
    return not ip.startswith(bad)

# ---------- test ----------
def test(ip):
    try:
        # first connect
        t1 = time.time()
        s = socket.socket()
        s.settimeout(1)
        s.connect((ip, PORT))
        s.close()
        ms1 = int((time.time() - t1) * 1000)

        # second connect (jitter check)
        t2 = time.time()
        s = socket.socket()
        s.settimeout(1)
        s.connect((ip, PORT))
        s.close()
        ms2 = int((time.time() - t2) * 1000)

        jitter = abs(ms1 - ms2)
        avg = (ms1 + ms2) // 2

        # score formula
        score = 100 - (avg // 4) - (jitter * 3)

        if avg <= MAX_LATENCY and score > 0:
            results.append((score, avg, ip))
            print(f"[OK] {ip} | {avg}ms | J:{jitter}")

    except:
        print(f"[FAIL] {ip}")

# ---------- main ----------
def main():
    ips = [ip for ip in load_ips() if is_valid(ip)]

    print("\n[+] NETWORK GOD PRO MAX STARTED...\n")

    with ThreadPoolExecutor(max_workers=THREADS) as ex:
        ex.map(test, ips)

    # sort
    results.sort(reverse=True)

    top = results[:TOP]
    clean = [x[2] for x in top]

    # save clean
    with open("clean.txt", "w") as f:
        f.write("\n".join(clean))

    # save port
    with open("port.txt", "w") as f:
        for ip in clean:
            f.write(f"{ip}:{PORT}\n")

    print("\n===== TOP IPS =====")
    for s, ms, ip in top:
        print(f"{ip} | {ms}ms | score:{s}")

    # clipboard
    subprocess.run("cat clean.txt port.txt | termux-clipboard-set", shell=True)

    print("\n[✓] COPIED TO CLIPBOARD (CLEAN + PORT)")
    print("[✓] DONE")

if __name__ == "__main__":
    main()
