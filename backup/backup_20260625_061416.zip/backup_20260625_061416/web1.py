import os
import webbrowser

# ===== ثابت مسیر =====
BASE_PATH = "/sdcard/Download/html"

def get_files():
    if not os.path.exists(BASE_PATH):
        print("Path not found!")
        return []

    return [f for f in os.listdir(BASE_PATH) if f.endswith(".html")]

def show(files):
    print("\n===== HTML LAUNCHER =====")
    for i, f in enumerate(files, 1):
        print(f"{i} - {f}")
    print("\n0 - Exit")

def open_file(files, index):
    try:
        path = os.path.join(BASE_PATH, files[index])
        url = "file://" + path
        print("\nOPEN:", url)
        webbrowser.open(url)
    except:
        print("Error opening file")

while True:
    files = get_files()

    if not files:
        print("No HTML files found!")
        break

    show(files)

    choice = input("\nSelect: ")

    if choice == "0":
        print("Exit...")
        break

    if choice.isdigit():
        i = int(choice) - 1
        if 0 <= i < len(files):
            open_file(files, i)
        else:
            print("Invalid number")
    else:
        print("Invalid input")
