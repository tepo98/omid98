#!/data/data/com.termux/files/usr/bin/python3
# -*- coding: utf-8 -*-
"""
Stable-first final script
- parsing for vless/vmess/trojan/shadowsocks and line links
- median tcp ping for initial accurate measurement
- RED filter: exclude ping None or <1ms or >300ms
- groups (Persian names): پایدارترین, پرسرعت ترین, فالبک ایده ال, انتخاب دستی, اتومات
- recheck loop (optional via RECHECK_INTERVAL_MIN) updates fallback ordering
- smart switch: prefers most stable proxies (low variance + low avg)
"""

import os, re, json, yaml, base64, socket, time, threading
from urllib.parse import urlparse, parse_qs
from concurrent.futures import ThreadPoolExecutor, as_completed

# ---------------- configuration (user prompts) ----------------
BASE_DIR = "/storage/emulated/0/Download/Akbar98"
os.makedirs(BASE_DIR, exist_ok=True)
INPUT_PATH = os.path.join(BASE_DIR, "input.txt")
with open(INPUT_PATH, "w", encoding="utf-8") as f:
    f.write("")

# try to open editor if available (non-fatal)
try:
    import subprocess
    subprocess.call(["nano", INPUT_PATH])
except Exception:
    pass

OUT_FOLDER = input("Enter output folder name in Download: ").strip()
if not OUT_FOLDER:
    print("Folder name required."); raise SystemExit(1)
OUT_DIR = os.path.join("/storage/emulated/0/Download", OUT_FOLDER)
os.makedirs(OUT_DIR, exist_ok=True)

OUT_NAME = input("Enter output file name (without extension): ").strip()
if not OUT_NAME:
    print("File name required."); raise SystemExit(1)
OUT_PATH = os.path.join(OUT_DIR, f"{OUT_NAME}.yaml")

try:
    PING_ATTEMPTS = int(input("PING_ATTEMPTS (suggest 5) [5]: ").strip() or "5")
except:
    PING_ATTEMPTS = 5
try:
    PING_TIMEOUT = float(input("PING_TIMEOUT sec per attempt (suggest 1.0) [1.0]: ").strip() or "1.0")
except:
    PING_TIMEOUT = 1.0
try:
    RECHECK_INTERVAL_MIN = int(input("RECHECK_INTERVAL_MIN minutes (0=off) [5]: ").strip() or "5")
except:
    RECHECK_INTERVAL_MIN = 5

try:
    FAST_MAX_MS = int(input("FAST_MAX_MS ms (green) [150]: ").strip() or "150")
except:
    FAST_MAX_MS = 150
try:
    STABLE_MAX_MS = int(input("STABLE_MAX_MS ms (yellow) [300]: ").strip() or "300")
except:
    STABLE_MAX_MS = 300

# fixed RED filter (do NOT prompt)
RED_MIN_MS = 1
RED_MAX_MS = 300
if STABLE_MAX_MS > RED_MAX_MS:
    STABLE_MAX_MS = RED_MAX_MS

MAX_WORKERS = 40
FAST_GROUP_LIMIT = 10
STABLE_GROUP_LIMIT = 12

# ---------------- helpers ----------------
def b64fix(s: str) -> str:
    s = (s or "").strip().replace("\n", "").replace(" ", "")
    pad = len(s) % 4
    if pad:
        s += "=" * (4 - pad)
    return s

def safe_int(x, default=0):
    try: return int(x)
    except: return default

def sanitize(s: str) -> str:
    if not s: return ""
    return re.sub(r"[^A-Za-z0-9_\- .]", "", str(s)).strip()

_used_names = set()
def uniq_name(base: str) -> str:
    base = sanitize(base) or "Proxy"
    name = base
    i = 2
    while name in _used_names:
        name = f"{base} {i}"; i += 1
    _used_names.add(name)
    return name

def tail(s: str, n=6):
    if not s: return ""
    s2 = re.sub(r"[-]", "", s)
    return s2[-n:] if len(s2) >= n else s2

# tcp connect measured in ms
def tcp_ping_once(host, port, timeout=PING_TIMEOUT):
    try:
        start = time.monotonic()
        sock = socket.create_connection((host, int(port)), timeout=timeout)
        sock.close()
        return int((time.monotonic() - start) * 1000)
    except Exception:
        return None

def tcp_ping_median(host, port, attempts=PING_ATTEMPTS, timeout=PING_TIMEOUT, gap=0.06):
    vals = []
    for _ in range(max(1, attempts)):
        v = tcp_ping_once(host, port, timeout)
        if v is not None:
            vals.append(v)
        time.sleep(gap)
    if not vals:
        return None
    vals.sort()
    mid = len(vals)//2
    if len(vals) % 2 == 1:
        return vals[mid]
    else:
        return int((vals[mid-1] + vals[mid]) / 2)

# extract JSON objects robustly
def extract_json_objects(text):
    objs, stack, start = [], [], None
    for i, c in enumerate(text):
        if c == "{":
            if not stack:
                start = i
            stack.append(c)
        elif c == "}":
            if stack:
                stack.pop()
                if not stack and start is not None:
                    objs.append(text[start:i+1])
                    start = None
    return objs

# ---------------- read input ----------------
try:
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        content = f.read()
except:
    content = ""

# parse proxies
proxies = []

# JSON fragments
for frag in extract_json_objects(content):
    try:
        obj = json.loads(frag)
    except:
        continue
    for ob in (obj.get("outbounds", []) or []):
        proto = (ob.get("protocol") or "").lower()
        if proto not in ("vless","vmess","trojan","shadowsocks"):
            continue
        stream = ob.get("streamSettings") or {}
        net = (stream.get("network") or "tcp").lower()
        security = (stream.get("security") or "").lower()
        tls_flag = security in ("tls","reality")

        if proto in ("vless","vmess"):
            try:
                vnext = (ob.get("settings") or {}).get("vnext", [])[0]
                user = (vnext.get("users") or [])[0]
            except Exception:
                continue
            server = vnext.get("address") or ""
            port = safe_int(vnext.get("port"), 0)
            uid = user.get("id") or ""
            if not (server and port and uid):
                continue
            name = uniq_name(f"{proto}-{server}-{tail(uid)}")
            p = {"name": name, "type": proto, "server": server, "port": port, "udp": True, "network": net}
            if proto == "vless":
                p["uuid"] = uid; p["encryption"] = "none"
            else:
                p["uuid"] = uid; p["alterId"] = safe_int(user.get("alterId", user.get("aid", 0))); p["cipher"] = user.get("cipher", "auto")
            if tls_flag:
                sni = (stream.get("tlsSettings") or {}).get("serverName") or (stream.get("realitySettings") or {}).get("serverName") or server
                p["tls"] = True; p["servername"] = sni
            if net == "ws":
                ws = stream.get("wsSettings") or {}
                path = ws.get("path") or "/"
                headers = ws.get("headers") or {}
                p["ws-opts"] = {"path": path}
                if headers: p["ws-opts"]["headers"] = headers
            if net == "grpc":
                grpc = stream.get("grpcSettings") or {}
                svc = grpc.get("serviceName") or ""
                if svc: p["grpc-opts"] = {"grpc-service-name": svc}
            proxies.append(p)

        elif proto == "trojan":
            try:
                s = (ob.get("settings") or {}).get("servers", [])[0]
            except:
                continue
            server = s.get("address") or ""
            port = safe_int(s.get("port"), 0)
            pwd = s.get("password") or ""
            if not (server and port and pwd): continue
            name = uniq_name(f"trojan-{server}-{tail(pwd)}")
            p = {"name": name, "type": "trojan", "server": server, "port": port, "password": pwd, "udp": True, "network": "tcp"}
            if tls_flag: p["tls"] = True; p["sni"] = server
            proxies.append(p)

        elif proto == "shadowsocks":
            try:
                s = (ob.get("settings") or {}).get("servers", [])[0]
            except:
                continue
            server = s.get("address") or ""
            port = safe_int(s.get("port"), 0)
            cipher = s.get("method") or s.get("cipher") or ""
            password = s.get("password") or ""
            if not (server and port and cipher and password): continue
            name = uniq_name(f"ss-{server}-{port}")
            p = {"name": name, "type": "ss", "server": server, "port": port, "cipher": cipher, "password": password, "udp": True}
            proxies.append(p)

# parse line links (vless:// vmess:// trojan:// ss://)
for line in [ln.strip() for ln in content.splitlines() if ln.strip() and not ln.strip().startswith("{")]:
    try:
        if line.startswith("vless://"):
            parsed = urlparse(line)
            uid = parsed.username or ""
            host = parsed.hostname or ""
            port = parsed.port or 443
            q = parse_qs(parsed.query)
            if not (uid and host and port): continue
            net = (q.get("type", ["tcp"])[0] or "tcp").lower()
            tls_flag = (q.get("security", [""])[0] or "").lower() in ("tls","reality")
            name = uniq_name(f"vless-{host}-{tail(uid)}")
            p = {"name": name, "type": "vless", "server": host, "port": port, "uuid": uid, "encryption":"none","udp":True,"network":net}
            if net == "ws":
                p["ws-opts"] = {"path": q.get("path", ["/"])[0]}
                hosth = q.get("host", []) or q.get("Host", [])
                if hosth: p["ws-opts"]["headers"] = {"Host": hosth[0]}
            elif net == "grpc":
                svc = q.get("serviceName", [""])[0]
                if svc: p["grpc-opts"] = {"grpc-service-name": svc}
            if tls_flag:
                sni = (q.get("sni", []) or q.get("servername", []) or [host])[0]
                p["tls"] = True; p["servername"] = sni
            proxies.append(p)

        elif line.startswith("vmess://"):
            payload = line[8:]
            try:
                txt = base64.b64decode(b64fix(payload)).decode(errors="ignore")
                info = json.loads(txt)
            except:
                continue
            host = info.get("add") or info.get("server") or ""
            port = safe_int(info.get("port"), 0)
            uid = info.get("id") or ""
            if not (host and port and uid): continue
            net = (info.get("net") or "tcp").lower()
            tls_flag = str(info.get("tls","")).lower() == "tls"
            name = uniq_name(f"vmess-{host}-{tail(uid)}")
            p = {"name": name, "type": "vmess", "server": host, "port": port, "uuid": uid,
                 "alterId": safe_int(info.get("aid", info.get("alterId", 0))),
                 "cipher": info.get("scy", "auto"), "udp": True, "network": net}
            if net == "ws":
                p["ws-opts"] = {"path": info.get("path") or "/"}
                hosth = info.get("host") or ""
                if hosth: p["ws-opts"]["headers"] = {"Host": hosth}
            if tls_flag:
                sni = info.get("sni") or info.get("host") or host
                p["tls"] = True; p["servername"] = sni
            proxies.append(p)

        elif line.startswith("trojan://"):
            parsed = urlparse(line)
            pwd = parsed.username or ""
            host = parsed.hostname or ""
            port = parsed.port or 443
            if not (pwd and host and port): continue
            q = parse_qs(parsed.query)
            sni = q.get("sni", [host])[0]
            name = uniq_name(f"trojan-{host}-{tail(pwd)}")
            p = {"name": name, "type": "trojan", "server": host, "port": port, "password": pwd, "udp": True, "network":"tcp", "tls": True, "sni": sni}
            proxies.append(p)

        elif line.startswith("ss://"):
            try:
                after = line[5:]
                if "@" in after and ":" in after.split("@",1)[0]:
                    cred, rest = after.split("@",1)
                    if ":" in cred: method, password = cred.split(":",1)
                    else: continue
                    host_port = rest.split("#",1)[0]
                    if ":" not in host_port: continue
                    host, port = host_port.rsplit(":",1)
                else:
                    if "@" not in after: continue
                    b64cred, rest = after.split("@",1)
                    method_password = base64.urlsafe_b64decode(b64fix(b64cred)).decode()
                    method, password = method_password.split(":",1)
                    host_port = rest.split("#",1)[0]
                    host, port = host_port.rsplit(":",1)
                method = method.strip(); password = password.strip(); host = host.strip(); port = safe_int(port.strip(), 0)
                if not (method and password and host and port): continue
                name = uniq_name(f"ss-{host}-{port}")
                p = {"name": name, "type": "ss", "server": host, "port": port, "cipher": method, "password": password, "udp": True}
                proxies.append(p)
            except:
                continue
    except:
        continue

# dedupe by (type,server,port) preserve order
seen = set()
unique_proxies = []
for p in proxies:
    key = (p.get("type"), p.get("server"), p.get("port"))
    if key in seen:
        continue
    seen.add(key)
    unique_proxies.append(p)
proxies = unique_proxies

# initial ping (median)
initial_results = []
if proxies:
    max_workers = max(1, min(MAX_WORKERS, len(proxies)))
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        fut_map = {ex.submit(tcp_ping_median, p.get("server"), p.get("port"), PING_ATTEMPTS, PING_TIMEOUT, 0.06): p for p in proxies}
        for fut in as_completed(fut_map):
            p = fut_map[fut]
            try:
                lat = fut.result()
            except:
                lat = None
            if lat is None:
                p["ping"] = None; p["status"] = "dead"
            else:
                try:
                    li = int(lat)
                except:
                    li = None
                if li is None or li < RED_MIN_MS or li > RED_MAX_MS:
                    p["ping"] = None; p["status"] = "dead"
                else:
                    p["ping"] = li; p["status"] = "ok"
            initial_results.append(p)

final_proxies = initial_results if initial_results else proxies

# filter only OK proxies (pass RED)
valid = [p for p in final_proxies if p.get("status")=="ok" and isinstance(p.get("ping"), int)]
# group stable-first: prioritize low variance/consistent ones
# For simplicity initial script uses ping only; variance could be added with rechecks
fast = [p for p in valid if p["ping"] <= FAST_MAX_MS]
stable = [p for p in valid if FAST_MAX_MS < p["ping"] <= STABLE_MAX_MS]
fallback = [p for p in valid if p not in fast and p not in stable]

safe_sort_key = lambda x: x.get("ping") if isinstance(x.get("ping"), int) else 999999
fast_sorted = sorted(fast, key=safe_sort_key)[:FAST_GROUP_LIMIT]
stable_sorted = sorted(stable, key=safe_sort_key)[:STABLE_GROUP_LIMIT]
fallback_sorted = sorted(fallback, key=safe_sort_key)

fast_names = [p["name"] for p in fast_sorted] or ([p["name"] for p in valid][:1] if valid else ["DIRECT"])
stable_names = [p["name"] for p in stable_sorted] or ([p["name"] for p in valid][:1] if valid else ["DIRECT"])
fallback_names = [p["name"] for p in fallback_sorted] or ([p["name"] for p in valid][:1] if valid else ["DIRECT"])

all_names = [p["name"] for p in final_proxies]

# final config (Persian group names with emojis)
config = {
    "proxies": final_proxies,
    "proxy-groups": [
        {"name": "🌟💢💦انتخاب دستی🌟💢💦", "type": "select", "proxies": ["⚡🔥💎اتومات⚡🔥💎", "💠🛡️🌈پایدارترین💠🛡️🌈", "🏎️💨💥پرسرعت ترین🏎️💨💥", "🔹💎🌈فالبک ایده ال🔹💎🌈", "DIRECT"] + all_names},
        {"name": "⚡🔥💎اتومات⚡🔥💎", "type": "url-test", "url": "https://www.gstatic.com/generate_204", "interval": max(60, RECHECK_INTERVAL_MIN * 60), "tolerance": 50, "proxies": all_names},
        {"name": "💠🛡️🌈پایدارترین💠🛡️🌈", "type": "select", "proxies": stable_names},
        {"name": "🏎️💨💥پرسرعت ترین🏎️💨💥", "type": "select", "proxies": fast_names},
        {"name": "🔹💎🌈فالبک ایده ال🔹💎🌈", "type": "fallback", "url": "https://www.gstatic.com/generate_204", "interval": max(60, RECHECK_INTERVAL_MIN * 60), "timeout": 3, "tolerance": 50, "proxies": fallback_names}
    ],
    "rules": ["MATCH,🌟💢💦انتخاب دستی🌟💢💦"]
}

with open(OUT_PATH, "w", encoding="utf-8") as f:
    yaml.safe_dump(config, f, allow_unicode=True, sort_keys=False)

# clear input
with open(INPUT_PATH, "w", encoding="utf-8") as f:
    f.write("")

print(f"[✅] Saved {len(final_proxies)} proxies to {OUT_PATH}")

# optional recheck loop: update fallback ordering using rolling averages
if RECHECK_INTERVAL_MIN and (fast_sorted or stable_sorted):
    ping_history = {p["name"]: [p.get("ping")] * 3 if isinstance(p.get("ping"), int) else [999999]*3 for p in (fast_sorted + stable_sorted)}
    def recheck_loop():
        interval = max(60, RECHECK_INTERVAL_MIN*60)
        while True:
            try:
                candidates = fast_sorted + stable_sorted
                if not candidates:
                    time.sleep(interval); continue
                with ThreadPoolExecutor(max_workers=max(1, min(MAX_WORKERS, len(candidates)))) as ex:
                    fut_map = {ex.submit(tcp_ping_median, p.get("server"), p.get("port"), max(1,min(PING_ATTEMPTS,7)), PING_TIMEOUT, 0.06): p for p in candidates}
                    for fut in as_completed(fut_map):
                        p = fut_map[fut]
                        try:
                            lat = fut.result()
                        except:
                            lat = None
                        name = p["name"]
                        ping_history.setdefault(name, []).append(int(lat) if isinstance(lat, (int,float)) else 999999)
                        if len(ping_history[name]) > 8:
                            ping_history[name] = ping_history[name][-8:]
                # compute avg and reorder
                ordered = sorted(candidates, key=lambda x: sum(ping_history.get(x["name"], [999999]))/len(ping_history.get(x["name"], [999999])))
                fb = [p["name"] for p in ordered] or (all_names[:1] if all_names else [])
                for g in config["proxy-groups"]:
                    if g["name"] == "فالبک ایده ال":
                        g["proxies"] = fb
                        g["interval"] = interval
                        break
                with open(OUT_PATH, "w", encoding="utf-8") as f:
                    yaml.safe_dump(config, f, allow_unicode=True, sort_keys=False)
            except Exception:
                pass
            time.sleep(interval)
    t = threading.Thread(target=recheck_loop, daemon=True)
    t.start()




