#!/data/data/com.termux/files/usr/bin/python3
# -*- coding: utf-8 -*-
"""
Ultra Mega Premium Live AutoSwitch – Multi-protocol Smart Proxy Manager
"""

import os, re, socket, time, base64, yaml, subprocess, threading
from urllib.parse import unquote
from concurrent.futures import ThreadPoolExecutor
from rich.console import Console
from rich.table import Table
from rich.text import Text

# ---------------- Paths ----------------
BASE_DIR = "/storage/emulated/0/Download/Akbar98"
os.makedirs(BASE_DIR, exist_ok=True)
INPUT_PATH = os.path.join(BASE_DIR, "input.txt")

with open(INPUT_PATH, "w", encoding="utf-8") as f:
    f.write("")
subprocess.call(["nano", INPUT_PATH])

out_folder = input("Enter output folder name in Download: ").strip()
if not out_folder:
    print("Folder name required."); exit(1)
OUT_DIR = os.path.join("/storage/emulated/0/Download", out_folder)
os.makedirs(OUT_DIR, exist_ok=True)

out_name = input("Enter output file name (without extension): ").strip()
if not out_name:
    print("File name required."); exit(1)
OUT_PATH = os.path.join(OUT_DIR, f"{out_name}.yaml")


console = Console()

# ---------------- Helpers ----------------
def b64fix(s): return s.replace("-", "+").replace("_", "/") + "=" * (-len(s) % 4)
def safe_int(x,d=0): 
    try: return int(x)
    except: return d
def sanitize(s): return re.sub(r'[\n\r]+','',str(s).strip())

_used_names=set()
def uniq_name(base):
    name=base; c=1
    while name in _used_names:
        name=f"{base}-{c}"; c+=1
    _used_names.add(name)
    return name

def split_host_port(hostport):
    if ":" in hostport: h,p=hostport.split(":",1); return h.strip(), safe_int(p)
    return hostport.strip(), None

# ---------------- TCP Ping ----------------
def tcp_ping_once(host,port,timeout=0.5):
    try:
        s=socket.socket(); s.settimeout(timeout)
        t0=time.time(); s.connect((host,port)); s.close()
        return int((time.time()-t0)*1000)
    except: return None

def tcp_ping_median(host,port,n=3):
    pings=[p for _ in range(n) if (p:=tcp_ping_once(host,port))]
    if not pings: return None
    pings.sort(); m=len(pings)//2
    return pings[m] if len(pings)%2 else (pings[m-1]+pings[m])//2

def attach_ping(proxy):
    proxy["ping"]=tcp_ping_median(proxy["server"],proxy["port"])
    proxy["status"]="✅" if proxy["ping"] is not None else "❌"
    return proxy

# ---------------- Parsers ----------------
def parse_vless(line):
    try:
        if not line.startswith("vless://"): return None
        raw=line[8:]; name=None
        if "#" in raw: raw,name=raw.split("#",1); name=unquote(name)
        creds,_,params=raw.partition("?"); uuid,_,hostport=creds.partition("@")
        host,port=split_host_port(hostport)
        param_dict=dict(p.split("=",1) for p in params.split("&") if "=" in p)
        proxy={"name":uniq_name(name or f"VLESS-{host}-{port}"),"type":"vless","server":host,
               "port":safe_int(port,443),"uuid":uuid,"tls":param_dict.get("security")=="tls",
               "network":param_dict.get("type","tcp"),"mptcp":True,"tfo":True}
        if proxy["network"]=="ws": proxy["ws-opts"]={"path":param_dict.get("path","/"),"headers":{"Host":param_dict.get("host",host)}}
        return proxy
    except: return None

def parse_vmess(line):
    try:
        if not line.startswith("vmess://"): return None
        raw=line[8:]
        js=None
        try: js=base64.b64decode(b64fix(raw)).decode()
        except: js=unquote(raw)
        import json; js=json.loads(js)
        host=js.get("add") or js.get("address"); port=js.get("port"); uuid=js.get("id") or js.get("uuid")
        proxy={"name":uniq_name(js.get("ps") or f"VMESS-{host}-{uuid[-6:]}"),"type":"vmess",
               "server":host,"port":safe_int(port),"uuid":uuid,"alterId":int(js.get("aid",0)),
               "cipher":js.get("scy","auto"),"network":js.get("net","tcp"),"tls":js.get("tls")=="tls"}
        return proxy
    except: return None

def parse_trojan(line):
    try:
        if not line.startswith("trojan://"): return None
        raw=line[9:]; name=None
        if "#" in raw: raw,name=raw.split("#",1); name=unquote(name)
        creds,_,params=raw.partition("?"); password,_,hostport=creds.partition("@")
        host,port=split_host_port(hostport)
        proxy={"name":uniq_name(name or f"Trojan-{host}-{port}"),"type":"trojan","server":host,
               "port":safe_int(port,443),"password":password,"tls":True,"network":params.get("type","tcp"),
               "mptcp":True,"tfo":True}
        return proxy
    except: return None

def parse_ss(line):
    try:
        if not line.startswith("ss://"): return None
        raw=line[5:]; decoded=base64.urlsafe_b64decode(b64fix(raw.split("#")[0])).decode()
        method_pass,_,hostport=decoded.partition("@"); cipher,password=method_pass.split(":",1)
        host,port=split_host_port(hostport)
        return {"name":uniq_name(f"SS-{host}-{port}"),"type":"ss","server":host,"port":safe_int(port),
                "cipher":cipher,"password":password,"udp":True}
    except: return None

def parse_ssr(line):
    try:
        if not line.startswith("ssr://"): return None
        raw=base64.urlsafe_b64decode(b64fix(line[6:])).decode()
        items=raw.split(":")
        if len(items)<6: return None
        host,port,protocol,method,obfs,pass_b64=items[:6]
        password=base64.urlsafe_b64decode(b64fix(pass_b64)).decode()
        return {"name":uniq_name(f"SSR-{host}-{port}"),"type":"ssr","server":host,"port":safe_int(port),
                "protocol":protocol,"cipher":method,"obfs":obfs,"password":password}
    except: return None

def parse_hysteria(line):
    try:
        if not line.lower().startswith("hysteria://"): return None
        raw=line[len("hysteria://"):]
        creds,_,params=raw.partition("?"); host,port=split_host_port(creds)
        param_dict=dict(p.split("=",1) for p in params.split("&") if "=" in p)
        return {"name":uniq_name(f"Hysteria-{host}-{port}"),"type":"hysteria","server":host,"port":safe_int(port),
                "protocol":param_dict.get("protocol","udp"),"auth":param_dict.get("auth",""),"obfs":param_dict.get("obfs","")}
    except: return None

def parse_tuic(line): return {"name":uniq_name("TUIC"),"type":"tuic"} if line.startswith("tuic://") else None
def parse_wireguard(line): return {"name":uniq_name("WireGuard"),"type":"wireguard"} if line.startswith("wg://") else None
def parse_http(line): return {"name":uniq_name("HTTP"),"type":"http","server":line} if line.startswith("http") else None
def parse_socks(line): return {"name":uniq_name("SOCKS"),"type":"socks","server":line} if line.startswith("socks") else None

def parse_line(line):
    line=sanitize(line)
    for p in (parse_vless,parse_vmess,parse_trojan,parse_ss,parse_ssr,parse_hysteria,parse_tuic,parse_wireguard,parse_http,parse_socks):
        if (res:=p(line)): return res
    return None

# ---------------- Groups ----------------
# ---------------- Groups ----------------
def generate_groups(proxies):
    alive = [p for p in proxies if p["status"] == "✅" and p.get("ping")]
    alive.sort(key=lambda x: x["ping"])

    top_fast = alive[:13]
    stable = [p for p in alive if p["ping"] < 550][:13]
    top3 = alive[:13]
    all_names = [p["name"] for p in alive]

    return [
        {
            "name": "🌐 All Proxies ",
            "type": "select",
            "proxies": all_names
        },
        {
            "name": "🌟 Stable Fallback",
            "type": "fallback",
            "proxies": [p["name"] for p in proxies if p["status"] == "✅"],
            "url": "http://www.google.com/generate_204",
            "interval": 2080
        },
        {
            "name": "⛔ Fallback Stable",
            "type": "fallback",
            "proxies": all_names,
            "url": "http://www.gstatic.com/ipranges/cloud.json",
            "interval": 888
        },
        {
            "name": "💚 Top Fast",
            "type": "url-test",
            "proxies": [p["name"] for p in top_fast],
            "url": "http://connectivitycheck.gstatic.com/generate_204",
            "interval": 46771,
            "tolerance": 508
        },
        {
            "name": "💛 Top Stable <550ms",
            "type": "url-test",
            "proxies": [p["name"] for p in stable],
            "url": "https://www.google.com/gen_204",
            "interval": 45678,
            "tolerance": 3800
        },
        {
            "name": "⚡ Top 3 AutoSwitch",
            "type": "url-test",
            "proxies": [p["name"] for p in top3],
            "url": "https://www.google.com/gen_204",
            "interval": 2500,
            "tolerance": 5000
        },
        {
            "name": "⚡ STABLE",
            "type": "fallback",
            "url": "http://connectivitycheck.gstatic.com/generate_204",
            "tolerance": 200,
            "interval": 2000,
            "proxies": [p["name"] for p in proxies if p["status"] == "✅"]
        },
        {
            "name": "🏆 BestPing",
            "type": "url-test",
            "url": "http://www.gstatic.com/ipranges/cloud.json",
            "tolerance": 300,
            "interval": 1500,
            "proxies": [p["name"] for p in proxies if p["status"] == "✅"]
        }
    ]


# ---------------- Display ----------------
def display_table(proxies):
    table = Table(title="Ultra Mega Premium AutoSwitch", show_lines=True)
    table.add_column("Name")
    table.add_column("Type")
    table.add_column("Server")
    table.add_column("Port")
    table.add_column("Ping (ms)")
    table.add_column("Status")

    best_ping = min((p["ping"] for p in proxies if p.get("ping")), default=None)

    for p in proxies:
        style = "bold yellow" if p.get("ping") == best_ping else ""
        status_style = "green" if p["status"] == "✅" else "red"

        table.add_row(
            Text(p["name"], style=style),
            p["type"],
            p["server"],
            str(p["port"]),
            str(p.get("ping", "N/A")),
            Text(p["status"], style=status_style)
        )

    console.clear()
    console.print(table)


def update_loop(raw_proxies):
    while True:
        with ThreadPoolExecutor(max_workers=30) as exe:
            final = list(exe.map(attach_ping, raw_proxies))

        display_table(final)

        data = {
            "proxies": final,
            "proxy-groups": generate_groups(final)
        }

        with open(OUT_PATH, "w", encoding="utf-8") as f:
            yaml.dump(data, f, allow_unicode=True)

        time.sleep(1)


# ---------------- Main ----------------
if __name__ == "__main__":
    lines = open(INPUT_PATH, "r", encoding="utf-8").read().splitlines()
    raw_proxies = [p for ln in lines if (p := parse_line(ln))]

    threading.Thread(
        target=update_loop,
        args=(raw_proxies,),
        daemon=True
    ).start()

    print(f"\n✅ Ultra Mega Premium AutoSwitch running. Output: {OUT_PATH}")
    print("Press Ctrl-C to stop live auto-switching.")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopped by user.")
