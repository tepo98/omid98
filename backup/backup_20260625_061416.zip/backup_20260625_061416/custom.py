#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import base64
from urllib.parse import urlparse, parse_qs, unquote

# ================= COLORS =================
G = "\033[92m"
B = "\033[94m"
Y = "\033[93m"
C = "\033[96m"
W = "\033[0m"

print(C + "========================" + W)
print(G + "   CUSTOM BUILDER MENU  " + W)
print(C + "========================\n" + W)

print(Y + "1) Paste Links" + W)
print(Y + "2) Nano Input" + W)
print(Y + "0) Exit\n" + W)

mode = input(B + "Select > " + W).strip()

print("\n")  # مهم برای ترموکس (flush UI)

links = []

# ================= INPUT FIX =================
if mode == "1":
    print("Paste links (END to finish):")

    while True:
        try:
            x = input().strip()
        except:
            break

        if x == "END":
            break

        if x:
            links.append(x)

elif mode == "2":
    import os, time, uuid

    tmp = f"/data/data/com.termux/files/home/tmp_{uuid.uuid4().hex}.txt"

    print("Opening nano...")

    with open(tmp, "w") as f:
        f.write("")

    os.system(f"nano {tmp}")

    time.sleep(0.2)

    if os.path.exists(tmp):
        with open(tmp, "r") as f:
            links = [i.strip() for i in f.readlines() if i.strip()]

    try:
        os.remove(tmp)
    except:
        pass

elif mode == "0":
    exit()

else:
    print("INVALID OPTION")
    exit()

# ================= DEBUG CHECK =================
if not links:
    print("NO INPUT RECEIVED ❌")
    exit()

# ================= SHOW =================
print(G + f"\nLOADED LINKS: {len(links)}" + W)

for i, l in enumerate(links, 1):
    print(f"{i}) {l}")

print(G + "\nOK INPUT WORKING ✔" + W)
