#!/bin/bash
# ------------------- COLORS & STYLE -------------------
CYAN="\e[96m"
BOLD="\e[1m"
RESET="\e[0m"

# ------------------- PATHS -------------------
BASE_PATH="$HOME"
DOWNLOAD_DIR="/sdcard/Download/Akbar98"
EXPORT_DIR="/sdcard/Download"

# ------------------- GLOBAL VARIABLES -------------------
CURRENT_REPO=""
REPO_PATH=""
GIT_USER=""
TOKEN=""

# ------------------- TOKENS (placeholders) -------------------
# جای توکن‌ها را خودت بعداً با توکن‌های واقعی پر کن.
TEPO18_TOKEN="#TEPO18_TOKEN#"
ALMASI98_TOKEN="#ALMASI98_TOKEN#"
TEPO98_TOKEN="#TEPO98_TOKEN#"
TEPO80_TOKEN="#TEPO80_TOKEN#"
ALMASI62_TOKEN="#ALMASI62_TOKEN#"

# ------------------- FUNCTIONS -------------------
choose_account() {
    echo -e "${BOLD}${CYAN}Select GitHub account:${RESET}"
    echo "1) tepo18"
    echo "2) almasi98"
    echo "3) tepo98"
    echo "4) tepo80"
    echo "5) almasi62"
    read -rp "Enter number: " ACC_CHOICE
    case $ACC_CHOICE in
        1) GIT_USER="tepo18"; TOKEN="$TEPO18_TOKEN" ;;
        2) GIT_USER="almasi98"; TOKEN="$ALMASI98_TOKEN" ;;
        3) GIT_USER="tepo98"; TOKEN="$TEPO98_TOKEN" ;;
        4) GIT_USER="tepo80"; TOKEN="$TEPO80_TOKEN" ;;
        5) GIT_USER="almasi62"; TOKEN="$ALMASI62_TOKEN" ;;
        *) echo -e "${CYAN}Invalid choice, defaulting to tepo18${RESET}"; GIT_USER="tepo18"; TOKEN="$TEPO18_TOKEN" ;;
    esac
    echo -e "${CYAN}GitHub account set to: $GIT_USER${RESET}"
}

# تابع کمکی برای تولید نام یکتا هنگام کپی
generate_unique_filename() {
    local dest_dir="$1"
    local filename="$2"
    local base name ext
    base="$(basename "$filename")"
    name="${base%.*}"
    ext="${base##*.}"
    if [ "$name" = "$ext" ]; then
        # no extension
        ext=""
    else
        ext=".$ext"
    fi
    local n=0
    local candidate
    while true; do
        if [ $n -eq 0 ]; then
            candidate="$dest_dir/$base"
        else
            candidate="$dest_dir/${name}_$n$ext"
        fi
        if [ ! -e "$candidate" ]; then
            echo "$candidate"
            return
        fi
        n=$((n+1))
    done
}

switch_repo() {
    echo -ne "${BOLD}${CYAN}Enter repo name to switch/use: ${RESET}"
    read -r REPO_NAME
    CURRENT_REPO="$REPO_NAME"
    REPO_PATH="$BASE_PATH/$CURRENT_REPO"
    if [ ! -d "$REPO_PATH" ]; then
        echo -e "${CYAN}Cloning repo...${RESET}"
        # اگر توکن تنظیم شده باشد از آن استفاده کن، در غیر این صورت کلون بدون توکن
        if [ -n "$TOKEN" ]; then
            git clone "https://$GIT_USER:$TOKEN@github.com/$GIT_USER/$CURRENT_REPO.git" "$REPO_PATH" || { echo "Clone failed!"; return; }
        else
            git clone "https://github.com/$GIT_USER/$CURRENT_REPO.git" "$REPO_PATH" || { echo "Clone failed!"; return; }
        fi
    else
        echo -e "${CYAN}Using existing repo.${RESET}"
    fi
    cd "$REPO_PATH" || { echo "Cannot enter repo folder."; return; }
    echo -e "${CYAN}Repo switched to: $CURRENT_REPO${RESET}"
}

# auto-recognize sab-vip10 for tepo18 if not set (non-intrusive)
if [ -z "$CURRENT_REPO" ] && [ "${GIT_USER:-}" = "tepo18" ]; then
    CURRENT_REPO="sab-vip10"
    REPO_PATH="$BASE_PATH/$CURRENT_REPO"
fi

reset_update_local_repo() {
    if [ -z "$REPO_PATH" ]; then
        echo -e "${CYAN}No repo selected. Please switch repo first.${RESET}"
        return
    fi
    read -rp "Are you sure you want to reset the local repo? This will discard all local changes! (yes/no): " CONFIRM
    if [ "$CONFIRM" != "yes" ]; then
        echo -e "${CYAN}Reset cancelled.${RESET}"
        return
    fi
    echo -e "${CYAN}Resetting and updating local repo...${RESET}"
    git reset --hard
    git pull origin main
    echo -e "${CYAN}Local repo reset and updated successfully!${RESET}"
}

# --- ادامه کد اصلی بدون هیچ تغییری ---
main_menu() {
    while true; do
        echo -e "\n${BOLD}${CYAN}===== LOCAL / DEVICE =====${RESET}"
        echo "1) Select account"
        echo "2) Switch repo"
        echo "3) Reset repo"
        echo "---------------------------"
        echo -e "${BOLD}${CYAN}===== MAIN MENU =====${RESET}"
        echo "4) Create file"
        echo "5) Edit file"
        echo "6) Delete file(s)"
        echo "7) Clear file(s)"
        echo "8) Commit"
        echo "9) Push Git"
        echo "10) Copy from Download"
        echo "11) Copy content to clipboard"
        echo "12) Custom copy files"
        echo "13) Copy all repo files to Download"
        echo "14) Copy password/token"
        echo "15) Exit"

        echo -ne "${BOLD}${CYAN}Choice: ${RESET}"
        read -r CHOICE

        case $CHOICE in
            1) choose_account ;;
            2) switch_repo ;;
            3) reset_update_local_repo ;;
            4)
                read -rp "Enter new filename: " NEWFILE
                [ -e "$NEWFILE" ] && echo -e "${CYAN}File exists${RESET}" || (touch "$NEWFILE" && echo -e "${CYAN}File created${RESET}")
                ;;
            5)
                read -rp "Enter filename to edit: " EDITFILE
                [ ! -e "$EDITFILE" ] && echo -e "${CYAN}File not found${RESET}" || nano "$EDITFILE"
                ;;
            6)
                read -rp "Enter filenames (space-separated): " DELFILES
                for f in $DELFILES; do
                    [ -e "$f" ] && rm -i "$f" && echo -e "${CYAN}$f deleted${RESET}" || echo -e "${CYAN}$f not found${RESET}"
                done
                ;;
            7)
                read -rp "Enter filenames to clear: " CLEARFILES
                for f in $CLEARFILES; do
                    [ -e "$f" ] && >"$f" && echo -e "${CYAN}$f cleared${RESET}" || echo -e "${CYAN}$f not found${RESET}"
                done
                ;;
            8)
                git status
                read -rp "Commit message (default: auto update): " MSG
                [ -z "$MSG" ] && MSG="auto update from script"
                git add .
                git commit -m "$MSG" 2>/dev/null || echo -e "${CYAN}Nothing to commit${RESET}"
                ;;
            9)
                read -rp "Push changes? (yes/no): " PUSH_ANSWER
                if [ "$PUSH_ANSWER" == "yes" ]; then
                    git add .
                    read -rp "Commit message (default: auto update): " MSG
                    [ -z "$MSG" ] && MSG="auto update from script"
                    git commit -m "$MSG" --allow-empty
                    if [ "$GIT_USER" = "tepo80" ] || [ "$GIT_USER" = "almasi62" ]; then
                        # اگر توکن اختصاصی tepo80 یا almasi62 تنظیم شده باشد، از آن استفاده کن
                        if [ -n "$TEPO80_TOKEN" ] && [ "$GIT_USER" = "tepo80" ]; then
                            git push "https://$GIT_USER:$TEPO80_TOKEN@github.com/$GIT_USER/$CURRENT_REPO.git" && echo -e "${CYAN}Pushed successfully${RESET}" || echo -e "${CYAN}Push failed${RESET}"
                        elif [ -n "$ALMASI62_TOKEN" ] && [ "$GIT_USER" = "almasi62" ]; then
                            git push "https://$GIT_USER:$ALMASI62_TOKEN@github.com/$GIT_USER/$CURRENT_REPO.git" && echo -e "${CYAN}Pushed successfully${RESET}" || echo -e "${CYAN}Push failed${RESET}"
                        else
                            git push "https://github.com/$GIT_USER/$CURRENT_REPO.git" && echo -e "${CYAN}Pushed successfully (interactive auth)${RESET}" || echo -e "${CYAN}Push failed${RESET}"
                        fi
                    else
                        # برای بقیه اکانت‌ها (مثلاً tepo18, almasi98, tepo98) از توکن مربوطه استفاده کن اگر تنظیم شده
                        if [ "$GIT_USER" = "tepo18" ] && [ -n "$TEPO18_TOKEN" ]; then
                            git push "https://$GIT_USER:$TEPO18_TOKEN@github.com/$GIT_USER/$CURRENT_REPO.git" && echo -e "${CYAN}Pushed successfully${RESET}" || echo -e "${CYAN}Push failed${RESET}"
                        elif [ "$GIT_USER" = "almasi98" ] && [ -n "$ALMASI98_TOKEN" ]; then
                            git push "https://$GIT_USER:$ALMASI98_TOKEN@github.com/$GIT_USER/$CURRENT_REPO.git" && echo -e "${CYAN}Pushed successfully${RESET}" || echo -e "${CYAN}Push failed${RESET}"
                        elif [ "$GIT_USER" = "tepo98" ] && [ -n "$TEPO98_TOKEN" ]; then
                            git push "https://$GIT_USER:$TEPO98_TOKEN@github.com/$GIT_USER/$CURRENT_REPO.git" && echo -e "${CYAN}Pushed successfully${RESET}" || echo -e "${CYAN}Push failed${RESET}"
                        else
                            git push "https://github.com/$GIT_USER/$CURRENT_REPO.git" && echo -e "${CYAN}Pushed successfully (interactive auth)${RESET}" || echo -e "${CYAN}Push failed${RESET}"
                        fi
                    fi
                fi
                ;;
            10)
                read -rp "Source file in Download: " SRC
                read -rp "Target filename in repo: " TARGET
                if [ -f "$DOWNLOAD_DIR/$SRC" ]; then
                    cat "$DOWNLOAD_DIR/$SRC" > "$TARGET" && echo -e "${CYAN}Copied content${RESET}"
                else
                    echo -e "${CYAN}Source file not found${RESET}"
                fi
                ;;
            11)
                if [ -z "$REPO_PATH" ]; then
                    echo -e "${CYAN}No repo selected. Switch first.${RESET}"
                else
                    cd "$REPO_PATH" || { echo -e "${CYAN}Cannot access repo path${RESET}"; continue; }
                    read -rp "Enter filename: " COPYFILE
                    if [ -f "$COPYFILE" ]; then
                        termux-clipboard-set < "$COPYFILE"
                        echo -e "${CYAN}Content copied to clipboard${RESET}"
                    else
                        echo -e "${CYAN}File not found${RESET}"
                    fi
                fi
                ;;
            12)
                if [ -z "$REPO_PATH" ]; then
                    echo -e "${CYAN}No repo selected. Switch first.${RESET}"
                else
                    cd "$REPO_PATH" || { echo -e "${CYAN}Cannot access repo path${RESET}"; continue; }
                    mkdir -p "$EXPORT_DIR/ahoora98"
                    read -rp "Enter filenames (space-separated): " FILES
                    for f in $FILES; do
                        if [ -f "$f" ]; then
                            DEST_FILE=$(generate_unique_filename "$EXPORT_DIR/ahoora98" "$f")
                            cp "$f" "$DEST_FILE"
                            echo -e "${CYAN}Copied $f to $DEST_FILE${RESET}"
                        else
                            echo -e "${CYAN}$f not found${RESET}"
                        fi
                    done
                fi
                ;;
            13)
                if [ -z "$REPO_PATH" ]; then
                    echo -e "${CYAN}No repo selected. Switch first.${RESET}"
                else
                    cd "$REPO_PATH" || { echo -e "${CYAN}Cannot access repo path${RESET}"; continue; }
                    echo -e "${BOLD}${CYAN}Select option:${RESET}"
                    echo "1) Copy all repo files"
                    echo "2) Copy custom files"
                    echo -ne "${BOLD}${CYAN}Choice: ${RESET}"
                    read -r SUBCHOICE
                    case $SUBCHOICE in
                        1)
                            read -rp "Enter output filename (without extension): " OUTFILE
                            UNIQUE_OUTPATH=$(generate_unique_filename "$EXPORT_DIR" "$OUTFILE.txt")
                            > "$UNIQUE_OUTPATH"
                            for f in *; do
                                [ -f "$f" ] && echo -e "\n===== $f =====\n" >> "$UNIQUE_OUTPATH" && cat "$f" >> "$UNIQUE_OUTPATH"
                            done
                            echo -e "${CYAN}All repo files merged into $UNIQUE_OUTPATH${RESET}"
                            ;;
                        2)
                            mkdir -p "$EXPORT_DIR/ahoora98"
                            read -rp "Enter filenames (space-separated): " FILES
                            for f in $FILES; do
                                if [ -f "$f" ]; then
                                    DEST_FILE=$(generate_unique_filename "$EXPORT_DIR/ahoora98" "$f")
                                    cp "$f" "$DEST_FILE"
                                    echo -e "${CYAN}Copied $f to $DEST_FILE${RESET}"
                                else
                                    echo -e "${CYAN}$f not found${RESET}"
                                fi
                            done
                            ;;
                        *) echo -e "${CYAN}Invalid choice${RESET}" ;;
                    esac
                fi
                ;;
            14)
                # نمایش امن وضعیت توکن — هرگز توکن کامل را چاپ نکن
                echo -e "${CYAN}Stored token status for account $GIT_USER:${RESET}"
                case "$GIT_USER" in
                    tepo18)
                        [ -n "$TEPO18_TOKEN" ] && echo -e "${CYAN}Tepo18 token is set (placeholder).${RESET}" || echo -e "${CYAN}Tepo18 token not set.${RESET}"
                        ;;
                    almasi98)
                        [ -n "$ALMASI98_TOKEN" ] && echo -e "${CYAN}Almasi98 token is set (placeholder).${RESET}" || echo -e "${CYAN}Almasi98 token not set.${RESET}"
                        ;;
                    tepo98)
                        [ -n "$TEPO98_TOKEN" ] && echo -e "${CYAN}Tepo98 token is set (placeholder).${RESET}" || echo -e "${CYAN}Tepo98 token not set.${RESET}"
                        ;;
                    tepo80)
                        [ -n "$TEPO80_TOKEN" ] && echo -e "${CYAN}Tepo80 token is set (placeholder).${RESET}" || echo -e "${CYAN}Tepo80 token not set.${RESET}"
                        ;;
                    almasi62)
                        [ -n "$ALMASI62_TOKEN" ] && echo -e "${CYAN}Almasi62 token is set (placeholder).${RESET}" || echo -e "${CYAN}Almasi62 token not set.${RESET}"
                        ;;
                    *)
                        echo -e "${CYAN}No account selected or token unknown.${RESET}"
                        ;;
                esac
                ;;
            15)
                echo -e "${CYAN}Exiting... Goodbye!${RESET}"
                exit 0
                ;;
            *) echo -e "${CYAN}Invalid choice${RESET}" ;;
        esac
    done
}

main_menu

