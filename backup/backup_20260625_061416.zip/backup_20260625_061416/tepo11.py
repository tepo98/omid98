#!/data/data/com.termux/files/usr/bin/python3
# -*- coding: utf-8 -*-
"""
Ultra Live AutoSwitch Parser – Clash Meta Generator
با سوئیچینگ زنده و خودکار
"""
# ====================== IMPORTS ======================
import threading
import os
import sys
import re
import socket
import time
import json
import base64
import yaml
import subprocess
from concurrent.futures import ThreadPoolExecutor


from urllib.parse import (
    urlparse,
    parse_qs,
    unquote
)

from concurrent.futures import (
    ThreadPoolExecutor,
    as_completed
)


#=====================================
# PATHS
#=====================================

BASE_DIR = "/storage/emulated/0/Download/Akbar98"
os.makedirs(BASE_DIR, exist_ok=True)
INPUT_PATH = os.path.join(BASE_DIR, "input.txt")

with open(INPUT_PATH, "w", encoding="utf-8") as f:
    f.write("")
subprocess.call(["nano", INPUT_PATH])

out_folder = input("Enter output folder name in Download: ").strip()
if not out_folder:
    print("Folder name required."); exit(1)
OUT_DIR = os.path.join("/storage/emulated/0/Download", out_folder)
os.makedirs(OUT_DIR, exist_ok=True)

out_name = input("Enter output file name (without extension): ").strip()
if not out_name:
    print("File name required."); exit(1)
OUT_PATH = os.path.join(OUT_DIR, f"{out_name}.yaml")


# ---------------- Helpers ----------------

def b64fix(s):
    if not s:
        return ""
    s = str(s).strip().replace("\n", "").replace(" ", "")
    s = s.replace("-", "+").replace("_", "/")
    pad = len(s) % 4
    if pad:
        s += "=" * (4 - pad)
    return s

def is_probably_base64(s):
    if not isinstance(s, str): return False
    s = s.strip()
    if len(s) < 8: return False
    try:
        base64.b64decode(b64fix(s))
        return True
    except Exception:
        return False

def safe_int(v, default=0):
    try:
        return int(v)
    except Exception:
        try:
            return int(float(v))
        except Exception:
            return default

def sanitize(s):
    if not s: return ""
    return re.sub(r"[^A-Za-z0-9_\- .]", "", str(s)).strip()

_used_names = set()
def uniq_name(base):
    base = sanitize(str(base)) or "Proxy"
    name = base
    i = 2
    while name in _used_names:
        name = f"{base} {i}"
        i += 1
    _used_names.add(name)
    return name

def tail(s, n=6):
    if not s: return ""
    s2 = re.sub(r"[-]", "", str(s))
    return s2[-n:] if len(s2) >= n else s2
    
    def b64fix(s): return s.replace("-", "+").replace("_", "/") + "=" * (-len(s) % 4)
def safe_int(x,d=0): 
    try: return int(x)
    except: return d
def sanitize(s): return re.sub(r'[\n\r]+','',str(s).strip())

_used_names=set()
def uniq_name(base):
    name=base; c=1
    while name in _used_names:
        name=f"{base}-{c}"; c+=1
    _used_names.add(name)
    return name

def split_host_port(hostport):
    if ":" in hostport: h,p=hostport.split(":",1); return h.strip(), safe_int(p)
    return hostport.strip(), None
    
def attach_ping(p):
    p['ping'] = 100  # Simulate ping value
    p['status'] = 'ok' if p['ping'] < 200 else 'not_ok'
    return p

# ----------------- Parsing Input -----------------
def parse_input_file(path):
    proxies = []
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    for line in lines:
        line = line.strip()
        if not line:
            continue
        # تشخیص نوع پروتکل
        if line.startswith("vmess://"):
            proxies.append(vmess.parse(line))
        elif line.startswith("vless://"):
            proxies.append(vless.parse(line))
        elif line.startswith("ss://"):
            proxies.append(ss.parse(line))
        elif line.startswith("trojan://"):
            proxies.append(trojan.parse(line))
        elif line.startswith("hysteria://"):
            proxies.append(hysteria.parse(line))
        elif line.startswith("tuic://"):
            proxies.append(tuic.parse(line))
        elif line.startswith("wireguard://"):
            proxies.append(wireguard.parse(line))
        else:
            # universal parser
            proxies.append(universal.parse(line))
    return proxies

# ---------------- TCP Ping ----------------
def tcp_ping_once(host,port,timeout=1.0):
    try:
        s=socket.socket(); s.settimeout(timeout)
        t0=time.time(); s.connect((host,port)); s.close()
        return int((time.time()-t0)*1000)
    except: return None

def tcp_ping_median(host,port,n=3):
    results=[p for _ in range(n) if (p:=tcp_ping_once(host,port))]
    if not results: return None
    results.sort(); m=len(results)//2
    return results[m] if len(results)%2 else (results[m-1]+results[m])//2

def attach_ping(proxy):
    proxy["ping"]=tcp_ping_median(proxy["server"],proxy["port"])
    proxy["status"]="ok" if proxy["ping"] is not None else "fail"
    return proxy


def parse_vless(line):
    try:
        if not line.startswith("vless://"): return None
        raw=line[8:]; name=None
        if "#" in raw: raw,name=raw.split("#",1); name=unquote(name)
        creds,_,params=raw.partition("?"); uuid,_,hostport=creds.partition("@")
        host,port=split_host_port(hostport)
        param_dict=dict(p.split("=",1) for p in params.split("&") if "=" in p)
        proxy={"name":uniq_name(name or f"VLESS-{host}-{port}"),"type":"vless","server":host,"port":safe_int(port,443),
               "uuid":uuid,"tls":param_dict.get("security")=="tls","network":param_dict.get("type","tcp"),"mptcp":True,"tfo":True}
        if proxy["network"]=="ws": proxy["ws-opts"]={"path":param_dict.get("path","/"),"headers":{"Host":param_dict.get("host",host)}}
        return proxy
    except: return None

def parse_trojan(line):
    try:
        if not line.startswith("trojan://"): return None
        raw=line[9:]; name=None
        if "#" in raw: raw,name=raw.split("#",1); name=unquote(name)
        creds,_,params=raw.partition("?"); password,_,hostport=creds.partition("@")
        host,port=split_host_port(hostport)
        param_dict=dict(p.split("=",1) for p in params.split("&") if "=" in p)
        proxy={"name":uniq_name(name or f"Trojan-{host}-{port}"),"type":"trojan","server":host,"port":safe_int(port,443),
               "password":password,"tls":True,"network":param_dict.get("type","tcp"),"mptcp":True,"tfo":True}
        if proxy["network"]=="ws": proxy["ws-opts"]={"path":param_dict.get("path","/"),"headers":{"Host":param_dict.get("host",host)}}
        return proxy
    except: return None

def parse_ss(line):
    try:
        if not line.startswith("ss://"): return None
        raw=line[5:]; decoded=base64.urlsafe_b64decode(b64fix(raw.split("#")[0])).decode()
        method_pass,_,hostport=decoded.partition("@"); cipher,password=method_pass.split(":",1)
        host,port=split_host_port(hostport)
        return {"name":uniq_name(f"SS-{host}-{port}"),"type":"ss","server":host,"port":safe_int(port),"cipher":cipher,"password":password,"udp":True}
    except: return None

def parse_ssr(line):
    try:
        if not line.startswith("ssr://"): return None
        raw=base64.urlsafe_b64decode(b64fix(line[6:])).decode()
        items=raw.split(":"); 
        if len(items)<6: return None
        host,port,protocol,method,obfs,pass_b64=items[:6]
        password=base64.urlsafe_b64decode(b64fix(pass_b64)).decode()
        return {"name":uniq_name(f"SSR-{host}-{port}"),"type":"ssr","server":host,"port":safe_int(port),
                "protocol":protocol,"cipher":method,"obfs":obfs,"password":password}
    except: return None

def parse_line(line):
    line=sanitize(line)
    for p in (parse_vless,parse_trojan,parse_ss,parse_ssr):
        if (res:=p(line)): return res
    return None
    
# ---------------- JSON extraction ----------------
def extract_json_objects(text):
    objs, stack, start = [], [], None
    for i, c in enumerate(text):
        if c == '{':
            if not stack: start = i
            stack.append(c)
        elif c == '}':
            if stack:
                stack.pop()
                if not stack and start is not None:
                    objs.append(text[start:i+1])
                    start = None
    return objs

# ---------------- read input ----------------
try:
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        content = f.read()
except Exception:
    content = ""

proxies = []

# ---------------- parse JSON fragments ----------------
for frag in extract_json_objects(content):
    try:
        obj = json.loads(frag)
    except Exception:
        continue
    outbounds = obj.get("outbounds", []) or []
    for ob in outbounds:
        proto = (ob.get("protocol") or "").lower()
        if proto not in ("vless","vmess","trojan","shadowsocks"):
            continue
        stream = ob.get("streamSettings") or {}
        net = (stream.get("network") or "tcp").lower()
        security = (stream.get("security") or "").lower()
        tls_flag = security in ("tls","reality")

        if proto in ("vless","vmess"):
            try:
                vnext = (ob.get("settings") or {}).get("vnext", [])[0]
                user = (vnext.get("users") or [])[0]
            except Exception:
                continue
            server = vnext.get("address") or ""
            port = safe_int(vnext.get("port"), 0)
            uid = user.get("id") or ""
            if not (server and port and uid):
                continue
            base = f"{proto}-{server}-{tail(uid)}"
            name = uniq_name(base)
            p = {"name": name, "type": proto, "server": server, "port": port, "udp": True, "network": net}
            if proto == "vless":
                p["uuid"] = uid; p["encryption"] = "none"
            else:
                p["uuid"] = uid; p["alterId"] = safe_int(user.get("alterId", user.get("aid",0)))
                p["cipher"] = user.get("cipher", "auto") or ob.get("settings", {}).get("clients", [{}])[0].get("cipher","auto")
            if tls_flag:
                sni = (stream.get("tlsSettings") or {}).get("serverName") or (stream.get("realitySettings") or {}).get("serverName") or server
                p["tls"] = True; p["servername"] = sni
            if net == "ws":
                ws = stream.get("wsSettings") or {}
                path = ws.get("path") or "/"
                headers = ws.get("headers") or {}
                p["ws-opts"] = {"path": path}
                if headers: p["ws-opts"]["headers"] = headers
            if net == "grpc":
                grpc = stream.get("grpcSettings") or {}
                svc = grpc.get("serviceName") or ""
                p["grpc-opts"] = {"grpc-service-name": svc}
            proxies.append(p)

        elif proto == "trojan":
            try:
                s = (ob.get("settings") or {}).get("servers", [])[0]
            except Exception:
                continue
            server = s.get("address") or ""
            port = safe_int(s.get("port"), 0)
            pwd = s.get("password") or ""
            if not (server and port and pwd):
                continue
            name = uniq_name(f"trojan-{server}-{tail(pwd)}")
            p = {"name": name, "type": "trojan", "server": server, "port": port, "password": pwd, "udp": True, "network": "tcp"}
            if tls_flag:
                p["tls"] = True; p["sni"] = server
            proxies.append(p)

        elif proto == "shadowsocks":
            try:
                s = (ob.get("settings") or {}).get("servers", [])[0]
            except Exception:
                continue
            server = s.get("address") or ""
            port = safe_int(s.get("port"), 0)
            cipher = s.get("method") or s.get("cipher") or ""
            password = s.get("password") or ""
            if not (server and port and cipher and password):
                continue
            name = uniq_name(f"ss-{server}-{port}")
            p = {"name": name, "type": "ss", "server": server, "port": port, "cipher": cipher, "password": password, "udp": True}
            proxies.append(p)


# ---------------- parse line links ----------------
for line in [ln.strip() for ln in content.splitlines() if ln.strip() and not ln.strip().startswith("{")]:
    try:
        if line.startswith("vless://"):
            parsed = urlparse(line)
            uid = parsed.username or ""
            host = parsed.hostname or ""
            port = parsed.port or 443
            q = parse_qs(parsed.query)
            if not (uid and host and port):
                continue
            net = (q.get("type", ["tcp"])[0] or "tcp").lower()
            tls_flag = (q.get("security", [""])[0] or "").lower() in ("tls","reality")
            name = uniq_name(f"vless-{host}-{tail(uid)}")
            p = {"name": name, "type": "vless", "server": host, "port": port, "uuid": uid, "encryption":"none","udp":True,"network":net}
            if net == "ws":
                p["ws-opts"] = {"path": q.get("path", ["/"])[0]}
                hosth = q.get("host", []) or q.get("Host", [])
                if hosth: p["ws-opts"]["headers"] = {"Host":hosth[0]}
            elif net == "grpc":
                svc = q.get("serviceName", [""])[0]
                if svc: p["grpc-opts"] = {"grpc-service-name": svc}
            if tls_flag:
                sni = q.get("sni", []) or q.get("servername", []) or [host]
                p["tls"] = True; p["servername"] = sni[0]
            proxies.append(p)

        elif line.startswith("vmess://"):
            payload = line[8:]
            try:
                decoded = base64.b64decode(b64fix(payload)).decode(errors="ignore")
                info = json.loads(decoded)
            except Exception:
                continue
            host = info.get("add") or info.get("server") or ""
            port = safe_int(info.get("port"), 0)
            uid = info.get("id") or ""
            if not (host and port and uid):
                continue
            net = (info.get("net") or "tcp").lower()
            tls_flag = str(info.get("tls","")).lower() == "tls"
            name = uniq_name(f"vmess-{host}-{tail(uid)}")
            p = {"name": name, "type": "vmess", "server": host, "port": port, "uuid": uid, "alterId": safe_int(info.get("aid", info.get("alterId",0))), "cipher": info.get("scy","auto"), "udp": True, "network": net}
            if net == "ws":
                path = info.get("path") or "/"
                hosth = info.get("host") or ""
                p["ws-opts"] = {"path": path}
                if hosth: p["ws-opts"]["headers"] = {"Host": hosth}
            if tls_flag:
                sni = info.get("sni") or info.get("host") or host
                p["tls"] = True; p["servername"] = sni
            proxies.append(p)

        elif line.startswith("trojan://"):
            parsed = urlparse(line)
            pwd = parsed.username or ""
            host = parsed.hostname or ""
            port = parsed.port or 443
            if not (pwd and host and port):
                continue
            q = parse_qs(parsed.query)
            sni = q.get("sni", [host])[0]
            name = uniq_name(f"trojan-{host}-{tail(pwd)}")
            p = {"name": name, "type": "trojan", "server": host, "port": port, "password": pwd, "udp": True, "network":"tcp", "tls": True, "sni": sni}
            proxies.append(p)

        elif line.startswith("ss://"):
            try:
                after = line[5:]
                if "@" in after and ":" in after.split("@",1)[0]:
                    cred, rest = after.split("@",1)
                    if ":" in cred:
                        method, password = cred.split(":",1)
                    else:
                        continue
                    host_port = rest.split("#",1)[0]
                    if ":" not in host_port: continue
                    host, port = host_port.rsplit(":",1)
                else:
                    if "@" not in after: continue
                    b64cred, rest = after.split("@",1)
                    method_password = base64.urlsafe_b64decode(b64fix(b64cred)).decode()
                    method, password = method_password.split(":",1)
                    host_port = rest.split("#",1)[0]
                    host, port = host_port.rsplit(":",1)
                method = method.strip(); password = password.strip(); host = host.strip(); port = safe_int(port.strip(),0)
                if not (method and password and host and port):
                    continue
                name = uniq_name(f"ss-{host}-{port}")
                p = {"name": name, "type":"ss", "server": host, "port": port, "cipher": method, "password": password, "udp": True}
                proxies.append(p)
            except Exception:
                continue
    except Exception:
        continue

# ----------------- TCP ping checks -----------------
def check_and_attach_ping(proxy):
    host = proxy.get("server") or ""
    port = proxy.get("port") or 0
    if not host or not port:
        proxy["ping"] = None
        proxy["status"] = "dead"
        return proxy
    lat = tcp_ping_ms(host, port, timeout=3.0)
    if lat is None:
        proxy["ping"] = None
        proxy["status"] = "dead"
    else:
        proxy["ping"] = lat
        proxy["status"] = "ok"
    return proxy

results = []
if proxies:
    max_workers = min(40, len(proxies))
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futs = {ex.submit(check_and_attach_ping, p): idx for idx,p in enumerate(proxies)}
        for fut in as_completed(futs):
            try:
                res = fut.result()
                results.append(res)
            except Exception:
                pass

name_map = {p["name"]: p for p in results} if results else {p["name"]: p for p in proxies}
final_proxies = [name_map.get(p["name"], p) for p in proxies]

good = [p for p in final_proxies if p.get("status")=="ok"]
good_sorted = sorted(good, key=lambda x: x.get("ping", 99999))
proxy_names = [p["name"] for p in final_proxies]


# ----------------- نام گروه‌ها (مرتب و قابل ویرایش) -----------------
# =====================================
# Functions
# =====================================

def live_autoswitch(proxies):
    ok = [p for p in proxies if p["status"] == "ok"]
    ok.sort(key=lambda x: x["ping"] if x["ping"] is not None else 99999)
    
    fast3 = ok[:13]
    
    groups = [
        {
            "name": "💚SELECT",
            "type": "fallback",
            "proxies": [p["name"] for p in ok]
        },
        {
            "name": "🌐 All Proxies",
            "type": "select",
            "proxies": [p["name"] for p in ok]
        },
        {
            "name": "⚡ Fastest AutoSwitch",
            "type": "url-test",
            "proxies": [p["name"] for p in fast3],
            "url": "http://www.google.com/generate_204",
            "interval": 6783
        },
        {
            "name": "🔰Stable Fallback",
            "type": "fallback",
            "proxies": [p["name"] for p in ok],
            "url": "http://www.google.com/generate_204",
            "interval": 6666
        },
    ]
    
    return {"proxies": ok, "proxy-groups": groups}


# =====================================
# Main Execution Loop
# =====================================
if __name__ == "__main__":
    try:
        lines = open(INPUT_PATH, "r", encoding="utf-8").read().splitlines()
    except FileNotFoundError:
        print(f"Error: File {INPUT_PATH} not found!")
        sys.exit(1)

    raw_proxies = [p for ln in lines if (p := parse_line(ln))]

    def update_loop():
        while True:
            with ThreadPoolExecutor(max_workers=30) as exe:
                final = list(exe.map(attach_ping, raw_proxies))
            data = live_autoswitch(final)
            with open(OUT_PATH, "w", encoding="utf-8") as f:
                yaml.dump(data, f, allow_unicode=True)
            print(f"[Ultra Rapid] YAML updated at {time.strftime('%H:%M:%S')}")
            time.sleep(21)

    threading.Thread(target=update_loop, daemon=True).start()
    print(f"\n✅ Ultra Live Rapid AutoSwitch running. Output: {OUT_PATH}")
    print("Press Ctrl-C to stop live updates.")
    
    try:
        while True:
            time.sleep(100)
    except KeyboardInterrupt:
        print("\nStopped by user.")    
    
    
