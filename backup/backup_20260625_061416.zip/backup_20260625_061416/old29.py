#!/data/data/com.termux/files/usr/bin/python3
import os, re, json, yaml, subprocess, base64, socket, time
from urllib.parse import urlparse, parse_qs, unquote
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import deque
import threading
from collections import defaultdict, deque
# ---------------- paths & editor ----------------
BASE_DIR = "/storage/emulated/0/Download/Akbar98"
os.makedirs(BASE_DIR, exist_ok=True)
INPUT_PATH = os.path.join(BASE_DIR, "input.txt")

with open(INPUT_PATH, "w", encoding="utf-8") as f:
    f.write("")
subprocess.call(["nano", INPUT_PATH])

out_folder = input("Enter output folder name in Download: ").strip()
if not out_folder:
    print("Folder name required."); exit(1)
OUT_DIR = os.path.join("/storage/emulated/0/Download", out_folder)
os.makedirs(OUT_DIR, exist_ok=True)

out_name = input("Enter output file name (without extension): ").strip()
if not out_name:
    print("File name required."); exit(1)
OUT_PATH = os.path.join(OUT_DIR, f"{out_name}.yaml")

# ---------------- valid ciphers ----------------
VALID_SS_CIPHERS = {
    "aes-128-ctr", "aes-192-ctr", "aes-256-ctr",
    "aes-128-cfb", "aes-192-cfb", "aes-256-cfb",
    "aes-128-gcm", "aes-192-gcm", "aes-256-gcm",
    "aes-128-ccm", "aes-192-ccm", "aes-256-ccm",
    "aes-128-gcm-siv", "aes-256-gcm-siv",
    "chacha20-ietf", "chacha20-ietf-poly1305",
    "xchacha20-ietf-poly1305",
    "2022-blake3-aes-128-gcm",
    "2022-blake3-aes-256-gcm",
    "2022-blake3-chacha20-poly1305"
}

# ---------------- helpers ----------------
def b64fix(s: str) -> str:
    s = s.strip().replace("\n","").replace(" ","")
    pad = len(s) % 4
    if pad: s += "=" * (4 - pad)
    return s

def safe_int(x, default=0):
    try: return int(x)
    except: return default

def sanitize(s: str) -> str:
    if not s: return ""
    return re.sub(r"[^A-Za-z0-9_\- .]", "", str(s)).strip()

_used_names = set()
def uniq_name(base: str) -> str:
    base = sanitize(base) or "Proxy"
    name = base
    i = 2
    while name in _used_names:
        name = f"{base} {i}"; i += 1
    _used_names.add(name)
    return name

def tail(s: str, n=6):
    if not s: return ""
    s2 = re.sub(r"[-]","",s)
    return s2[-n:] if len(s2) >= n else s2

# ---------------- TCP ping ----------------
def tcp_ping_once(host, port, timeout=0.2):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        start = time.time()
        sock.connect((host, port))
        sock.close()
        return int((time.time() - start) * 1000)
    except:
        return None

def tcp_ping_median(host, port, attempts=7):
    pings = []
    for _ in range(attempts):
        p = tcp_ping_once(host, port)
        if p is not None: pings.append(p)
    if pings:
        pings.sort()
        mid = len(pings) // 2
        return pings[mid] if len(pings) % 2 else (pings[mid-1]+pings[mid])//2
    return None

def tcp_ping_ms(host, port, timeout=0.2):
    try:
        start = time.monotonic()
        sock = socket.create_connection((host, int(port)), timeout=timeout)
        sock.close()
        return int((time.monotonic() - start) * 1000)
    except Exception:
        return None

def attach_ping(proxy):
    proxy['ping'] = tcp_ping_median(proxy['server'], proxy['port'])
    proxy['status'] = "ok" if proxy['ping'] is not None else "fail"
    return proxy

# ----------------- read input -----------------
try:
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        content = f.read()
except Exception:
    content = ""
from urllib.parse import urlparse, parse_qs, unquote

# ================== JSON extractor (برای سازگاری – استفاده نمی‌شود) ==================
def extract_json_objects(text):
    return []


# ================== PROTOCOL PARSERS (LINEAR ONLY) ==================

def parse_vless(line):
    if not line.lower().startswith("vless://"):
        return None
    try:
        raw = line[8:]
        name = ""
        if "#" in raw:
            raw, name = raw.split("#", 1)
            name = unquote(name)

        if "@" not in raw:
            return None

        if "?" in raw:
            main, qs = raw.split("?", 1)
            q = dict(x.split("=",1) for x in qs.split("&") if "=" in x)
        else:
            main, q = raw, {}

        uuid, rest = main.split("@", 1)
        host, port = rest.split(":",1) if ":" in rest else (rest, "443")

        p = {
            "name": uniq_name(name or f"vless-{host}-{tail(uuid)}"),
            "type": "vless",
            "server": host,
            "port": safe_int(port,443),
            "uuid": uuid,
            "encryption": q.get("encryption","none"),
            "network": (q.get("type") or q.get("network") or "tcp"),
            "udp": True
        }

        if q.get("security") == "tls":
            p["tls"] = True
            p["servername"] = q.get("sni") or q.get("host") or host

        if p["network"] == "ws":
            p["ws-opts"] = {"path": q.get("path","/")}
            if q.get("host"):
                p["ws-opts"]["headers"] = {"Host": q.get("host")}

        if p["network"] == "grpc" and q.get("serviceName"):
            p["grpc-opts"] = {"grpc-service-name": q.get("serviceName")}

        return p
    except:
        return None


def parse_trojan(line):
    if not line.lower().startswith("trojan://"):
        return None
    try:
        u = urlparse(line)
        if not u.hostname or not u.username:
            return None

        p = {
            "name": uniq_name(u.fragment or f"trojan-{u.hostname}"),
            "type": "trojan",
            "server": u.hostname,
            "port": u.port or 443,
            "password": u.username,
            "udp": True
        }

        q = parse_qs(u.query)
        if q.get("sni"):
            p["sni"] = q["sni"][0]

        if q.get("type",[""])[0] == "ws":
            p["network"] = "ws"
            p["ws-opts"] = {"path": q.get("path",["/"])[0]}

        return p
    except:
        return None


def parse_ss(line):
    if not line.lower().startswith("ss://"):
        return None
    try:
        body = line[5:]
        name = ""
        if "#" in body:
            body, name = body.split("#",1)
            name = unquote(name)

        if "@" not in body or ":" not in body:
            return None

        creds, addr = body.split("@",1)
        method, password = creds.split(":",1)
        host, port = addr.split(":",1)

        return {
            "name": uniq_name(name or f"ss-{host}"),
            "type": "ss",
            "server": host,
            "port": safe_int(port),
            "cipher": method,
            "password": password,
            "udp": True
        }
    except:
        return None


def parse_hysteria1(line):
    if not line.lower().startswith("hy://"):
        return None
    try:
        raw = line[5:]
        if "@" not in raw:
            return None
        auth, rest = raw.split("@",1)
        host, port = rest.split(":",1)

        return {
            "name": uniq_name(f"hysteria-{host}"),
            "type": "hysteria",
            "server": host,
            "port": safe_int(port),
            "auth": auth,
            "udp": True
        }
    except:
        return None


def parse_hysteria2(line):
    if not (line.lower().startswith("hy2://") or line.lower().startswith("hysteria2://")):
        return None
    try:
        raw = line.split("://",1)[1]
        auth, rest = raw.split("@",1)
        host, port = rest.split(":",1)

        return {
            "name": uniq_name(f"hysteria2-{host}"),
            "type": "hysteria2",
            "server": host,
            "port": safe_int(port),
            "password": auth,
            "udp": True
        }
    except:
        return None


def parse_http(line):
    if not line.lower().startswith("http://"):
        return None
    try:
        u = urlparse(line)
        if not u.hostname or not u.port:
            return None

        return {
            "name": uniq_name(f"http-{u.hostname}"),
            "type": "http",
            "server": u.hostname,
            "port": u.port,
            "username": u.username or "",
            "password": u.password or "",
            "udp": False
        }
    except:
        return None


def parse_socks(line):
    if not (line.lower().startswith("socks://") or line.lower().startswith("socks5://")):
        return None
    try:
        u = urlparse(line)
        if not u.hostname or not u.port:
            return None

        return {
            "name": uniq_name(f"socks-{u.hostname}"),
            "type": "socks5",
            "server": u.hostname,
            "port": u.port,
            "username": u.username or "",
            "password": u.password or "",
            "udp": True
        }
    except:
        return None


# ---------- FALLBACK: RAW IP:PORT ----------
def parse_ipport(line):
    if ":" in line and "://" not in line:
        try:
            host, port = line.split(":",1)
            return {
                "name": uniq_name(f"raw-{host}"),
                "type": "http",
                "server": host,
                "port": safe_int(port),
                "udp": True
            }
        except:
            return None
    return None


# ================== MASTER ==================
def parse_line_any(line):
    for fn in (
        parse_vless,
        parse_trojan,
        parse_ss,
        parse_hysteria1,
        parse_hysteria2,
        parse_http,
        parse_socks
    ):
        p = fn(line)
        if p:
            return [p]

    p = parse_ipport(line)
    return [p] if p else []


def parse_any(text):
    proxies = []
    for ln in text.splitlines():
        ln = ln.strip()
        if not ln:
            continue
        proxies.extend(parse_line_any(ln))
    return proxies
# ================== RUN PARSER ON INPUT ==================

print("[*] Reading input...")
try:
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        raw_input = f.read()
except Exception:
    raw_input = ""

print("[*] Parsing proxies...")
parsed_proxies = parse_any(raw_input)

if not parsed_proxies:
    print("[!] No proxies parsed from input.")
    proxies = []
else:
    print(f"[+] Parsed {len(parsed_proxies)} raw proxies")

# ================== DEDUPE ==================
def dedupe_proxies(items):
    seen = set()
    out = []
    for p in items:
        key = (
            p.get("type"),
            p.get("server"),
            int(safe_int(p.get("port"))),
            p.get("uuid") or p.get("password") or p.get("auth") or ""
        )
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
    return out

proxies = dedupe_proxies(parsed_proxies)
print(f"[+] {len(proxies)} unique proxies after dedupe")

# ================== BASIC VALIDATION ==================
def validate_proxy(p):
    if not isinstance(p, dict):
        return False
    if not p.get("type") or not p.get("server"):
        return False

    port = safe_int(p.get("port"))
    if not (1 <= port <= 65535):
        return False

    t = p.get("type")
    if t in ("vless","vmess") and not p.get("uuid"):
        return False
    if t == "trojan" and not p.get("password"):
        return False
    if t == "ss" and not (p.get("cipher") and p.get("password")):
        return False

    return True

proxies = [p for p in proxies if validate_proxy(p)]
print(f"[+] {len(proxies)} proxies passed validation")

# ================== PING ATTACH ==================
def check_and_attach_ping(proxy):
    host = proxy.get("server")
    port = proxy.get("port")

    if not host or not port:
        proxy["ping"] = None
        proxy["status"] = "dead"
        return proxy

    ping = tcp_ping_ms(host, port, timeout=2)
    if ping is None:
        proxy["ping"] = None
        proxy["status"] = "dead"
    else:
        proxy["ping"] = ping
        proxy["status"] = "ok"

    return proxy
    
# ----------------- TCP ping checks -----------------
def check_and_attach_ping(proxy):
    host = proxy.get("server") or ""
    port = proxy.get("port") or 0
    if not host or not port:
        proxy["ping"] = None
        proxy["status"] = "dead"
        return proxy
    lat = tcp_ping_ms(host, port, timeout=3.0)
    if lat is None:
        proxy["ping"] = None
        proxy["status"] = "dead"
    else:
        proxy["ping"] = lat
        proxy["status"] = "ok"
    return proxy

proxies = parsed_proxies
results = []
if proxies:
    max_workers = min(40, len(proxies))
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futs = {ex.submit(check_and_attach_ping, p): idx for idx, p in enumerate(proxies)}
        for fut in as_completed(futs):
            try:
                res = fut.result()
                results.append(res)
            except Exception:
                pass

name_map = {p.get("name", ""): p for p in results} if results else {p.get("name", ""): p for p in proxies}
final_proxies = [name_map.get(p.get("name", ""), p) for p in proxies]
good_sorted = sorted([p for p in final_proxies if p.get("status")=="ok"], key=lambda x: x.get("ping",99999))
proxy_names = [p.get("name","") for p in final_proxies]

# ----------------- گروه‌ها و تنظیمات -----------------
Select, Auto, Stable, Fallback, T1, T2, T3 = \
"🟢SELECT🟢","🔴AUTO🔴","🥌STABLE🥌","🔵FALLBACK🔵","🟣SHAH🟣","🟡FAST🟡","🟠JAVED_SHAH🟠"

PING_RANGES = {"green":(1,50),"yellow":(51,1500),"dead":(0,0),"too_high":(1501,99999)}
GROUP_SETTINGS = {
    "Auto":{"min_proxies":12,"ping_color":"green","interval":25,"tolerance":50,"timeout":2},
    "Stable":{"min_proxies":12,"ping_color":"green","interval":3,"tolerance":50,"timeout":2},
    "Fallback":{"min_proxies":12,"ping_color":"yellow","interval":20,"tolerance":50,"timeout":3},
    "T1":{"min_proxies":12,"ping_color":"green","interval":1895,"tolerance":50,"timeout":2},
    "T2":{"min_proxies":12,"ping_color":"yellow","interval":300,"tolerance":50,"timeout":3},
    "T3":{"min_proxies":12,"ping_color":"yellow","interval":29860,"tolerance":50,"timeout":33}
}

proxy_health = defaultdict(lambda: {"fail":0,"penalty":0,"ban_until":0})
MAX_FAIL,BAN_TIME,PENALTY_TIMEOUT,PENALTY_DECAY = 3,120,300,50

def is_proxy_usable(name): return time.time() >= proxy_health[name]["ban_until"]
def mark_proxy_fail(name):
    h = proxy_health[name]
    h["fail"] += 1
    h["penalty"] += PENALTY_TIMEOUT
    if h["fail"]>=MAX_FAIL:
        h["ban_until"]=time.time()+BAN_TIME
        h["fail"]=0
def mark_proxy_success(name):
    h = proxy_health[name]
    if h["penalty"]>0: h["penalty"]=max(0,h["penalty"]-PENALTY_DECAY)

# ----------------- اصلاح تابع get_group_proxies -----------------
def get_group_proxies(group_name):
    settings = GROUP_SETTINGS.get(group_name, {})
    ping_color = settings.get("ping_color", "green")
    ping_min, ping_max = PING_RANGES.get(ping_color, (1, 99999))
    
    candidates = [p for p in good_sorted if p.get("status")=="ok" and ping_min <= p.get("ping", 0) <= ping_max and is_proxy_usable(p.get("name",""))]
    candidates.sort(key=lambda x: x.get("ping", 99999) + proxy_health[x.get("name","")]["penalty"])
    selected = [p.get("name","") for p in candidates]  # همه پروکسی‌های مناسب
    
    if not selected:
        selected = [final_proxies[0].get("name","")] if final_proxies else ["DIRECT"]
    return selected
    
    # ----------------- ساخت config نهایی -----------------
config = {
    "proxies": final_proxies,
    "proxy-groups":[
        {"name":Select,"type":"select","proxies":[Auto,Stable,Fallback,"DIRECT"]+proxy_names},
        {"name":Auto,"type":"url-test","url":"https://www.gstatic.com/generate_204","interval":GROUP_SETTINGS["Auto"]["interval"],"tolerance":GROUP_SETTINGS["Auto"]["tolerance"],"proxies":get_group_proxies("Auto")},
        {"name":Stable,"type":"fallback","url":"https://www.gstatic.com/generate_204","interval":GROUP_SETTINGS["Stable"]["interval"],"proxies":get_group_proxies("Stable")},
        {"name":Fallback,"type":"fallback","url":"https://www.gstatic.com/generate_204","interval":GROUP_SETTINGS["Fallback"]["interval"],"timeout":GROUP_SETTINGS["Fallback"]["timeout"],"tolerance":GROUP_SETTINGS["Fallback"]["tolerance"],"proxies":get_group_proxies("Fallback")},
        {"name":T1,"type":"url-test","url":"https://www.gstatic.com/generate_204","interval":GROUP_SETTINGS["T1"]["interval"],"tolerance":GROUP_SETTINGS["T1"]["tolerance"],"proxies":get_group_proxies("T1")},
        {"name":T2,"type":"fallback","url":"https://www.gstatic.com/generate_204","interval":GROUP_SETTINGS["T2"]["interval"],"proxies":get_group_proxies("T2")},
        {"name":T3,"type":"fallback","url":"https://www.gstatic.com/generate_204","interval":GROUP_SETTINGS["T3"]["interval"],"timeout":GROUP_SETTINGS["T3"]["timeout"],"tolerance":GROUP_SETTINGS["T3"]["tolerance"],"proxies":get_group_proxies("T3")}
    ],
    "rules":[f"MATCH,{Select}"]
}

with open(OUT_PATH,"w",encoding="utf-8") as f:
    yaml.safe_dump(config,f,allow_unicode=True,sort_keys=False)

print(f"[✅] Saved {len(final_proxies)} proxies to {OUT_PATH}")

# ----------------- smart auto switch -----------------
MIN_PROXIES=min(10,len(good_sorted))
stable_proxies=good_sorted[:MIN_PROXIES]
ping_history={p.get('name',""):deque(maxlen=50) for p in stable_proxies}
stability_score={p.get('name',""):0 for p in stable_proxies}
DEFAULT_PING=1500
PING_TIMEOUT=2

def update_groups_with_ping():
    for group_name, settings in GROUP_SETTINGS.items():
        ping_min,ping_max=PING_RANGES[settings["ping_color"]]
        filtered=[p for p in good_sorted if p.get("status")=="ok" and ping_min<=p.get("ping",0)<=ping_max]
        filtered.sort(key=lambda x:x.get("ping",99999))
        selected=[p.get("name","") for p in filtered]
        if group_name=="Fallback" and not selected:
            selected=[final_proxies[0].get("name","")] if final_proxies else ["DIRECT"]
        for group in config['proxy-groups']:
            if group['name']==group_name: group['proxies']=selected

update_groups_with_ping()

def smart_auto_switch_optimized():
    if not stable_proxies: return
    active=stable_proxies[0]
    while True:
        best=active
        best_score=float('inf')
        for p in stable_proxies:
            ping=tcp_ping_ms(p.get('server',''),p.get('port',0),timeout=PING_TIMEOUT)
            if ping is not None:
                ping_history[p.get('name',"")].append(ping)
                avg_ping=sum(ping_history[p.get('name',"")])/len(ping_history[p.get('name',"")])
                stability_score[p.get('name',"")]=stability_score.get(p.get('name',""),0)+1
                variance=(max(ping_history[p.get('name',"")])-min(ping_history[p.get('name',"")])) if len(ping_history[p.get('name',"")])>1 else 0
            else:
                avg_ping=DEFAULT_PING
                stability_score[p.get('name',"")]=0
                variance=DEFAULT_PING
            w1,w2,w3=0.5,-0.35,0.15
            score=w1*avg_ping+w2*stability_score[p.get('name',"")]+w3*variance
            if score<best_score:
                best_score=score
                best=p
        if best.get('name',"")!=active.get('name',""):
            active=best
            avg_ping=sum(ping_history[active.get('name',"")])/len(ping_history[active.get('name',"")])
            print(f"[⚡] Switched to optimal proxy: {active.get('name','')} | avg_ping={avg_ping:.1f}ms | stability={stability_score[active.get('name','')]} | variance={variance:.1f}")
        update_groups_with_ping()
        with open(OUT_PATH,"w",encoding="utf-8") as f:
            yaml.safe_dump(config,f,allow_unicode=True,sort_keys=False)
        active_avg_ping=sum(ping_history[active.get('name',"")])/len(ping_history[active.get('name',"")]) if ping_history[active.get('name',"")] else DEFAULT_PING
        active_variance=(max(ping_history[active.get('name',"")])-min(ping_history[active.get('name',"")])) if len(ping_history[active.get('name',"")])>1 else 0
        if active_avg_ping<200 and active_variance<50: sleep_time=1
        elif active_avg_ping<500: sleep_time=3
        else: sleep_time=6
        time.sleep(sleep_time)

threading.Thread(target=smart_auto_switch_optimized,daemon=True).start()
print("[✅] Smart auto-switch thread started")
