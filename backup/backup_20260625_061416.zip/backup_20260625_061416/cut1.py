import os
from rich import print
from rich.table import Table

# --- Fixed Output Path ---
BASE_PATH = "/storage/emulated/0/Download/"

# --- Input Links ---
print("[bold cyan]Paste your configs or sub links (press CTRL+D to finish):[/bold cyan]")
lines = []
try:
    while True:
        line = input().strip()
        if line:
            lines.append(line)
except EOFError:
    pass

if not lines:
    print("[bold red]❌ No configs provided![/bold red]")
    exit(1)

# --- Remove duplicates ---
unique_lines = list(dict.fromkeys(lines))
print(f"[bold green]✔ {len(unique_lines)} unique configs loaded[/bold green]")

# --- Categorize by Protocol ---
PROTOCOLS = ["vmess", "vless", "trojan", "hy2", "hysteria2", "ss", "socks", "wireguard"]
protocol_map = {p: [] for p in PROTOCOLS}
protocol_map["other"] = []

for line in unique_lines:
    matched = False
    for p in PROTOCOLS:
        if line.lower().startswith(p + "://"):
            protocol_map[p].append(line)
            matched = True
            break
    if not matched:
        protocol_map["other"].append(line)

# --- Show Table Summary ---
table = Table(title="Config Summary")
table.add_column("Protocol", justify="left", style="bold cyan")
table.add_column("Count", justify="right", style="bold yellow")

for p in PROTOCOLS + ["other"]:
    table.add_row(p, str(len(protocol_map[p])))

print(table)

# --- Ask split mode ---
split_choice = input("\n[bold cyan]Split each protocol into multiple files? (y/n):[/bold cyan] ").strip().lower()
package_size = None

if split_choice == "y":
    while True:
        try:
            package_size = int(input("[bold cyan]Enter number of configs per file:[/bold cyan] ").strip())
            if package_size <= 0:
                raise ValueError
            break
        except ValueError:
            print("[bold red]❌ Please enter a valid positive integer![/bold red]")
else:
    print("[bold yellow]⚙️ Proceeding without split (one file per protocol).[/bold yellow]")

# --- Output Folder ---
output_folder_name = input("\n[bold cyan]Enter folder name for output files:[/bold cyan] ").strip()
if not output_folder_name:
    output_folder_name = "configs_output"

OUTPUT_FOLDER = os.path.join(BASE_PATH, output_folder_name)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# --- Write Files ---
for proto, group in protocol_map.items():
    if not group:
        continue

    total = len(group)

    if not package_size:  # no split
        file_name = f"{proto}.txt"
        file_path = os.path.join(OUTPUT_FOLDER, file_name)
        with open(file_path, "w", encoding="utf-8") as f:
            f.write("\n".join(group))
        print(f"[bold green]✔ Saved {total} configs → [yellow]{file_name}[/yellow][/bold green]")

    else:  # split mode
        parts = (total + package_size - 1) // package_size
        for i in range(parts):
            start = i * package_size
            end = min(start + package_size, total)
            chunk = group[start:end]
            suffix = f"{i}" if i > 0 else ""
            file_name = f"{proto}{suffix}.txt"
            file_path = os.path.join(OUTPUT_FOLDER, file_name)
            with open(file_path, "w", encoding="utf-8") as f:
                f.write("\n".join(chunk))
            print(f"[bold green]✔ Saved {len(chunk)} configs → [yellow]{file_name}[/yellow][/bold green]")

print(f"\n[bold green]✅ All files saved in:[/bold green] [bold yellow]{OUTPUT_FOLDER}[/bold yellow]")

