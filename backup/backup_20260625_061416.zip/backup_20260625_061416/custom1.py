#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import base64
import time
import uuid
from urllib.parse import urlparse, parse_qs, unquote

# ================= COLORS =================
G = "\033[92m"
B = "\033[94m"
Y = "\033[93m"
C = "\033[96m"
W = "\033[0m"

# ================= TEMPLATE =================
TEMPLATE = {
    "remarks": "CUSTOM-CONFIG",
    "log": {
        "access": "",
        "error": "",
        "loglevel": "info",
        "dnsLog": False
    },
    "inbounds": [
        {
            "tag": "in_proxy",
            "port": 1080,
            "protocol": "socks",
            "listen": "0.0.0.0",
            "settings": {
                "auth": "noauth",
                "udp": True,
                "userLevel": 8
            },
            "sniffing": {
                "enabled": False
            }
        }
    ],
    "outbounds": [
        {
            "tag": "proxy",
            "protocol": "trojan",
            "settings": {
                "servers": [{
                    "address": "",
                    "port": 0,
                    "password": ""
                }]
            },
            "streamSettings": {
                "network": "ws",
                "security": "tls",
                "wsSettings": {
                    "path": "/",
                    "headers": {
                        "Host": ""
                    }
                },
                "tlsSettings": {
                    "serverName": "",
                    "allowInsecure": True,
                    "alpn": ["http/1.1"],
                    "fingerprint": "ios"
                }
            }
        }
    ]
}

# ================= DETECT =================
def detect(link):
    if link.startswith("vless://"): return "vless"
    if link.startswith("trojan://"): return "trojan"
    if link.startswith("vmess://"): return "vmess"
    if link.startswith("ss://"): return "ss"
    return "unknown"

# ================= PARSERS =================
def parse_common(link):
    u = urlparse(link)
    q = parse_qs(u.query)

    return {
        "address": u.hostname,
        "port": u.port,
        "password": u.username,
        "host": q.get("host", [""])[0] or q.get("sni", [""])[0],
        "sni": q.get("sni", [""])[0] or q.get("host", [""])[0],
        "path": unquote(q.get("path", ["/"])[0])
    }

def parse_vmess(link):
    raw = link.replace("vmess://", "")
    try:
        j = json.loads(base64.b64decode(raw + "==").decode())
    except:
        j = json.loads(base64.b64decode(raw).decode())

    return {
        "address": j.get("add"),
        "port": int(j.get("port", 0)),
        "password": j.get("id"),
        "host": j.get("host", ""),
        "sni": j.get("host", ""),
        "path": j.get("path", "/")
    }

def parse_ss(link):
    u = urlparse(link)
    raw = base64.b64decode(u.username + "==").decode()
    _, pwd = raw.split(":", 1)

    return {
        "address": u.hostname,
        "port": u.port,
        "password": pwd,
        "host": unquote(u.fragment),
        "sni": unquote(u.fragment),
        "path": "/"
    }

# ================= BUILD =================
def build_one(data):
    cfg = json.loads(json.dumps(TEMPLATE))

    s = cfg["outbounds"][0]["settings"]["servers"][0]
    st = cfg["outbounds"][0]["streamSettings"]

    s["address"] = data.get("address", "")
    s["port"] = data.get("port", 0)
    s["password"] = data.get("password", "")

    host = data.get("host", "") or data.get("sni", "")
    sni = data.get("sni", "") or data.get("host", "")

    if "+" in host:
        host = host.replace("+", ".")
    if "+" in sni:
        sni = sni.replace("+", ".")

    if len(sni) < 3:
        sni = host

    st["wsSettings"]["headers"]["Host"] = host
    st["tlsSettings"]["serverName"] = sni
    st["wsSettings"]["path"] = data.get("path", "/")

    return cfg

# ================= MENU =================
print(C + "==============================" + W)
print(G + "   CUSTOM BUILDER TOOL   " + W)
print(C + "==============================\n" + W)

print(Y + "1) Paste Mode" + W)
print(Y + "2) Nano Mode (TEMP)" + W)
print(Y + "0) Exit\n" + W)

mode = input(B + "Select > " + W).strip()

links = []

# ================= PASTE MODE =================
if mode == "1":
    print("\nPaste links (END to finish):")
    while True:
        x = input().strip()
        if x == "END":
            break
        links.append(x)

# ================= NANO MODE =================
elif mode == "2":
    tmp = f"/data/data/com.termux/files/home/tmp_{uuid.uuid4().hex}.txt"

    print("\nOpening Nano Editor...")
    os.system(f"nano {tmp}")

    time.sleep(0.2)

    if os.path.exists(tmp):
        with open(tmp, "r") as f:
            links = [i.strip() for i in f.readlines() if i.strip()]

    try:
        os.remove(tmp)
    except:
        pass

elif mode == "0":
    exit()

else:
    print("Invalid")
    exit()

# ================= CHECK =================
if not links:
    print("NO INPUT FOUND")
    exit()

# ================= PROCESS =================
results = []

for link in links:

    t = detect(link)

    if t == "vmess":
        data = parse_vmess(link)
    elif t == "ss":
        data = parse_ss(link)
    else:
        data = parse_common(link)

    results.append(build_one(data))

# ================= CLEAN OUTPUT FIX =================
print("\n")

for cfg in results:
    print(json.dumps(cfg, ensure_ascii=False))
    print()
