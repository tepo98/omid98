#!/data/data/com.termux/files/usr/bin/bash

CYAN='\033[1;36m'
GREEN='\033[1;32m'
NC='\033[0m'

clear
echo -e "${CYAN}=== ARRAY CUSTOM BUILDER (FIXED) ===${NC}"
echo
echo "Paste trojan links (CTRL + D to finish):"
INPUT=$(cat)

OUTFILE="custom.txt"
> "$OUTFILE"

# ===== BASE TEMPLATE =====
BASE='{
"remarks":"hamedvpns-XSfilternet",
"log":{"loglevel":"info"},
"inbounds":[{"tag":"in","port":1080,"protocol":"socks"}],
"outbounds":[
{
"tag":"proxy",
"protocol":"trojan",
"settings":{
"servers":[
{
"address":"🌟",
"password":"🌟",
"port":443
}
]
},
"streamSettings":{
"network":"ws",
"wsSettings":{
"path":"🌟",
"headers":{"Host":"🌟"}
},
"tlsSettings":{
"serverName":"🌟"
}
}
}
],
"dns":{"servers":["8.8.8.8"]},
"routing":{"domainStrategy":"UseIp"}
}'

echo "[" >> "$OUTFILE"

FIRST=1

echo "$INPUT" | while read -r line; do
    [ -z "$line" ] && continue

    IP=$(echo "$line" | sed -n 's/.*@\([^:]*\):.*/\1/p')
    PORT=$(echo "$line" | sed -n 's/.*:\([0-9]*\)?.*/\1/p')
    PASS=$(echo "$line" | sed -n 's|trojan://\([^@]*\)@.*|\1|p' | sed 's/%.*//')

    PATHWS=$(echo "$line" | sed -n 's/.*path=\([^&]*\).*/\1/p')
    HOST=$(echo "$line" | sed -n 's/.*host=\([^&]*\).*/\1/p')
    SNI=$(echo "$line" | sed -n 's/.*sni=\([^&#]*\).*/\1/p')

    [ -z "$PORT" ] && PORT=443

    OUTPUT="$BASE"

    OUTPUT=$(echo "$OUTPUT" | sed "0,/🌟/s//${IP}/")
    OUTPUT=$(echo "$OUTPUT" | sed "0,/🌟/s//${PASS}/")
    OUTPUT=$(echo "$OUTPUT" | sed "0,/🌟/s//${PATHWS}/")
    OUTPUT=$(echo "$OUTPUT" | sed "0,/🌟/s//${HOST}/")
    OUTPUT=$(echo "$OUTPUT" | sed "0,/🌟/s//${SNI}/")

    # ===== JSON ARRAY FIX =====
    if [ $FIRST -eq 0 ]; then
        echo "," >> "$OUTFILE"
    fi
    FIRST=0

    echo "$OUTPUT" >> "$OUTFILE"

done

echo "]" >> "$OUTFILE"

echo -e "${GREEN}Saved: $OUTFILE${NC}"

# ===== AUTO COPY =====
termux-clipboard-set < "$OUTFILE"

echo -e "${CYAN}Copied to clipboard ✔${NC}"
