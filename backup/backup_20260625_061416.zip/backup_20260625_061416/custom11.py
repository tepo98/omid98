import json
import copy
from urllib.parse import urlparse, parse_qs, unquote

# ===== BASE TEMPLATE (UNCHANGED) =====
BASE = {
    "remarks": "CUSTOM-CONFIG",
    "outbounds": [
        {
            "protocol": "trojan",
            "settings": {
                "servers": [
                    {
                        "address": "",
                        "port": 0,
                        "password": ""
                    }
                ]
            },
            "streamSettings": {
                "wsSettings": {
                    "path": "",
                    "headers": {
                        "Host": ""
                    }
                },
                "tlsSettings": {
                    "serverName": ""
                }
            }
        }
    ]
}

# ===== SIMPLE EXTRACT (NO SMART LOGIC) =====
def extract(link):
    u = urlparse(link)
    q = parse_qs(u.query)

    return {
        "address": u.hostname or "",
        "port": u.port or 0,
        "password": u.username or "",
        "host": q.get("host", [""])[0],
        "sni": q.get("sni", [""])[0],
        "path": unquote(q.get("path", [""])[0])
    }

# ===== PURE REPLACE ONLY =====
def build(link):
    d = extract(link)
    cfg = copy.deepcopy(BASE)

    srv = cfg["outbounds"][0]["settings"]["servers"][0]
    st = cfg["outbounds"][0]["streamSettings"]

    # ONLY REPLACE (NO TOUCH ELSE)
    srv["address"] = d["address"]
    srv["port"] = d["port"]
    srv["password"] = d["password"]

    if d["host"]:
        st["wsSettings"]["headers"]["Host"] = d["host"]

    if d["sni"]:
        st["tlsSettings"]["serverName"] = d["sni"]

    if d["path"]:
        st["wsSettings"]["path"] = d["path"]

    return cfg

# ===== RUN =====
link = input("Paste link:\n> ").strip()
print(json.dumps(build(link), ensure_ascii=False, indent=2))
