#!/data/data/com.termux/files/usr/bin/python3
import sys
from pathlib import Path

# ---------- Colors ----------
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'

# ---------- Default Output Directory ----------
DEFAULT_OUTPUT_DIR = "/sdcard/Download"

# ---------- Input Section ----------
print(f"{Colors.HEADER}📋 Paste your links below (one per line).")
print(f"Press Enter to go to next line.")
print(f"When finished, press Ctrl+D (EOF) to continue.{Colors.ENDC}")

lines = []
try:
    while True:
        line = input()
        lines.append(line.strip())
except EOFError:
    pass

# ---------- Validate Input ----------
if not lines:
    print(f"{Colors.FAIL}❌ No links entered. Exiting.{Colors.ENDC}")
    sys.exit(1)

# ---------- Link Classification ----------
vless_links = [l for l in lines if l.startswith("vless://")]
trojan_links = [l for l in lines if l.startswith("trojan://")]
ss_links = [l for l in lines if l.startswith("ss://") or l.startswith("ssss://")]
total = len(lines)

# ---------- Print Statistics ----------
print(f"\n{Colors.OKBLUE}================ Statistics ================\n{Colors.ENDC}")
print(f"{Colors.OKGREEN}{'Protocol':<10} {'Count':>6}{Colors.ENDC}")
print(f"{'VLESS':<10} {len(vless_links):>6}")
print(f"{'Trojan':<10} {len(trojan_links):>6}")
print(f"{'SS/SSS':<10} {len(ss_links):>6}")
print(f"{'-'*22}")
print(f"{'Total':<10} {total:>6}")
print(f"{Colors.OKBLUE}============================================{Colors.ENDC}\n")

# ---------- Folder Name ----------
folder_name = input(f"{Colors.HEADER}Enter folder name for output (e.g. almasi): {Colors.ENDC}").strip()
if not folder_name:
    print(f"{Colors.FAIL}❌ Folder name cannot be empty. Exiting.{Colors.ENDC}")
    sys.exit(1)

output_path = Path(DEFAULT_OUTPUT_DIR) / folder_name
try:
    output_path.mkdir(parents=True, exist_ok=True)
except Exception as e:
    print(f"{Colors.FAIL}❌ Failed to create folder '{output_path}': {e}{Colors.ENDC}")
    sys.exit(1)

# ---------- Split Size ----------
while True:
    batch_input = input(f"{Colors.HEADER}Enter number of links per file: {Colors.ENDC}").strip()
    try:
        batch_size = int(batch_input)
        if batch_size <= 0:
            raise ValueError
        break
    except ValueError:
        print(f"{Colors.WARNING}⚠️ Please enter a valid positive number.{Colors.ENDC}")

# ---------- Split and Save ----------
total_links = len(lines)
num_files = (total_links + batch_size - 1) // batch_size  # Ceiling division

for i in range(num_files):
    start = i * batch_size
    end = min(start + batch_size, total_links)
    batch = lines[start:end]
    file_name = f"input{i+1}.txt"
    file_path = output_path / file_name
    try:
        with open(file_path, "w", encoding="utf-8") as f:
            f.write("\n".join(batch))
        print(f"{Colors.OKGREEN}✅ Saved {len(batch)} links to {file_name}{Colors.ENDC}")
    except Exception as e:
        print(f"{Colors.FAIL}❌ Failed to write {file_name}: {e}{Colors.ENDC}")

print(f"\n{Colors.OKBLUE}📁 All files saved in: {output_path}{Colors.ENDC}")
print(f"{Colors.OKGREEN}✅ Task completed successfully!{Colors.ENDC}\n")


