#!/data/data/com.termux/files/usr/bin/python3
# -*- coding: utf-8 -*-

import os, re, json, socket, time, subprocess, base64, yaml, sys
from urllib.parse import unquote
from concurrent.futures import ThreadPoolExecutor, as_completed

# ====================== PATHS =========================
BASE_DIR = "/storage/emulated/0/Download/ClashMetaParser"
os.makedirs(BASE_DIR, exist_ok=True)

INPUT_PATH = os.path.join(BASE_DIR, "input.txt")
with open(INPUT_PATH, "w", encoding="utf-8") as f:  
    f.write("")

try:
    subprocess.call(["nano", INPUT_PATH])
except:
    pass

out_folder = input("Enter output folder name in Download: ").strip() or "ClashMetaExport"
OUT_DIR = os.path.join("/storage/emulated/0/Download", out_folder)
os.makedirs(OUT_DIR, exist_ok=True)

out_name = input("Enter output file name: ").strip() or "proxies"
OUT_PATH = os.path.join(OUT_DIR, f"{out_name}.yaml")

# ====================== HELPERS =========================

def b64_fix(s):
    s = s.replace("-", "+").replace("_", "/")
    return s + "=" * (-len(s) % 4)

def safe_int(x, default=None):
    try:
        return int(x)
    except:
        return default

def split_host_port(h):
    if ":" in h:
        host, port = h.split(":", 1)
        return host.strip(), safe_int(port, 0)
    return h.strip(), 0

_used = set()
def unique(n):
    base = n
    i = 1
    while n in _used:
        n = f"{base}-{i}"
        i += 1
    _used.add(n)
    return n

# ====================== TCP PING =========================

def tcp_ping_once(host, port, timeout=0.7):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        t1 = time.time()
        s.connect((host, port))
        s.close()
        return int((time.time() - t1) * 1000)
    except:
        return None

def tcp_ping(host, port):
    vals = [tcp_ping_once(host, port) for _ in range(5)]
    vals = [v for v in vals if v is not None]
    if not vals:
        return None
    vals.sort()
    return vals[len(vals)//2]

# ====================== ADVANCED PARSERS =========================

def parse_vless(line):
    try:
        if not line.startswith("vless://"): return None
        raw = line[8:]
        name = None
        if "#" in raw:
            raw, name = raw.split("#", 1)
            name = unquote(name)

        user, _, rest = raw.partition("@")
        hostport, _, params = rest.partition("?")
        host, port = split_host_port(hostport)

        P = {k: v for k, v in (p.split("=", 1) for p in params.split("&") if "=" in p)}

        out = {
            "name": unique(name or f"VLESS-{host}"),
            "type": "vless",
            "server": host,
            "port": port or 443,
            "uuid": user,
            "tls": P.get("security", "none") in ["tls", "reality"],
            "network": P.get("type", "tcp"),
            "flow": P.get("flow", ""),
            "packet-encoding": "packetaddr"
        }

        if out["network"] == "ws":
            out["ws-opts"] = {
                "path": P.get("path", "/"),
                "headers": {"Host": P.get("host", host)}
            }

        if out["network"] == "grpc":
            out["grpc-opts"] = {"grpc-service-name": P.get("serviceName", "")}

        if P.get("security") == "reality":
            out["reality-opts"] = {
                "public-key": P.get("pbk", ""),
                "short-id": P.get("sid", "")
            }

        return out

    except:
        return None


def parse_trojan(line):
    try:
        if not line.startswith("trojan://"): return None
        raw = line[9:]

        name = None
        if "#" in raw:
            raw, name = raw.split("#", 1)
            name = unquote(name)

        pwd, _, rest = raw.partition("@")
        hostport, _, params = rest.partition("?")
        host, port = split_host_port(hostport)

        P = {k: v for k, v in (p.split("=", 1) for p in params.split("&") if "=" in p)}

        out = {
            "name": unique(name or f"Trojan-{host}"),
            "type": "trojan",
            "server": host,
            "port": port or 443,
            "password": pwd,
            "tls": True,
            "network": P.get("type", "tcp")
        }

        if out["network"] == "ws":
            out["ws-opts"] = {
                "path": P.get("path", "/"),
                "headers": {"Host": P.get("host", host)}
            }

        return out

    except:
        return None


def parse_ss(line):
    try:
        if not line.startswith("ss://"): return None
        raw = line[5:]
        name = None

        if "#" in raw:
            raw, name = raw.split("#", 1)
            name = unquote(name)

        decoded = base64.urlsafe_b64decode(b64_fix(raw)).decode()
        method_pwd, _, hostport = decoded.partition("@")
        method, pwd = method_pwd.split(":", 1)
        host, port = split_host_port(hostport)

        return {
            "name": unique(name or f"SS-{host}"),
            "type": "ss",
            "server": host,
            "port": port,
            "cipher": method,
            "password": pwd
        }
    except:
        return None


def parse_hysteria(line):
    try:
        if not line.startswith("hysteria://"): return None
        raw = line[11:]

        name = None
        if "#" in raw:
            raw, name = raw.split("#", 1)
            name = unquote(name)

        host, port = split_host_port(raw)
        return {
            "name": unique(name or f"Hysteria-{host}"),
            "type": "hysteria",
            "server": host,
            "port": port or 443,
            "udp": True
        }
    except:
        return None


# ====================== UNIVERSAL PARSE =========================

PARSE_FUNCS = [
    parse_vless,
    parse_trojan,
    parse_ss,
    parse_hysteria
]

def parse_any(l):
    for p in PARSE_FUNCS:
        r = p(l)
        if r:
            return r
    return None


# ====================== MAIN PROCESS =========================

def generate_yaml(text):
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    proxies = []

    for l in lines:
        p = parse_any(l)
        if p:
            proxies.append(p)

    proxies = list({(p["type"], p["server"], p["port"], p["name"]): p for p in proxies}.values())

    with ThreadPoolExecutor(max_workers=40) as ex:
        tasks = {ex.submit(tcp_ping, p["server"], p["port"]): p for p in proxies}

        for f in as_completed(tasks):
            p = tasks[f]
            ping = f.result()
            p["ping"] = ping
            p["alive"] = ping is not None

    proxies = [p for p in proxies if p["alive"]]
    proxies.sort(key=lambda x: x["ping"])

    names = [p["name"] for p in proxies]

    config = {
        "proxies": proxies,
        "proxy-groups": [
            {"name": "🔰 Selector", "type": "select", "proxies": names},
            {"name": "⚡ UltraFast", "type": "url-test",
             "url": "https://www.gstatic.com/generate_204",
             "tolerance": 20, "interval": 20, "proxies": names},

            {"name": "💎 Stable", "type": "fallback",
             "url": "https://www.gstatic.com/generate_204",
             "interval": 25, "proxies": names},

            {"name": "🏆 BestPing", "type": "url-test",
             "url": "https://www.gstatic.com/generate_204",
             "tolerance": 10, "interval": 15, "proxies": names},
        ],
        "rules": ["MATCH,🔰 Selector"]
    }

    with open(OUT_PATH, "w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, allow_unicode=True, sort_keys=False)

    print(f"\n[OK] Saved → {OUT_PATH}\n")


# ====================== ENTRY =========================

if __name__ == "__main__":
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        text = f.read()

    if not text.strip():
        print("Empty input!")
        sys.exit(0)

    generate_yaml(text)

