import os
import webbrowser

# ===== AUTO PATH (Download/HTML) =====
BASE_PATH = "/storage/emulated/0/Download/html"

# ===== COLORS =====
R = "\033[91m"
G = "\033[92m"
Y = "\033[93m"
B = "\033[94m"
C = "\033[96m"
W = "\033[0m"

def scan_html():
    files = []
    for root, dirs, fs in os.walk(BASE_PATH):
        for f in fs:
            if f.lower().endswith(".html"):
                files.append(os.path.join(root, f))
    return files

def clear():
    os.system("clear")

def show(files):
    clear()
    print(C + "===================================" + W)
    print(B + "   HTML LAUNCHER AUTO SCAN" + W)
    print(C + "===================================" + W)

    for i, f in enumerate(files, 1):
        print(G + f"{i}. {os.path.basename(f)}" + W)

    print("\n" + Y + "0. Exit" + W)

def open_file(path):
    url = "file://" + path
    print(B + "\nOPEN -> " + url + W)
    webbrowser.open(url)

while True:
    files = scan_html()

    if not files:
        print(R + "No HTML files found in Download/html !" + W)
        break

    show(files)

    choice = input(C + "\nSelect: " + W)

    if choice == "0":
        print(Y + "Exit..." + W)
        break

    if choice.isdigit():
        i = int(choice) - 1
        if 0 <= i < len(files):
            open_file(files[i])
        else:
            print(R + "Invalid choice" + W)
