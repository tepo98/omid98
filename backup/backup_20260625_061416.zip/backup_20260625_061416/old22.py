#!/data/data/com.termux/files/usr/bin/python3
# -*- coding: utf-8 -*-

import os, re, json, socket, time, subprocess, base64, yaml, threading
from urllib.parse import urlparse, parse_qs, unquote
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import deque

# =================== PATHS ===================
BASE_DIR = "/storage/emulated/0/Download/Akbar98"
os.makedirs(BASE_DIR, exist_ok=True)
INPUT_PATH = os.path.join(BASE_DIR, "input.txt")

with open(INPUT_PATH, "w", encoding="utf-8") as f:
    f.write("")
try:
    subprocess.call(["nano", INPUT_PATH])
except:
    pass

out_folder = input("Enter output folder name in Download: ").strip()
if not out_folder:
    print("Folder name required."); exit(1)
OUT_DIR = os.path.join("/storage/emulated/0/Download", out_folder)
os.makedirs(OUT_DIR, exist_ok=True)

out_name = input("Enter output file name (without extension): ").strip()
if not out_name:
    print("File name required."); exit(1)
OUT_PATH = os.path.join(OUT_DIR, f"{out_name}.yaml")

# =================== HELPERS ===================
def b64fix(s):
    if not s: return ""
    s = s.strip().replace("\n","").replace(" ","")
    s = s.replace("-", "+").replace("_", "/")
    pad = len(s) % 4
    if pad: s += "="*(4-pad)
    return s

def safe_int(x, default=0):
    try: return int(x)
    except: return default

def sanitize(s):
    if not s: return ""
    return re.sub(r"[^A-Za-z0-9_\- .\u0600-\u06FF]", "", str(s)).strip()

_used_names=set()
def uniq_name(base):
    base=sanitize(base) or "Proxy"
    name=base
    i=2
    while name in _used_names:
        name=f"{base} {i}"; i+=1
    _used_names.add(name)
    return name

def tail(s,n=6):
    if not s: return ""
    s2=re.sub(r"-","",str(s))
    return s2[-n:] if len(s2)>=n else s2

# =================== PING ===================
def ping_proxy(host, port, attempts=4, timeout=2.0):
    try:
        host_ip = socket.gethostbyname(host)
    except:
        return None
    results=[]
    for _ in range(attempts):
        try:
            t0=time.monotonic()
            sock=socket.create_connection((host_ip,int(port)), timeout=timeout)
            sock.close()
            ms=int((time.monotonic()-t0)*1000)
            results.append(ms)
            time.sleep(0.03)
        except:
            results.append(None)
    valid = [x for x in results if x is not None]
    if not valid: return None
    return min(valid)

def attach_ping(proxy):
    host=proxy.get("server")
    port=proxy.get("port")
    lat = ping_proxy(host, port)
    proxy["ping"]=lat
    proxy["status"]="ok" if lat is not None else "dead"
    return proxy

# =================== PARSERS ===================
def parse_link(line: str):
    line=line.strip()
    if not line: return None
    for parser in [parse_vless, parse_vmess, parse_trojan, parse_ss]:
        try:
            p=parser(line)
            if p: return p
        except:
            continue
    try:
        return json.loads(line)
    except:
        return None

def parse_vless(line):
    try:
        raw=line[8:]
        name_fragment=""
        if "#" in raw:
            raw,name_fragment=raw.split("#",1); name_fragment=unquote(name_fragment)
        if "?" in raw:
            main,qs=raw.split("?",1)
        else: main,qs=raw,""
        if "@" not in main: return None
        uid, rest = main.split("@",1)
        host, port = rest.split(":",1)
        q = dict(x.split("=",1) for x in qs.split("&") if "=" in x) if qs else {}
        name = uniq_name(name_fragment or f"vless-{host}-{tail(uid)}")
        p={"name":name,"type":"vless","server":host,"port":safe_int(port),"uuid":uid,"udp":True,"network":q.get("type","tcp")}
        if q.get("security")=="tls": p["tls"]=True; p["sni"]=q.get("sni") or host; p["servername"]=p["sni"]
        return p
    except: return None

def parse_vmess(line):
    try:
        raw=line[8:]
        js=None
        try: js=json.loads(base64.b64decode(b64fix(raw)).decode())
        except:
            try: js=json.loads(unquote(raw))
            except: return None
        host=js.get("add") or js.get("address")
        port=safe_int(js.get("port"))
        uid=js.get("id") or js.get("uuid")
        name=uniq_name(js.get("ps") or f"vmess-{host}-{tail(uid)}")
        p={"name":name,"type":"vmess","server":host,"port":port,"uuid":uid,"alterId":safe_int(js.get("aid", js.get("alterId",0))),"cipher":js.get("cipher","auto"),"udp":True,"network":js.get("net","tcp")}
        if js.get("tls")=="tls": p["tls"]=True; p["sni"]=js.get("sni") or host; p["servername"]=p["sni"]
        return p
    except: return None

def parse_trojan(line):
    try:
        raw=line[9:]
        if "#" in raw: raw,frag=raw.split("#",1); frag=unquote(frag)
        if "?" in raw: main,qs=raw.split("?",1)
        else: main,qs=raw,""
        if "@" not in main: return None
        pwd, hostport = main.split("@",1)
        host, port = hostport.split(":",1)
        name=uniq_name(frag or f"trojan-{host}-{tail(pwd)}")
        p={"name":name,"type":"trojan","server":host,"port":safe_int(port),"password":pwd,"udp":True,"network":"tcp","tls":True,"sni":host}
        return p
    except: return None

def parse_ss(line):
    try:
        raw=line[5:]
        if "@" in raw:
            creds, rest = raw.split("@",1)
            try:
                dec=base64.b64decode(b64fix(creds)).decode()
                method,pwd=dec.split(":",1)
            except:
                method,pwd=creds.split(":",1)
            host, port = rest.split(":",1)
        else:
            dec=base64.b64decode(b64fix(raw)).decode()
            pre, addr = dec.split("@",1)
            method, pwd = pre.split(":",1)
            host, port = addr.split(":",1)
        name=uniq_name(f"ss-{host}-{port}")
        p={"name":name,"type":"ss","server":host,"port":safe_int(port),"cipher":method,"password":pwd,"udp":True}
        return p
    except: return None

def validate_proxy(p):
    if not isinstance(p,dict): return False
    if not p.get("type") or not p.get("server") or not (1<=int(p.get("port",0))<=65535): return False
    t=p["type"]
    if t in ("vless","vmess") and not p.get("uuid"): return False
    if t=="trojan" and not p.get("password"): return False
    if t=="ss" and (not p.get("cipher") or not p.get("password")): return False
    return True

try:
    with open(INPUT_PATH,"r",encoding="utf-8") as f: content=f.read()
except: content=""
# =================== PROCESS INPUT ===================

# جدا کردن خطوط JSON و لینک
lines = [l.strip() for l in content.splitlines() if l.strip()]
json_blocks = []
links = []

buf=[]
for line in lines:
    if line.startswith("{") and line.endswith("}"):
        try:
            js=json.loads(line)
            json_blocks.append(js)
        except:
            links.append(line)
    elif any(line.lower().startswith(x) for x in ("vless://","vmess://","ss://","trojan://")):
        links.append(line)
    else:
        links.append(line)

# استخراج پروکسی‌ها
proxies=[]
for blk in json_blocks:
    if isinstance(blk,list):
        for item in blk:
            if validate_proxy(item):
                item["name"]=uniq_name(item.get("name","Proxy"))
                proxies.append(item)
    elif isinstance(blk,dict) and validate_proxy(blk):
        blk["name"]=uniq_name(blk.get("name","Proxy"))
        proxies.append(blk)

# از لینک‌ها
for line in links:
    p=parse_link(line)
    if validate_proxy(p):
        proxies.append(p)


if not proxies:
    print("[ERROR] No valid proxies found.")
    exit(1)

print(f"[INFO] Valid proxies found: {len(proxies)}")

# =================== PING ALL ===================
print("[INFO] Measuring ping…")

def ping_thread(p):
    return attach_ping(p)

with ThreadPoolExecutor(max_workers=25) as ex:
    futures=[ex.submit(ping_thread,p) for p in proxies]
    proxies=[f.result() for f in as_completed(futures)]

alive=[p for p in proxies if p.get("status")=="ok"]
dead=[p for p in proxies if p.get("status")!="ok"]

if not alive:
    print("[ERROR] All proxies dead, no output.")
    exit(1)

# =================== GROUPING ===================
# Stable = پایدارترین با پینگ بالا-پایین کم
# Fast = کمترین ping لحظه‌ای
# Fallback = ترکیب Stable + Fast

alive_sorted = sorted(alive, key=lambda x: x.get("ping") or 99999)

# Fast → 30% سریع‌ترین‌ها
fast_count = max(1, len(alive_sorted)//3)
fast_group = alive_sorted[:fast_count]

# Stable → 40% میانه با نوسان کمتر (باقیمانده وسط)
stable_start = fast_count
stable_end = stable_start + max(1, len(alive_sorted)//2)
stable_group = alive_sorted[stable_start:stable_end]

# Fallback = Fast + Stable (بدون تکرار)
fallback_group = []
seen=set()
for p in fast_group + stable_group:
    if p["name"] not in seen:
        fallback_group.append(p)
        seen.add(p["name"])

# =================== SMART SWITCH ===================
smart_switch = {
    "name": "Smart-Switch",
    "type": "select",
    "proxies": [p["name"] for p in fallback_group] or [alive_sorted[0]["name"]]
}

# =================== OUTPUT YAML ===================

final_yaml = {
    "proxies": alive_sorted,  
    "proxy-groups": [
        {
            "name":"Fast",
            "type":"url-test",
            "url":"http://www.gstatic.com/generate_204",
            "interval": 20,
            "tolerance": 50,
            "proxies":[p["name"] for p in fast_group]
        },
        {
            "name":"Stable",
            "type":"url-test",
            "url":"http://www.gstatic.com/generate_204",
            "interval":30,
            "tolerance":15,
            "proxies":[p["name"] for p in stable_group]
        },
        {
            "name":"Fallback",
            "type":"fallback",
            "url":"http://www.gstatic.com/generate_204",
            "interval":15,
            "proxies":[p["name"] for p in fallback_group]
        },
        smart_switch
    ],
    "rules":[
        "MATCH,Smart-Switch"
    ]
}

# ذخیره نهایی
with open(OUT_PATH,"w",encoding="utf-8") as f:
    yaml.dump(final_yaml, f, allow_unicode=True)

print(f"[DONE] Output saved:\n{OUT_PATH}")

