#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import shutil
from datetime import datetime
from rich.console import Console
from rich.prompt import Prompt
from rich.table import Table

console = Console()

BASE_BACKUP_DIR = "/sdcard/Download/akbar98"
TERMUX_HOME = "/data/data/com.termux/files/home"

os.makedirs(BASE_BACKUP_DIR, exist_ok=True)

def backup_selected(exts=(".py", ".sh")):
    """Backup only .py and .sh files from Termux HOME"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = os.path.join(BASE_BACKUP_DIR, f"backup_{timestamp}")
    os.makedirs(backup_dir, exist_ok=True)

    count = 0
    for root, dirs, files in os.walk(TERMUX_HOME):
        rel_path = os.path.relpath(root, TERMUX_HOME)
        dest_dir = os.path.join(backup_dir, rel_path) if rel_path != "." else backup_dir
        os.makedirs(dest_dir, exist_ok=True)

        for f in files:
            if f.endswith(exts):
                shutil.copy(os.path.join(root, f), dest_dir)
                count += 1

    console.print(f"[bold green]Backup complete.[/bold green] Files copied: {count}")

def restore_files():
    """Restore backed up .py and .sh files"""
    backups = sorted([d for d in os.listdir(BASE_BACKUP_DIR) if d.startswith("backup_")], reverse=True)
    if not backups:
        console.print("[bold red]No backups found.[/bold red]")
        return

    table = Table(title="Backups")
    table.add_column("No")
    table.add_column("Folder")

    for idx, b in enumerate(backups):
        table.add_row(str(idx + 1), b)

    console.print(table)
    choice = Prompt.ask("Select backup number (0 = cancel)", default="0")

    if choice == "0":
        console.print("Cancelled.")
        return

    try:
        idx = int(choice) - 1
        backup_dir = os.path.join(BASE_BACKUP_DIR, backups[idx])
    except:
        console.print("Invalid selection.")
        return

    for root, dirs, files in os.walk(backup_dir):
        rel_path = os.path.relpath(root, backup_dir)
        dest_dir = os.path.join(TERMUX_HOME, rel_path) if rel_path != "." else TERMUX_HOME
        os.makedirs(dest_dir, exist_ok=True)

        for f in files:
            if f.endswith((".py", ".sh")):
                shutil.copy(os.path.join(root, f), dest_dir)

    console.print(f"[bold green]Restore complete.[/bold green]")

def main():
    while True:
        console.print("\n[bold yellow]Termux Backup Manager[/bold yellow]")
        console.print("1: Backup .py and .sh files")
        console.print("2: Restore")
        console.print("0: Exit")

        choice = Prompt.ask("Select", default="0")

        if choice == "1":
            backup_selected()
        elif choice == "2":
            restore_files()
        elif choice == "0":
            console.print("Exit.")
            break
        else:
            console.print("Invalid option.")

if __name__ == "__main__":
    main()

