#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import copy
import os
from urllib.parse import urlparse, parse_qs, unquote

# ================= BASE CUSTOM CONFIG (FIXED TEMPLATE) =================
BASE_CONFIG = {
    "remarks": "hamedvpns-XSfilternet",
    "log": {
        "access": "",
        "error": "",
        "loglevel": "info",
        "dnsLog": False
    },
    "inbounds": [
        {
            "tag": "in_proxy",
            "port": 1080,
            "protocol": "socks",
            "listen": "0.0.0.0",
            "settings": {
                "auth": "noauth",
                "udp": True,
                "userLevel": 8
            },
            "sniffing": {
                "enabled": False
            }
        },
        {
            "tag": "http-in",
            "port": 10808,
            "listen": "::",
            "protocol": "http"
        }
    ],
    "outbounds": [
        {
            "tag": "proxy",
            "protocol": "trojan",
            "settings": {
                "servers": [
                    {
                        "address": "",
                        "port": 0,
                        "password": ""
                    }
                ]
            },
            "streamSettings": {
                "network": "ws",
                "security": "tls",
                "wsSettings": {
                    "path": "/",
                    "headers": {
                        "Host": ""
                    }
                },
                "tlsSettings": {
                    "allowInsecure": True,
                    "serverName": "",
                    "alpn": ["http/1.1"],
                    "fingerprint": "ios"
                },
                "sockopt": {
                    "dialerProxy": "fragment",
                    "tcpKeepAliveIdle": 100,
                    "tcpNoDelay": True
                }
            },
            "mux": {
                "enabled": False,
                "concurrency": 8
            }
        }
    ]
}

# ================= PARSER =================
def parse(link):
    u = urlparse(link)
    q = parse_qs(u.query)

    return {
        "address": u.hostname,
        "port": u.port,
        "password": u.username or "",
        "host": q.get("host", [""])[0] or q.get("sni", [""])[0] or "",
        "sni": q.get("sni", [""])[0] or q.get("host", [""])[0] or "",
        "path": unquote(q.get("path", ["/"])[0])
    }

# ================= PATCH ENGINE =================
def build_config(link):
    data = parse(link)

    cfg = copy.deepcopy(BASE_CONFIG)

    srv = cfg["outbounds"][0]["settings"]["servers"][0]
    stream = cfg["outbounds"][0]["streamSettings"]

    # فقط جایگزینی فیلدهای مهم
    srv["address"] = data["address"]
    srv["port"] = data["port"]
    srv["password"] = data["password"]

    if data["host"]:
        stream["wsSettings"]["headers"]["Host"] = data["host"]

    if data["sni"]:
        stream["tlsSettings"]["serverName"] = data["sni"]

    if data["path"]:
        stream["wsSettings"]["path"] = data["path"]

    return cfg

# ================= INPUT MODE =================
print("\nSelect Input Mode")
print("1) Paste Mode")
print("2) Nano Mode")
mode = input("> ").strip()

links = []

# PASTE MODE
if mode == "1":
    print("\nPaste links (type END to finish):")
    while True:
        x = input().strip()
        if x == "END":
            break
        links.append(x)

# NANO MODE
elif mode == "2":
    tmp_file = "/data/data/com.termux/files/home/custom_input.txt"
    open(tmp_file, "w").close()
    os.system(f"nano {tmp_file}")

    with open(tmp_file, "r") as f:
        links = [i.strip() for i in f.readlines() if i.strip()]

    os.remove(tmp_file)

else:
    print("Invalid option")
    exit()

# ================= BUILD OUTPUT =================
print("\n")

for l in links:
    result = build_config(l)
    print(json.dumps(result, ensure_ascii=False))
    print()
