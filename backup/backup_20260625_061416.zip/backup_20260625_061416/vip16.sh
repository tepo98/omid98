#!/data/data/com.termux/files/usr/bin/bash

# مسیر ذخیره خروجی
OUTPUT_DIR="/sdcard/Download/almasi98"
mkdir -p "$OUTPUT_DIR"

# رنگ‌ها
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

########################################
#        CONFIGURATION MENUS
########################################

ask_icmp_config() {
    echo -e "${YELLOW}Configure ICMP Test Parameters:${NC}"

    # ---- Packet Count ----
    echo "Select Packet Count:"
    echo "1) Lowest -> 2"
    echo "2) Medium -> 5"
    echo "3) Highest -> 10"
    echo "4) Custom"
    read -p "Choose [1-4]: " choice
    case $choice in
        1) ICMP_COUNT=2 ;;
        2) ICMP_COUNT=5 ;;
        3) ICMP_COUNT=10 ;;
        4) read -p "Enter custom packet count: " ICMP_COUNT ;;
        *) ICMP_COUNT=5 ;;
    esac

    # ---- Timeout ----
    echo "Select Timeout (seconds):"
    echo "1) Lowest -> 1"
    echo "2) Medium -> 3"
    echo "3) Highest -> 5"
    echo "4) Custom"
    read -p "Choose [1-4]: " choice
    case $choice in
        1) ICMP_TIMEOUT=1 ;;
        2) ICMP_TIMEOUT=3 ;;
        3) ICMP_TIMEOUT=5 ;;
        4) read -p "Enter custom timeout: " ICMP_TIMEOUT ;;
        *) ICMP_TIMEOUT=3 ;;
    esac

    echo -e "${GREEN}ICMP config -> count=$ICMP_COUNT, timeout=$ICMP_TIMEOUT${NC}"
}

ask_tcp_config() {
    echo -e "${YELLOW}Configure TCP Test Parameters:${NC}"

    # ---- Port ----
    echo "Select Port:"
    echo "1) Lowest -> 22 (SSH)"
    echo "2) Medium -> 80 (HTTP)"
    echo "3) Highest -> 443 (HTTPS)"
    echo "4) Custom"
    read -p "Choose [1-4]: " choice
    case $choice in
        1) TCP_PORT=22 ;;
        2) TCP_PORT=80 ;;
        3) TCP_PORT=443 ;;
        4) read -p "Enter custom port: " TCP_PORT ;;
        *) TCP_PORT=443 ;;
    esac

    # ---- Timeout ----
    echo "Select Timeout (seconds):"
    echo "1) Lowest -> 2"
    echo "2) Medium -> 5"
    echo "3) Highest -> 10"
    echo "4) Custom"
    read -p "Choose [1-4]: " choice
    case $choice in
        1) TCP_TIMEOUT=2 ;;
        2) TCP_TIMEOUT=5 ;;
        3) TCP_TIMEOUT=10 ;;
        4) read -p "Enter custom timeout: " TCP_TIMEOUT ;;
        *) TCP_TIMEOUT=5 ;;
    esac

    # ---- Retries ----
    echo "Select Retries:"
    echo "1) Lowest -> 1"
    echo "2) Medium -> 2"
    echo "3) Highest -> 5"
    echo "4) Custom"
    read -p "Choose [1-4]: " choice
    case $choice in
        1) TCP_RETRIES=1 ;;
        2) TCP_RETRIES=2 ;;
        3) TCP_RETRIES=5 ;;
        4) read -p "Enter custom retries: " TCP_RETRIES ;;
        *) TCP_RETRIES=2 ;;
    esac

    # ---- Retry Sleep ----
    echo "Select Retry Sleep (seconds):"
    echo "1) Lowest -> 1"
    echo "2) Medium -> 2"
    echo "3) Highest -> 3"
    echo "4) Custom"
    read -p "Choose [1-4]: " choice
    case $choice in
        1) TCP_RETRY_SLEEP=1 ;;
        2) TCP_RETRY_SLEEP=2 ;;
        3) TCP_RETRY_SLEEP=3 ;;
        4) read -p "Enter custom retry sleep: " TCP_RETRY_SLEEP ;;
        *) TCP_RETRY_SLEEP=1 ;;
    esac

    echo -e "${GREEN}TCP config -> port=$TCP_PORT, timeout=$TCP_TIMEOUT, retries=$TCP_RETRIES, sleep=$TCP_RETRY_SLEEP${NC}"
}

ask_url_config() {
    echo -e "${YELLOW}Configure URL Test Parameters:${NC}"

    # ---- Timeout ----
    echo "Select Timeout (seconds):"
    echo "1) Lowest -> 2"
    echo "2) Medium -> 5"
    echo "3) Highest -> 10"
    echo "4) Custom"
    read -p "Choose [1-4]: " choice
    case $choice in
        1) URL_TIMEOUT=2 ;;
        2) URL_TIMEOUT=5 ;;
        3) URL_TIMEOUT=10 ;;
        4) read -p "Enter custom timeout: " URL_TIMEOUT ;;
        *) URL_TIMEOUT=5 ;;
    esac

    # ---- Expected Codes ----
    echo "Select Expected HTTP Codes:"
    echo "1) Lowest -> 200 only"
    echo "2) Medium -> 200, 204"
    echo "3) Highest -> 200, 204, 301, 302"
    echo "4) Custom"
    read -p "Choose [1-4]: " choice
    case $choice in
        1) URL_CODES="200" ;;
        2) URL_CODES="200|204" ;;
        3) URL_CODES="200|204|301|302" ;;
        4) read -p "Enter custom codes (regex, e.g. 200|204|301): " URL_CODES ;;
        *) URL_CODES="200|204" ;;
    esac

    echo -e "${GREEN}URL config -> timeout=$URL_TIMEOUT, codes=$URL_CODES${NC}"
}

########################################
#        MAIN MENU
########################################
main_menu() {
    echo -e "${YELLOW}========== Network Test Menu ==========${NC}"
    echo -e "1) ICMP Test"
    echo -e "2) TCP Test"
    echo -e "3) URL Test"
    echo -e "4) Run All Tests"
    echo -e "0) Exit"
    echo -n "Choose an option: "
    read option

    case $option in
        1) protocol="ICMP" ;;
        2) protocol="TCP" ;;
        3) protocol="URL" ;;
        4) protocol="ALL" ;;
        0) exit 0 ;;
        *) echo -e "${RED}Invalid option${NC}"; main_menu ;;
    esac
}

# گرفتن لیست کانفیگ‌ها / URL‌ها
get_targets() {
    echo -e "${YELLOW}Enter each target (SS/VMess URL) per line. Press Ctrl+D when done:${NC}"
    targets=()
    while read line; do
        [ -n "$line" ] && targets+=("$line")
    done
}

# گرفتن نام فایل خروجی
get_output_file() {
    echo -n "Enter output file name (without extension): "
    read filename
    output_path="$OUTPUT_DIR/${filename}.txt"
    > "$output_path"
}

########################################
#        TEST FUNCTIONS
########################################

test_icmp() {
    ask_icmp_config
    echo -e "${YELLOW}Running ICMP tests...${NC}"
    success_targets=()
    for target in "${targets[@]}"; do
        host=$(echo "$target" | awk -F@ '{print $2}' | awk -F: '{print $1}')
        ping -c $ICMP_COUNT -W $ICMP_TIMEOUT $host &> /dev/null
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}ICMP Success: $target${NC}"
            success_targets+=("$target")
        else
            echo -e "${RED}ICMP Failed: $target${NC}"
        fi
    done
    targets=("${success_targets[@]}")
}

test_tcp() {
    ask_tcp_config
    echo -e "${YELLOW}Running TCP tests...${NC}"
    success_targets=()
    for target in "${targets[@]}"; do
        host=$(echo "$target" | awk -F@ '{print $2}' | awk -F: '{print $1}')

        attempt=1
        success=0
        while [ $attempt -le $TCP_RETRIES ]; do
            nc -z -w $TCP_TIMEOUT $host $TCP_PORT &> /dev/null
            if [ $? -eq 0 ]; then
                success=1
                break
            else
                echo -e "${YELLOW}TCP attempt $attempt failed for $target${NC}"
                sleep $TCP_RETRY_SLEEP
            fi
            attempt=$((attempt+1))
        done

        if [ $success -eq 1 ]; then
            echo -e "${GREEN}TCP Success: $target${NC}"
            success_targets+=("$target")
        else
            echo -e "${RED}TCP Failed: $target${NC}"
        fi
    done
    targets=("${success_targets[@]}")
}

test_url() {
    ask_url_config
    echo -e "${YELLOW}Running URL/HTTP tests...${NC}"
    success_targets=()
    for target in "${targets[@]}"; do
        host=$(echo "$target" | awk -F@ '{print $2}' | awk -F: '{print $1}')
        http_code=$(curl -m $URL_TIMEOUT -o /dev/null -s -w "%{http_code}" "https://$host")
        echo "$http_code" | grep -Eq "$URL_CODES"
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}URL Success: $target (code $http_code)${NC}"
            success_targets+=("$target")
        else
            echo -e "${RED}URL Failed: $target (code $http_code)${NC}"
        fi
    done
    targets=("${success_targets[@]}")
}

########################################
#        MAIN LOOP
########################################
while true; do
    main_menu
    get_targets
    get_output_file

    case $protocol in
        ICMP) test_icmp ;;
        TCP) test_tcp ;;
        URL) test_url ;;
        ALL)
            test_icmp
            test_tcp
            test_url
            ;;
    esac

    for target in "${targets[@]}"; do
        echo "$target" >> "$output_path"
    done

    echo -e "${YELLOW}Test completed. Results saved to $output_path${NC}"
    echo -e "Press Enter to return to the main menu..."
    read
done


